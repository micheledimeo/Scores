<?php
return [
    'routes' => [
        ['name' => 'page#index', 'url' => '/', 'verb' => 'GET'],
        ['name' => 'api#getFile', 'url' => '/api/file/{fileId}', 'verb' => 'GET'],
        ['name' => 'api#listFiles', 'url' => '/api/files', 'verb' => 'GET'],
        ['name' => 'api#createShare', 'url' => '/api/share/{fileId}', 'verb' => 'POST'],
        ['name' => 'public#showShare', 'url' => '/s/{token}', 'verb' => 'GET'],
        ['name' => 'settings#isAdmin', 'url' => '/api/settings/isAdmin', 'verb' => 'GET'],
        ['name' => 'settings#getScoresFolder', 'url' => '/api/settings/folder', 'verb' => 'GET'],
        ['name' => 'settings#setScoresFolder', 'url' => '/api/settings/folder', 'verb' => 'POST'],
        ['name' => 'settings#browseFolders', 'url' => '/api/settings/browse', 'verb' => 'GET'],
    ]
];
