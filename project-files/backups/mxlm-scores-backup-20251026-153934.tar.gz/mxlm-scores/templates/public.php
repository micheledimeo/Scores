<script>
    // Inject file data for Vue app
    window.scoresData = {
        fileId: null,
        fileName: <?php p(json_encode($_['fileName'])); ?>,
        fileContent: <?php p(json_encode($_['fileContent'])); ?>,
        isPublicShare: true,
        token: <?php p(json_encode($_['token'])); ?>
    };
</script>

<div id="app"></div>
