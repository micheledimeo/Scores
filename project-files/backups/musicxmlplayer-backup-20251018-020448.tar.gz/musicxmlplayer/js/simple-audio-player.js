/**
 * Enhanced Audio Player - Fallback when OSMD PlaybackManager not available
 * Uses Web Audio API directly with MIDI-like note synthesis
 */
class SimpleAudioPlayer {
    constructor(audioContext) {
        this.audioContext = audioContext;
        this.currentNotes = [];
        this.isPlaying = false;
        this.currentBeat = 0;
        this.bpm = 120;
        this.gain = null;
        this.init();
    }
    
    init() {
        // Create master gain node
        this.gain = this.audioContext.createGain();
        this.gain.connect(this.audioContext.destination);
        this.gain.gain.value = 0.3;
    }
    
    // Simple note frequency mapping
    getNoteFrequency(noteName) {
        const noteMap = {
            'C': 261.63, 'C#': 277.18, 'D': 293.66, 'D#': 311.13,
            'E': 329.63, 'F': 349.23, 'F#': 369.99, 'G': 392.00,
            'G#': 415.30, 'A': 440.00, 'A#': 466.16, 'B': 493.88
        };
        
        const note = noteName.replace(/[0-9]/g, '');
        const octave = parseInt(noteName.match(/[0-9]/)?.[0] || '4');
        const baseFreq = noteMap[note] || 440;
        
        return baseFreq * Math.pow(2, octave - 4);
    }
    
    playNote(frequency, duration = 0.5) {
        const oscillator = this.audioContext.createOscillator();
        const noteGain = this.audioContext.createGain();
        
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime);
        
        // Envelope
        noteGain.gain.setValueAtTime(0, this.audioContext.currentTime);
        noteGain.gain.linearRampToValueAtTime(0.3, this.audioContext.currentTime + 0.01);
        noteGain.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration);
        
        oscillator.connect(noteGain);
        noteGain.connect(this.gain);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + duration);
        
        return oscillator;
    }
    
    simulateScorePlayback() {
        // Simple C major scale for demo
        const notes = ['C4', 'D4', 'E4', 'F4', 'G4', 'A4', 'B4', 'C5'];
        let noteIndex = 0;
        
        const playNextNote = () => {
            if (this.isPlaying && noteIndex < notes.length) {
                const freq = this.getNoteFrequency(notes[noteIndex]);
                this.playNote(freq, 0.8);
                noteIndex++;
                
                if (noteIndex >= notes.length) {
                    noteIndex = 0; // Loop
                }
                
                setTimeout(playNextNote, (60 / this.bpm) * 1000);
            }
        };
        
        playNextNote();
    }
    
    start() {
        this.isPlaying = true;
        this.simulateScorePlayback();
    }
    
    stop() {
        this.isPlaying = false;
    }
    
    pause() {
        this.isPlaying = false;
    }
}

// Export for use in main player
window.SimpleAudioPlayer = SimpleAudioPlayer;
