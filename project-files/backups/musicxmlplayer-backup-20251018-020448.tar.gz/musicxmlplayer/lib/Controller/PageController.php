<?php
declare(strict_types=1);

namespace OCA\MusicXMLPlayer\Controller;

use OCP\IRequest;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\AppFramework\Http\DataResponse;
use OCP\AppFramework\Controller;
use OCP\Files\IRootFolder;
use OCP\IUserSession;
use OCP\Files\NotFoundException;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use OCP\AppFramework\Http\Attribute\NoCSRFRequired;

class PageController extends Controller {
    private ?string $userId;
    private IRootFolder $rootFolder;
    private IUserSession $userSession;

    public function __construct(
        string $appName,
        IRequest $request,
        ?string $userId,
        IRootFolder $rootFolder,
        IUserSession $userSession
    ) {
        parent::__construct($appName, $request);
        $this->userId = $userId;
        $this->rootFolder = $rootFolder;
        $this->userSession = $userSession;
    }

    #[NoAdminRequired]
    #[NoCSRFRequired]
    public function index(): TemplateResponse {
        return new TemplateResponse('musicxmlplayer', 'index', [
            'app_version' => '1.0.0'
        ]);
    }

    #[NoAdminRequired]
    #[NoCSRFRequired]
    public function listMusicFiles(): DataResponse {
        try {
            // Verifica che l'utente sia loggato
            if (!$this->userId) {
                return new DataResponse(['error' => 'User not logged in'], 401);
            }
            
            $userFolder = $this->rootFolder->getUserFolder($this->userId);
            
            $files = [];
            $this->searchMusicFiles($userFolder, $files);
            
            return new DataResponse(['files' => $files]);
        } catch (\Exception $e) {
            \OC::$server->getLogger()->error('Error in listMusicFiles: ' . $e->getMessage(), ['app' => 'musicxmlplayer']);
            return new DataResponse(['error' => $e->getMessage()], 500);
        }
    }

    private function searchMusicFiles($folder, &$files) {
        try {
            $nodes = $folder->getDirectoryListing();
            
            foreach ($nodes as $node) {
                if ($node->getType() === \OCP\Files\FileInfo::TYPE_FILE) {
                    $extension = strtolower(pathinfo($node->getName(), PATHINFO_EXTENSION));
                    if (in_array($extension, ['mxml', 'musicxml', 'xml'])) {
                        // Quick check if it's a MusicXML file
                        if ($this->isMusicXMLFile($node)) {
                            $files[] = [
                                'id' => $node->getId(),
                                'name' => $node->getName(),
                                'path' => $node->getPath(),
                                'size' => $node->getSize(),
                                'mtime' => $node->getMTime()
                            ];
                        }
                    }
                } elseif ($node->getType() === \OCP\Files\FileInfo::TYPE_FOLDER) {
                    // Recursively search in subfolders (limit depth to avoid timeout)
                    if (count(explode('/', $node->getPath())) < 10) {
                        $this->searchMusicFiles($node, $files);
                    }
                }
            }
        } catch (\Exception $e) {
            // Skip folders we can't access
            \OC::$server->getLogger()->debug('Cannot access folder: ' . $e->getMessage(), ['app' => 'musicxmlplayer']);
        }
    }

    #[NoAdminRequired]
    #[NoCSRFRequired]
    public function getFileContent(int $fileId): DataResponse {
        try {
            if (!$this->userId) {
                return new DataResponse(['error' => 'User not logged in'], 401);
            }
            
            $userFolder = $this->rootFolder->getUserFolder($this->userId);
            $files = $userFolder->getById($fileId);
            
            if (empty($files)) {
                return new DataResponse(['error' => 'File not found'], 404);
            }
            
            $file = $files[0];
            
            // Verifica che sia un file MusicXML
            if (!$this->isMusicXMLFile($file)) {
                return new DataResponse(['error' => 'Not a valid MusicXML file'], 400);
            }
            
            $content = $file->getContent();
            
            return new DataResponse([
                'content' => $content,
                'name' => $file->getName(),
                'path' => $file->getPath()
            ]);
        } catch (\Exception $e) {
            \OC::$server->getLogger()->error('Error in getFileContent: ' . $e->getMessage(), ['app' => 'musicxmlplayer']);
            return new DataResponse(['error' => $e->getMessage()], 500);
        }
    }

    private function isMusicXMLFile($file): bool {
        try {
            // Read only first 1000 bytes to check
            $handle = $file->fopen('r');
            if (!$handle) {
                return false;
            }
            
            $content = fread($handle, 1000);
            fclose($handle);
            
            if (!$content) {
                return false;
            }
            
            // Check for MusicXML signature
            return (strpos($content, '<score-partwise') !== false || 
                    strpos($content, '<score-timewise') !== false ||
                    strpos($content, 'DOCTYPE score-partwise') !== false ||
                    strpos($content, 'musicxml') !== false);
        } catch (\Exception $e) {
            return false;
        }
    }
}