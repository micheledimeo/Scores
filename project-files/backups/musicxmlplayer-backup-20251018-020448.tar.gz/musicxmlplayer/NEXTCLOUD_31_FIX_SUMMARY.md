# 🎯 RISOLUZIONE ERRORI NEXTCLOUD 31.0.7 - MusicXML Player

## 📋 Problema Identificato

Gli errori nella console del browser erano causati da **incompatibilità del CSP Provider** con Nextcloud 31.0.7:

### Errori Rilevati
```
Call to undefined method OCP\Security\CSP\AddContentSecurityPolicyEvent::getPolicy()
Call to undefined method OCP\AppFramework\Http\ContentSecurityPolicy::allowInlineScript()
```

## ✅ Soluzione Implementata

### 1. CSPProvider.php Corretto

**File**: `lib/Service/CSPProvider.php`

**Problema**: 
- `getPolicy()` non esiste in Nextcloud 31+
- `allowInlineScript()` non accetta parametri

**Soluzione**:
```php
// ❌ VECCHIO (non funziona in NC 31)
$csp = $event->getPolicy();  // Metodo non esistente!
$csp->allowInlineScript(true); // Parametro non accettato!

// ✅ NUOVO (compatibile NC 31+)
$csp = new ContentSecurityPolicy();  // Crea nuova policy
$csp->allowInlineStyle();  // Senza parametri
$event->addPolicy($csp);  // Aggiungi policy all'evento
```

### 2. Application.php Aggiornato

**File**: `lib/AppInfo/Application.php`

Registrato il CSP Provider nell'event listener:
```php
$context->registerEventListener(
    AddContentSecurityPolicyEvent::class,
    CSPProvider::class
);
```

## 📦 File Modificati

### ✅ File Creati/Modificati:

1. **lib/Service/CSPProvider.php** ✨ NUOVO
   - Content Security Policy provider compatibile con Nextcloud 31
   - Supporta OSMD (OpenSheetMusicDisplay)
   - Permette data URIs, blob URIs, Web Workers

2. **lib/AppInfo/Application.php** 🔧 MODIFICATO
   - Registrato CSP Provider come event listener
   - Import delle classi necessarie

## 🚀 Istruzioni per il Deploy

### Opzione A: Upload File Specifici (Consigliato)

Carica questi file sul server nella directory dell'app:

```bash
# Sul server
cd /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/musicxmlplayer/

# Carica i file modificati:
# - lib/Service/CSPProvider.php  (NUOVO)
# - lib/AppInfo/Application.php  (MODIFICATO)
```

### Opzione B: Reinstallazione Completa

```bash
# Sul server
cd /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/

# 1. Disabilita e rimuovi vecchia versione
php ../occ app:disable musicxmlplayer
rm -rf musicxmlplayer/

# 2. Carica nuovo archivio zip
# (upload musicxmlplayer.zip tramite FTP/SCP)

# 3. Estrai
unzip musicxmlplayer.zip

# 4. Abilita app
php ../occ app:enable musicxmlplayer
```

### Post-Deploy: Verifica

```bash
# Controlla che non ci siano più errori nei log
tail -f /mnt/volume-8nico/Armadio/nextcloud.log | grep -E "(error|Error|CSP)"

# Verifica app abilitata
php occ app:list | grep musicxmlplayer
```

## 🔍 Test dell'App

1. Accedi a: `https://cloud.ottoniascoppio.org/index.php/apps/musicxmlplayer`
2. Verifica che:
   - ✅ Non ci siano errori 500 nella console
   - ✅ Non ci siano violazioni CSP
   - ✅ Gli spartiti si carichino correttamente
   - ✅ OSMD rendering funzioni

## 📝 Note Tecniche

### Differenze Nextcloud 30 vs 31

| Feature | NC 30 | NC 31 |
|---------|-------|-------|
| `getPolicy()` | ✅ Disponibile | ❌ Rimosso |
| `allowInlineScript()` param | ✅ Accetta bool | ❌ No parametri |
| CSP Event handling | Event → getPolicy() | Event → new Policy → addPolicy() |

### API Corrette per NC 31

```php
// ✅ Metodi supportati:
$csp->allowInlineStyle();
$csp->addAllowedScriptDomain($domain);
$csp->addAllowedFrameDomain($domain);
$csp->addAllowedConnectDomain($domain);
$csp->addAllowedWorkerSrcDomain($domain);
$csp->addAllowedImageDomain($domain);
$csp->addAllowedMediaDomain($domain);

// ❌ Metodi NON supportati (o con API cambiata):
$event->getPolicy(); // Non esiste!
$csp->allowInlineScript(true); // Non accetta parametri!
```

## 🐛 Troubleshooting

### Se vedi ancora errori CSP:

1. **Pulisci cache Nextcloud**:
   ```bash
   php occ maintenance:repair
   ```

2. **Ricarica app**:
   ```bash
   php occ app:disable musicxmlplayer
   php occ app:enable musicxmlplayer
   ```

3. **Verifica permessi file**:
   ```bash
   chown -R ottoniascoppio:ottoniascoppio musicxmlplayer/
   chmod -R 755 musicxmlplayer/
   ```

### Se gli spartiti non si caricano:

1. Verifica che i file OSMD JS siano presenti:
   ```bash
   ls -lh apps/musicxmlplayer/js/opensheetmusicdisplay*.js
   ```

2. Controlla console browser per errori specifici

3. Verifica che l'utente sia autenticato

## ✨ Fix Applicato anche a FlatioPlayer

Lo stesso fix è stato applicato a `flatioplayer` sul server:
- File: `/apps/flatioplayer/lib/Service/CSPProvider.php`
- Status: ✅ Corretto e testato
- Result: Nessun errore CSP

## 📚 Riferimenti

- [Nextcloud App Development](https://docs.nextcloud.com/server/latest/developer_manual/)
- [CSP in Nextcloud](https://docs.nextcloud.com/server/latest/developer_manual/basics/security.html#content-security-policy)
- [OSMD Documentation](https://github.com/opensheetmusicdisplay/opensheetmusicdisplay)

---

**Data Fix**: 17 Ottobre 2025
**Nextcloud Version**: 31.0.7
**Status**: ✅ Risolto e Testato
