/**
 * OSMD Container Debug Script - OPTIONAL
 * Include this script if you need debugging capabilities
 * Usage: <script src="js/osmd-debug.js"></script>
 */

class OSMDContainerDebugger {
    constructor() {
        this.testResults = [];
    }
    
    // Test completo del container
    async runFullTest() {
        console.log('🧪 === OSMD CONTAINER FULL TEST ===');
        
        this.testResults = [];
        
        await this.testElementExistence();
        await this.testCSS();
        await this.testDimensions();
        await this.testVisibilitySequence();
        await this.testBasicOSMD();
        
        this.generateReport();
    }
    
    async testElementExistence() {
        console.log('🔍 Test 1: Element Existence');
        const elements = [
            'score-container',
            'osmd-container',
            'score-area',
            'welcome-guide'
        ];
        
        elements.forEach(id => {
            const element = document.getElementById(id);
            const exists = !!element;
            console.log(`  ${exists ? '✅' : '❌'} ${id}: ${exists ? 'Found' : 'NOT FOUND'}`);
            this.testResults.push({ test: 'existence', element: id, passed: exists });
        });
    }
    
    async testCSS() {
        console.log('🎨 Test 2: CSS Properties');
        const container = document.getElementById('osmd-container');
        if (!container) {
            console.log('  ❌ Container not found');
            return;
        }
        
        const style = window.getComputedStyle(container);
        const tests = [
            { prop: 'display', expected: 'block', actual: style.display },
            { prop: 'visibility', expected: 'visible', actual: style.visibility },
            { prop: 'min-width', expected: '850px', actual: style.minWidth },
            { prop: 'min-height', expected: '650px', actual: style.minHeight }
        ];
        
        tests.forEach(test => {
            const passed = test.actual.includes(test.expected.replace('px', ''));
            console.log(`  ${passed ? '✅' : '❌'} ${test.prop}: ${test.actual} (expected: ${test.expected})`);
            this.testResults.push({ test: 'css', property: test.prop, passed });
        });
    }
    
    async testDimensions() {
        console.log('📐 Test 3: Dimensions');
        const container = document.getElementById('osmd-container');
        if (!container) {
            console.log('  ❌ Container not found');
            return;
        }
        
        container.offsetHeight;
        const rect = container.getBoundingClientRect();
        const tests = [
            { name: 'width > 0', value: rect.width, test: rect.width > 0 },
            { name: 'height > 0', value: rect.height, test: rect.height > 0 },
            { name: 'width >= 800', value: rect.width, test: rect.width >= 800 },
            { name: 'height >= 600', value: rect.height, test: rect.height >= 600 }
        ];
        
        tests.forEach(test => {
            console.log(`  ${test.test ? '✅' : '❌'} ${test.name}: ${test.value}`);
            this.testResults.push({ test: 'dimensions', name: test.name, passed: test.test, value: test.value });
        });
    }
    
    async testVisibilitySequence() {
        console.log('🔄 Test 4: Visibility Sequence');
        
        const welcomeGuide = document.getElementById('welcome-guide');
        const scoreContainer = document.getElementById('score-container');
        
        if (welcomeGuide) {
            welcomeGuide.style.display = 'none';
            console.log('  ✅ Welcome guide hidden');
        }
        
        if (scoreContainer) {
            scoreContainer.style.display = 'block';
            scoreContainer.style.visibility = 'visible';
            scoreContainer.style.opacity = '1';
            console.log('  ✅ Score container shown');
        }
        
        await new Promise(resolve => setTimeout(resolve, 500));
        
        const container = document.getElementById('osmd-container');
        if (container) {
            container.offsetHeight;
            const rect = container.getBoundingClientRect();
            const valid = rect.width > 0 && rect.height > 0;
            console.log(`  ${valid ? '✅' : '❌'} Post-visibility dimensions: ${rect.width}x${rect.height}`);
            this.testResults.push({ test: 'visibility-sequence', passed: valid, dimensions: `${rect.width}x${rect.height}` });
        }
    }
    
    async testBasicOSMD() {
        console.log('🎼 Test 5: Basic OSMD Creation');
        
        try {
            if (typeof window.opensheetmusicdisplay === 'undefined') {
                console.log('  ❌ OSMD library not available');
                this.testResults.push({ test: 'osmd-basic', passed: false, error: 'Library not found' });
                return;
            }
            
            const container = document.getElementById('osmd-container');
            if (!container) {
                console.log('  ❌ Container not found');
                this.testResults.push({ test: 'osmd-basic', passed: false, error: 'Container not found' });
                return;
            }
            
            container.innerHTML = '';
            container.style.width = '800px';
            container.style.height = '600px';
            container.offsetHeight;
            
            const rect = container.getBoundingClientRect();
            console.log(`  📐 Container dimensions before OSMD: ${rect.width}x${rect.height}`);
            
            if (rect.width <= 0 || rect.height <= 0) {
                console.log('  ❌ Invalid dimensions before OSMD creation');
                this.testResults.push({ test: 'osmd-basic', passed: false, error: 'Invalid dimensions' });
                return;
            }
            
            const osmd = new window.opensheetmusicdisplay.OpenSheetMusicDisplay(container, {
                autoResize: false,
                backend: 'svg'
            });
            
            console.log('  ✅ OSMD instance created successfully');
            this.testResults.push({ test: 'osmd-basic', passed: true });
            
            osmd.clear();
            
        } catch (error) {
            console.log(`  ❌ OSMD creation failed: ${error.message}`);
            this.testResults.push({ test: 'osmd-basic', passed: false, error: error.message });
        }
    }
    
    generateReport() {
        console.log('📊 === TEST REPORT ===');
        
        const byTest = this.testResults.reduce((acc, result) => {
            if (!acc[result.test]) acc[result.test] = { passed: 0, failed: 0, total: 0 };
            acc[result.test].total++;
            if (result.passed) acc[result.test].passed++;
            else acc[result.test].failed++;
            return acc;
        }, {});
        
        Object.entries(byTest).forEach(([test, stats]) => {
            const status = stats.failed === 0 ? '✅' : '❌';
            console.log(`${status} ${test}: ${stats.passed}/${stats.total} passed`);
        });
        
        const totalPassed = this.testResults.filter(r => r.passed).length;
        const totalTests = this.testResults.length;
        
        console.log(`\n🎯 Overall: ${totalPassed}/${totalTests} tests passed`);
        
        if (totalPassed < totalTests) {
            console.log('\n🔧 Suggested Fixes:');
            const failedTests = this.testResults.filter(r => !r.passed);
            failedTests.forEach(test => {
                if (test.error) {
                    console.log(`  • ${test.test}: ${test.error}`);
                }
            });
        }
        
        console.log('📊 === END REPORT ===');
        
        return { passed: totalPassed, total: totalTests, details: byTest };
    }
    
    // Quick fix per dimensioni
    applyQuickFix() {
        console.log('🔧 Applying quick fix...');
        
        const scoreContainer = document.getElementById('score-container');
        const osmdContainer = document.getElementById('osmd-container');
        
        if (scoreContainer) {
            scoreContainer.style.cssText = `
                position: absolute !important;
                top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
                width: 100% !important; height: 100% !important;
                display: block !important; visibility: visible !important; opacity: 1 !important;
                background: white !important; z-index: 5 !important;
            `;
        }
        
        if (osmdContainer) {
            osmdContainer.style.cssText = `
                width: 850px !important; height: 650px !important;
                min-width: 850px !important; min-height: 650px !important;
                display: block !important; visibility: visible !important; opacity: 1 !important;
                background: white !important; padding: 20px !important;
                position: relative !important; box-sizing: border-box !important;
            `;
            osmdContainer.offsetHeight;
        }
        
        console.log('✅ Quick fix applied');
    }
}

// Make debugger available globally
window.osmdDebugger = new OSMDContainerDebugger();

console.log('🧪 OSMD Container Debugger loaded!');
console.log('💡 Commands available:');
console.log('  • window.osmdDebugger.runFullTest() - Complete test suite');
console.log('  • window.osmdDebugger.applyQuickFix() - Emergency fix');
console.log('  • window.player.debugOSMDStatus() - Player status');
