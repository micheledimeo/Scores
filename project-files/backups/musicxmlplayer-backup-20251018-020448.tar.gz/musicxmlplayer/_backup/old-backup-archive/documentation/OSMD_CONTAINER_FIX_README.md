# 🔧 Fix per "Container has invalid dimensions" - OSMD

## 📋 Problema Identificato

L'errore `Container has invalid dimensions` si verifica perché OSMD cerca di accedere alle dimensioni del container prima che il browser abbia completato il layout rendering dopo la transizione CSS da `display: none` a `display: block`.

## 🎯 Cause principali:

1. **Timing Issue**: Il container viene mostrato ma le dimensioni non sono ancora calcolate
2. **CSS Transitions**: Il browser ha bisogno di tempo per calcolare le dimensioni finali
3. **Layout Thrashing**: Accesso prematuro alle dimensioni prima del reflow

## 🛠️ Soluzioni Implementate

### 1. **Metodo `waitForContainer()` Migliorato**
- ✅ Controlli più robusti delle dimensioni (soglia 100px invece di 0px)
- ✅ Verifica stato CSS (display, visibility, opacity)
- ✅ Fallback aggressivo con dimensioni forzate
- ✅ Aumentati tentativi e timeout (30 tentativi, 100ms ciascuno)

### 2. **Metodo `selectFile()` Rafforzato**
- ✅ Sequenza controllata di visibility
- ✅ Debug dettagliato dello stato del container
- ✅ Verifiche multiple delle dimensioni
- ✅ Gestione errori user-friendly

### 3. **CSS Migliorato**
- ✅ Dimensioni minime aumentate (850x650px)
- ✅ Forzatura layout con `::before` pseudo-element
- ✅ Media queries per schermi piccoli
- ✅ Classi debug per troubleshooting

### 4. **Tool di Debug**
- ✅ Script completo di testing del container
- ✅ Verifiche automatiche di CSS, dimensioni, visibilità
- ✅ Quick fix per problemi comuni
- ✅ Report dettagliato dei test

## 🚀 Come Implementare i Fix

### Opzione A: Aggiornamento Graduale (Raccomandato)

1. **Sostituisci i metodi nel file esistente**:
   ```javascript
   // In musicxmlplayer.js, sostituisci:
   // - waitForContainer()
   // - selectFile()
   // Aggiungi:
   // - debugContainerState()
   // - verifyContainerDimensions()
   // - ensureParentContainersVisible()
   // - showUserErrorMessage()
   ```

2. **Aggiungi il CSS migliorato**:
   ```html
   <!-- Nel template index.php -->
   <link rel="stylesheet" href="css/container-fix.css">
   ```

3. **Aggiungi lo script di debug**:
   ```html
   <!-- Per troubleshooting -->
   <script src="js/osmd-debug.js"></script>
   ```

### Opzione B: Applicazione Immediata dei Fix

1. **Backup del file corrente**:
   ```bash
   cp js/musicxmlplayer.js js/musicxmlplayer.js.backup
   ```

2. **Applica i fix specifici**:

**Fix 1: Sostituisci il metodo `waitForContainer()`** (linee ~215-250):
```javascript
async waitForContainer() {
    return new Promise((resolve) => {
        const container = document.getElementById('osmd-container');
        if (!container) {
            console.log('⚠️ Container not found, proceeding anyway');
            resolve();
            return;
        }

        let attempts = 0;
        const maxAttempts = 30;
        
        const checkContainer = () => {
            attempts++;
            
            container.style.display = 'block';
            container.offsetHeight;
            
            const rect = container.getBoundingClientRect();
            const computedStyle = window.getComputedStyle(container);
            
            const hasValidDimensions = rect.width > 100 && rect.height > 100;
            const isVisible = computedStyle.display !== 'none' && 
                            computedStyle.visibility !== 'hidden' && 
                            parseFloat(computedStyle.opacity) > 0;
            
            if (hasValidDimensions && isVisible) {
                console.log('✅ Container ready:', rect.width, 'x', rect.height);
                resolve();
            } else if (attempts >= maxAttempts) {
                console.log('⏰ Container timeout, applying AGGRESSIVE fallback...');
                
                const scoreContainer = document.getElementById('score-container');
                if (scoreContainer) {
                    scoreContainer.style.display = 'block !important';
                    scoreContainer.style.visibility = 'visible !important';
                    scoreContainer.style.opacity = '1 !important';
                }
                
                container.style.cssText = `
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                    width: 800px !important;
                    height: 600px !important;
                    min-width: 800px !important;
                    min-height: 600px !important;
                    background: white !important;
                    position: relative !important;
                    z-index: 1000 !important;
                `;
                
                container.offsetHeight;
                container.offsetWidth;
                document.body.offsetHeight;
                
                setTimeout(() => {
                    console.log('🔧 Forced dimensions applied, proceeding...');
                    resolve();
                }, 100);
            } else {
                setTimeout(checkContainer, 100);
            }
        };

        this.ensureParentContainersVisible();
        setTimeout(checkContainer, 200);
    });
}
```

**Fix 2: Aggiungi il metodo helper** (dopo `waitForContainer()`):
```javascript
ensureParentContainersVisible() {
    const containers = [
        'score-container',
        'score-area', 
        'main-content',
        'content-wrapper'
    ];
    
    containers.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            const style = window.getComputedStyle(element);
            if (style.display === 'none' || style.visibility === 'hidden') {
                console.log(`🔧 Making ${id} visible`);
                element.style.display = 'block';
                element.style.visibility = 'visible';
                element.style.opacity = '1';
            }
        }
    });
    
    document.body.offsetHeight;
}
```

**Fix 3: Migliora il metodo `selectFile()`** (linee ~185-210):
```javascript
async selectFile(file) {
    try {
        console.log('🎵 Loading file:', file.name);
        const xmlContent = await this.fetchFileContent(file);
        
        console.log('🔄 Starting container visibility sequence...');
        
        this.showWelcomeGuide(false);
        
        const scoreContainer = document.getElementById('score-container');
        if (scoreContainer) {
            scoreContainer.style.display = 'block';
            scoreContainer.classList.add('visible');
            console.log('✅ Score container shown');
        }
        
        document.body.offsetHeight;
        scoreContainer?.offsetHeight;
        
        console.log('⏳ Waiting for transitions...');
        await new Promise(resolve => setTimeout(resolve, 500));
        
        console.log('⏳ Waiting for container to be ready...');
        await this.waitForContainer();
        
        const finalCheck = this.verifyContainerDimensions();
        if (!finalCheck.valid) {
            console.error('❌ Container still invalid after wait:', finalCheck);
            throw new Error(`Container dimensions still invalid: ${finalCheck.width}x${finalCheck.height}`);
        }
        
        console.log('🎼 Proceeding with score loading...');
        await this.loadScoreInContainer(xmlContent, file.name);
        this.currentFile = file;
        
    } catch (error) {
        console.error('❌ Error selecting file:', error);
        this.showUserErrorMessage(`Errore nel caricare il file: ${error.message}`);
    }
}
```

**Fix 4: Aggiungi metodo di verifica** (dopo `selectFile()`):
```javascript
verifyContainerDimensions() {
    const container = document.getElementById('osmd-container');
    if (!container) {
        return { valid: false, error: 'Container not found', width: 0, height: 0 };
    }
    
    const rect = container.getBoundingClientRect();
    const valid = rect.width > 100 && rect.height > 100;
    
    return {
        valid,
        width: rect.width,
        height: rect.height,
        error: valid ? null : `Dimensions too small: ${rect.width}x${rect.height}`
    };
}

showUserErrorMessage(message) {
    const scoreArea = document.getElementById('score-area') || document.body;
    
    const existingError = scoreArea.querySelector('.user-error-message');
    if (existingError) {
        existingError.remove();
    }
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'user-error-message';
    errorDiv.style.cssText = `
        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        background: rgba(239, 68, 68, 0.95); color: white; padding: 20px 30px;
        border-radius: 12px; z-index: 9999; backdrop-filter: blur(10px);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3); text-align: center; max-width: 400px;
    `;
    
    errorDiv.innerHTML = `
        <div style="font-size: 24px; margin-bottom: 10px;">⚠️</div>
        <div style="font-weight: 600; margin-bottom: 10px;">Errore</div>
        <div style="font-size: 14px; margin-bottom: 15px;">${message}</div>
        <button onclick="this.parentElement.remove()" style="
            background: rgba(255, 255, 255, 0.2); border: 1px solid rgba(255, 255, 255, 0.3);
            color: white; padding: 8px 16px; border-radius: 6px; cursor: pointer;
        ">Chiudi</button>
    `;
    
    scoreArea.appendChild(errorDiv);
    
    setTimeout(() => {
        if (errorDiv.parentElement) {
            errorDiv.remove();
        }
    }, 10000);
}
```

## 🧪 Testing e Debug

### Console Commands:
```javascript
// Test completo del container
window.osmdDebugger.runFullTest()

// Quick fix per problemi di dimensioni
window.osmdDebugger.applyQuickFix()

// Debug stato corrente del player
window.player.debugOSMDStatus()

// Verifica dimensioni container
window.player.verifyContainerDimensions()
```

### CSS Debug:
```css
/* Aggiungi temporaneamente per debug visivo */
#osmd-container {
    border: 3px solid red !important;
    background: rgba(255, 0, 0, 0.1) !important;
}
```

## 📊 Monitoraggio

Dopo l'implementazione, monitora la console per questi messaggi:

✅ **Successo**:
- `✅ Container ready: 800x600`
- `🎉 Score loaded successfully!`
- `✅ Basic OSMD rendering successful`

❌ **Problemi persistenti**:
- `❌ Container still invalid after wait`
- `⏰ Container timeout, applying AGGRESSIVE fallback`
- `❌ Basic OSMD failed`

## 🔍 Troubleshooting Avanzato

Se i problemi persistono:

1. **Verifica la gerarchia HTML**:
   ```javascript
   document.querySelectorAll('#score-container, #osmd-container, #score-area').forEach(el => {
       console.log(el.id, window.getComputedStyle(el).display, el.getBoundingClientRect());
   });
   ```

2. **Test CSS inheritance**:
   ```javascript
   const container = document.getElementById('osmd-container');
   console.log('Parent styles:', Array.from(container.parentElement.classList));
   ```

3. **Force layout debugging**:
   ```javascript
   const container = document.getElementById('osmd-container');
   container.style.border = '5px solid blue';
   container.offsetHeight;
   console.log('Forced layout:', container.getBoundingClientRect());
   ```

## 🎯 Risultati Attesi

Dopo l'implementazione dovresti vedere:
- ✅ Eliminazione dell'errore "Container has invalid dimensions"
- ✅ Caricamento più affidabile dei file MusicXML
- ✅ Feedback migliore in caso di errori
- ✅ Debug più semplice dei problemi

## 📞 Supporto

Se hai ancora problemi:
1. Esegui `window.osmdDebugger.runFullTest()` nella console
2. Condividi l'output del test report
3. Verifica che tutti i fix siano stati applicati correttamente

---
*Fix implementato il: 13 Agosto 2025*  
*Versione: 1.0*  
*Compatibilità: OSMD 1.x, Browsers moderni*
