/**
 * FIX 1: Miglioramento del metodo waitForContainer()
 * Risolve il problema "Container has invalid dimensions"
 */

// Sostituisci il metodo waitForContainer esistente con questa versione migliorata:
async waitForContainer() {
    return new Promise((resolve) => {
        const container = document.getElementById('osmd-container');
        if (!container) {
            console.log('⚠️ Container not found, proceeding anyway');
            resolve();
            return;
        }

        let attempts = 0;
        const maxAttempts = 30; // Aumentato da 20 a 30 per più pazienza
        
        const checkContainer = () => {
            attempts++;
            
            // Force layout recalculation prima di controllare le dimensioni
            container.style.display = 'block';
            container.offsetHeight; // Force reflow
            
            const rect = container.getBoundingClientRect();
            const computedStyle = window.getComputedStyle(container);
            
            console.log(`⏳ Tentativo ${attempts}/${maxAttempts}:`, {
                width: rect.width,
                height: rect.height,
                display: computedStyle.display,
                visibility: computedStyle.visibility,
                opacity: computedStyle.opacity
            });
            
            // Controllo più robusto delle dimensioni
            const hasValidDimensions = rect.width > 100 && rect.height > 100; // Soglia più alta
            const isVisible = computedStyle.display !== 'none' && 
                            computedStyle.visibility !== 'hidden' && 
                            parseFloat(computedStyle.opacity) > 0;
            
            if (hasValidDimensions && isVisible) {
                console.log('✅ Container ready:', rect.width, 'x', rect.height);
                resolve();
            } else if (attempts >= maxAttempts) {
                console.log('⏰ Container timeout, applying AGGRESSIVE fallback...');
                
                // AGGRESSIVE FALLBACK: Force container to be visible and sized
                const scoreContainer = document.getElementById('score-container');
                if (scoreContainer) {
                    scoreContainer.style.display = 'block !important';
                    scoreContainer.style.visibility = 'visible !important';
                    scoreContainer.style.opacity = '1 !important';
                }
                
                // Force container dimensions with !important
                container.style.cssText = `
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                    width: 800px !important;
                    height: 600px !important;
                    min-width: 800px !important;
                    min-height: 600px !important;
                    background: white !important;
                    position: relative !important;
                    z-index: 1000 !important;
                `;
                
                // Multiple forced reflows
                container.offsetHeight;
                container.offsetWidth;
                document.body.offsetHeight;
                
                setTimeout(() => {
                    console.log('🔧 Forced dimensions applied, proceeding...');
                    resolve();
                }, 100);
            } else {
                setTimeout(checkContainer, 100); // Aumentato da 50ms a 100ms
            }
        };

        // Start checking after ensuring parent containers are visible
        this.ensureParentContainersVisible();
        setTimeout(checkContainer, 200); // Aumentato delay iniziale
    });
}

// Nuovo metodo helper per assicurarsi che tutti i container parent siano visibili
ensureParentContainersVisible() {
    const containers = [
        'score-container',
        'score-area', 
        'main-content',
        'content-wrapper'
    ];
    
    containers.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            const style = window.getComputedStyle(element);
            if (style.display === 'none' || style.visibility === 'hidden') {
                console.log(`🔧 Making ${id} visible`);
                element.style.display = 'block';
                element.style.visibility = 'visible';
                element.style.opacity = '1';
            }
        }
    });
    
    // Force a full layout recalculation
    document.body.offsetHeight;
}


/**
 * FIX 2: Miglioramento del metodo selectFile() con debugging avanzato
 */
async selectFile(file) {
    try {
        console.log('🎵 Loading file:', file.name);
        const xmlContent = await this.fetchFileContent(file);
        
        console.log('🔄 Starting container visibility sequence...');
        
        // Step 1: Hide welcome guide
        this.showWelcomeGuide(false);
        
        // Step 2: Show score container with explicit class toggle
        const scoreContainer = document.getElementById('score-container');
        if (scoreContainer) {
            scoreContainer.style.display = 'block';
            scoreContainer.classList.add('visible'); // Se usi classi CSS
            console.log('✅ Score container shown');
        }
        
        // Step 3: Force multiple layout recalculations
        document.body.offsetHeight;
        scoreContainer?.offsetHeight;
        
        // Step 4: Wait longer for CSS transitions
        console.log('⏳ Waiting for transitions...');
        await new Promise(resolve => setTimeout(resolve, 500)); // Aumentato da 200ms
        
        // Step 5: Debug container state prima di procedere
        this.debugContainerState();
        
        // Step 6: Wait for container with improved method
        console.log('⏳ Waiting for container to be ready...');
        await this.waitForContainer();
        
        // Step 7: Double-check container state
        const finalCheck = this.verifyContainerDimensions();
        if (!finalCheck.valid) {
            console.error('❌ Container still invalid after wait:', finalCheck);
            throw new Error(`Container dimensions still invalid: ${finalCheck.width}x${finalCheck.height}`);
        }
        
        // Step 8: Proceed with loading
        console.log('🎼 Proceeding with score loading...');
        await this.loadScoreInContainer(xmlContent, file.name);
        this.currentFile = file;
        
    } catch (error) {
        console.error('❌ Error selecting file:', error);
        // Fallback: mostra messaggio di errore user-friendly
        this.showUserErrorMessage(`Errore nel caricare il file: ${error.message}`);
    }
}

/**
 * FIX 3: Nuovo metodo per debug dettagliato dello stato del container
 */
debugContainerState() {
    console.log('🔍 === DEBUG CONTAINER STATE ===');
    
    const elements = [
        'score-container',
        'osmd-container', 
        'score-area',
        'main-content'
    ];
    
    elements.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            const rect = element.getBoundingClientRect();
            const style = window.getComputedStyle(element);
            
            console.log(`📐 ${id}:`, {
                dimensions: `${rect.width}x${rect.height}`,
                display: style.display,
                visibility: style.visibility,
                opacity: style.opacity,
                position: style.position,
                zIndex: style.zIndex
            });
        } else {
            console.log(`❌ ${id}: NOT FOUND`);
        }
    });
    
    console.log('🔍 === END DEBUG ===');
}

/**
 * FIX 4: Metodo per verificare le dimensioni del container
 */
verifyContainerDimensions() {
    const container = document.getElementById('osmd-container');
    if (!container) {
        return { valid: false, error: 'Container not found', width: 0, height: 0 };
    }
    
    const rect = container.getBoundingClientRect();
    const valid = rect.width > 100 && rect.height > 100;
    
    return {
        valid,
        width: rect.width,
        height: rect.height,
        error: valid ? null : `Dimensions too small: ${rect.width}x${rect.height}`
    };
}

/**
 * FIX 5: Messaggio di errore user-friendly
 */
showUserErrorMessage(message) {
    const scoreArea = document.getElementById('score-area') || document.body;
    
    // Rimuovi eventuali messaggi di errore precedenti
    const existingError = scoreArea.querySelector('.user-error-message');
    if (existingError) {
        existingError.remove();
    }
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'user-error-message';
    errorDiv.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(239, 68, 68, 0.95);
        color: white;
        padding: 20px 30px;
        border-radius: 12px;
        z-index: 9999;
        backdrop-filter: blur(10px);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        text-align: center;
        max-width: 400px;
    `;
    
    errorDiv.innerHTML = `
        <div style="font-size: 24px; margin-bottom: 10px;">⚠️</div>
        <div style="font-weight: 600; margin-bottom: 10px;">Errore</div>
        <div style="font-size: 14px; margin-bottom: 15px;">${message}</div>
        <button onclick="this.parentElement.remove()" style="
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
        ">Chiudi</button>
    `;
    
    scoreArea.appendChild(errorDiv);
    
    // Auto-remove after 10 seconds
    setTimeout(() => {
        if (errorDiv.parentElement) {
            errorDiv.remove();
        }
    }, 10000);
}
