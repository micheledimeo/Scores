// 🧪 MUSICXML PLAYER v2.1 - TEST SCRIPT
// Esegui questo nella console del browser dopo il caricamento

console.log('🧪 === MUSICXML PLAYER v2.1 DIAGNOSTIC TEST ===');

// Test 1: Verifica inizializzazione player
console.log('\n1️⃣ TESTING PLAYER INITIALIZATION...');
const playerExists = !!window.player;
const playerState = window.player ? window.player.getPlaybackState() : null;

console.log('✓ Player available:', playerExists ? '✅ YES' : '❌ NO');
if (playerState) {
    console.log('✓ Player initialized:', playerState.isInitialized ? '✅ YES' : '❌ NO');
    console.log('✓ Current file:', playerState.currentFile || '❌ None');
    console.log('✓ OSMD instance:', playerState.hasOSMD ? '✅ YES' : '❌ NO');
    console.log('✓ Playback controls:', playerState.hasControls ? '✅ YES' : '❌ NO');
}

// Test 2: Verifica container DOM
console.log('\n2️⃣ TESTING DOM CONTAINERS...');
const scoreContainer = document.getElementById('score-container');
const osmdContainer = document.getElementById('osmd-container');
const renderArea = document.getElementById('osmd-render-area');

console.log('✓ Score container:', scoreContainer ? '✅ EXISTS' : '❌ NOT FOUND');
console.log('✓ OSMD container:', osmdContainer ? '✅ EXISTS' : '❌ NOT FOUND');
console.log('✓ Render area:', renderArea ? '✅ EXISTS' : '❌ NOT FOUND');

if (renderArea) {
    const rect = renderArea.getBoundingClientRect();
    console.log('✓ Render dimensions:', rect.width + 'x' + rect.height);
    console.log('✓ Dimensions valid:', (rect.width > 0 && rect.height > 0) ? '✅ YES' : '❌ NO');
}

// Test 3: Verifica controlli playback
console.log('\n3️⃣ TESTING PLAYBACK CONTROLS...');
const controls = document.querySelector('.playback-controls-fixed');
const playButton = controls ? controls.querySelector('button') : null;

console.log('✓ Controls container:', controls ? '✅ FOUND' : '❌ NOT FOUND');
console.log('✓ Play button:', playButton ? '✅ FOUND' : '❌ NOT FOUND');

if (controls) {
    const controlsRect = controls.getBoundingClientRect();
    const isVisible = controlsRect.width > 0 && controlsRect.height > 0;
    console.log('✓ Controls visible:', isVisible ? '✅ YES' : '❌ NO');
    console.log('✓ Controls position:', Math.round(controlsRect.left) + ',' + Math.round(controlsRect.top));
}

// Test 4: Verifica librerie OSMD
console.log('\n4️⃣ TESTING OSMD LIBRARIES...');
const osmdLib = typeof window.opensheetmusicdisplay !== 'undefined';
const osmdPlayback = typeof window.OSMDPlaybackEngine !== 'undefined';

console.log('✓ OSMD Library:', osmdLib ? '✅ LOADED' : '❌ NOT LOADED');
console.log('✓ OSMD Playback:', osmdPlayback ? '✅ LOADED' : '❌ NOT LOADED');

// Test 5: Test emergency fix se necessario
console.log('\n5️⃣ EMERGENCY FIXES...');

if (!playerExists) {
    console.log('🚨 EMERGENCY: Creating player instance...');
    try {
        window.player = new MusicXMLPlayer();
        window.player.init();
        console.log('✅ Emergency player created');
    } catch (error) {
        console.error('❌ Emergency player failed:', error.message);
    }
}

if (renderArea && renderArea.getBoundingClientRect().width === 0) {
    console.log('🚨 EMERGENCY: Fixing render area dimensions...');
    renderArea.style.width = '760px';
    renderArea.style.height = '500px';
    renderArea.style.minWidth = '760px';
    renderArea.style.minHeight = '500px';
    renderArea.style.display = 'block';
    renderArea.offsetHeight; // Force reflow
    
    const newRect = renderArea.getBoundingClientRect();
    console.log('✅ Emergency fix applied:', newRect.width + 'x' + newRect.height);
}

if (!controls && window.player && osmdContainer) {
    console.log('🚨 EMERGENCY: Adding missing playback controls...');
    try {
        window.player.addPlaybackControls();
        console.log('✅ Emergency controls added');
    } catch (error) {
        console.error('❌ Emergency controls failed:', error.message);
    }
}

// Final Status
console.log('\n🎯 === FINAL STATUS ===');
const finalPlayer = !!window.player;
const finalControls = !!document.querySelector('.playback-controls-fixed');
const finalRenderArea = document.getElementById('osmd-render-area');
const finalDimensions = finalRenderArea ? finalRenderArea.getBoundingClientRect() : {width: 0, height: 0};

console.log('🎼 Player Ready:', finalPlayer ? '✅' : '❌');
console.log('🎮 Controls Ready:', finalControls ? '✅' : '❌');  
console.log('📏 Render Area:', (finalDimensions.width > 0 && finalDimensions.height > 0) ? '✅ ' + finalDimensions.width + 'x' + finalDimensions.height : '❌ Invalid');

const allGreen = finalPlayer && finalControls && finalDimensions.width > 0;
console.log('\n🚀 OVERALL STATUS:', allGreen ? '✅ ALL SYSTEMS GO!' : '❌ ISSUES DETECTED');

if (allGreen) {
    console.log('\n🎉 Ready to load and play MusicXML files!');
    console.log('💡 Select a file from the library to test rendering.');
} else {
    console.log('\n🔧 Some issues detected. Check individual test results above.');
}

console.log('\n🧪 === END DIAGNOSTIC TEST ===');
