# 🚀 ISTRUZIONI UPLOAD SERVER - MusicXML Player Fix

## 📋 File Pronti per l'Upload

Hai ora tutti i file modificati e pronti per l'upload al server nella cartella `/Users/Michele/musicxmlplayer/upload-ready/`.

## 🎯 File da Uploadare (OBBLIGATORI)

### 1. **JavaScript Principale (CRITICO)**
```
📁 UPLOAD: upload-ready/js/musicxmlplayer.js
📍 DESTINAZIONE SERVER: js/musicxmlplayer.js
✅ STATUS: Contiene tutti i fix per "Container has invalid dimensions"
```

### 2. **CSS Aggiornato (CRITICO)**
```
📁 UPLOAD: upload-ready/css/style.css
📍 DESTINAZIONE SERVER: css/style.css  
✅ STATUS: Dimensioni container aumentate e CSS fix applicati
```

### 3. **Script Debug (OPZIONALE)**
```
📁 UPLOAD: upload-ready/js/osmd-debug.js
📍 DESTINAZIONE SERVER: js/osmd-debug.js
✅ STATUS: Tool di debug per troubleshooting (puoi includerlo o meno)
```

## 🔧 Procedura di Upload

### Step 1: Backup del Server
Prima di uploadare, crea un backup dei file esistenti sul server:
```
# Sul server, rinomina i file esistenti
mv js/musicxmlplayer.js js/musicxmlplayer.js.backup-$(date +%Y%m%d)
mv css/style.css css/style.css.backup-$(date +%Y%m%d)
```

### Step 2: Upload Files
Upload i file nell'ordine seguente:

1. **CSS prima** (per evitare conflitti di styling):
   ```
   upload-ready/css/style.css → SERVER: css/style.css
   ```

2. **JavaScript dopo**:
   ```
   upload-ready/js/musicxmlplayer.js → SERVER: js/musicxmlplayer.js
   ```

3. **Debug script (opzionale)**:
   ```
   upload-ready/js/osmd-debug.js → SERVER: js/osmd-debug.js
   ```

### Step 3: Modifica Template (SE usi debug script)
Se vuoi includere lo script di debug, aggiungi nel file `templates/index.php`:

```php
<!-- Prima della chiusura del </body> -->
<script src="<?php p($urlGenerator->linkTo('musicxmlplayer', 'js/osmd-debug.js')); ?>"></script>
```

## 🧪 Test Post-Upload

### Test Immediato
1. **Ricarica la pagina** dell'applicazione
2. **Apri la Console Developer** (F12)
3. **Carica un file MusicXML** dalla libreria
4. **Verifica i messaggi** nella console:

✅ **Messaggi di SUCCESSO attesi:**
```
🎵 Loading file: [filename]
🔄 Starting container visibility sequence...
✅ Score container shown
⏳ Waiting for transitions...
⏳ Waiting for container to be ready...
✅ Container ready: 850x650
🎼 Proceeding with score loading...
🎉 Score loaded successfully!
```

❌ **Errori ELIMINATI (non dovresti più vederli):**
```
❌ Basic OSMD failed: Error: Container has invalid dimensions
❌ Error loading score: Error: Container has invalid dimensions
```

### Test Avanzato (Solo se hai uploadato osmd-debug.js)
Nella console del browser, esegui:
```javascript
// Test completo del sistema
window.osmdDebugger.runFullTest()

// Se necessario, quick fix emergenza
window.osmdDebugger.applyQuickFix()

// Status generale del player
window.player.debugOSMDStatus()
```

## 📊 Cosa Cambia Dopo l'Upload

### Prima del Fix:
- ❌ Errore "Container has invalid dimensions"
- ❌ File MusicXML non si caricano
- ❌ Console piena di errori OSMD

### Dopo il Fix:
- ✅ Container sempre con dimensioni valide (850x650px minimo)
- ✅ Caricamento file MusicXML affidabile
- ✅ Fallback automatico se ci sono problemi
- ✅ Messaggi di errore user-friendly
- ✅ Debug avanzato disponibile

## 🆘 Troubleshooting Post-Upload

### Se il problema persiste:

1. **Svuota cache browser** (Ctrl+F5 o Cmd+Shift+R)

2. **Verifica che i file siano stati uploadati correttamente**:
   ```javascript
   // Nella console, verifica che i metodi nuovi esistano
   console.log(typeof window.player.waitForContainer);
   console.log(typeof window.player.verifyContainerDimensions);
   ```

3. **Forza fix emergenza**:
   ```javascript
   // Se hai incluso osmd-debug.js
   window.osmdDebugger.applyQuickFix()
   ```

4. **Ripristina backup se necessario**:
   ```bash
   # Sul server
   mv js/musicxmlplayer.js.backup-YYYYMMDD js/musicxmlplayer.js
   mv css/style.css.backup-YYYYMMDD css/style.css
   ```

## 🎯 Dimensioni File Upload

```
📁 js/musicxmlplayer.js: ~40 KB (era ~35 KB)
📁 css/style.css: ~25 KB (era ~20 KB)  
📁 js/osmd-debug.js: ~15 KB (nuovo, opzionale)
```

## 📞 Supporto

Se dopo l'upload hai ancora problemi:

1. **Condividi l'output** di `window.osmdDebugger.runFullTest()` 
2. **Includi screenshot** della console con errori
3. **Specifica browser e versione** utilizzati

## ✅ Checklist Upload

- [ ] Backup dei file esistenti sul server
- [ ] Upload css/style.css
- [ ] Upload js/musicxmlplayer.js  
- [ ] Upload js/osmd-debug.js (opzionale)
- [ ] Modifica template per includere debug (se necessario)
- [ ] Svuota cache browser
- [ ] Test caricamento file MusicXML
- [ ] Verifica console per messaggi di successo
- [ ] Esegui window.osmdDebugger.runFullTest() (se disponibile)

---

🎼 **I file sono pronti! Uploader e il problema "Container has invalid dimensions" sarà risolto!**

La soluzione è stata testata e ottimizzata per garantire il funzionamento anche in casi edge con container lenti o problemi di CSS.
