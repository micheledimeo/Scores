<?php
$TRANSLATIONS = array(
    "MusicXML Player" => "MusicXML Player",
    "Play MusicXML files directly in Nextcloud" => "Play MusicXML files directly in Nextcloud",
    "Error loading MusicXML files" => "Error loading MusicXML files",
    "Error loading MusicXML file" => "Error loading MusicXML file",
    "Error rendering score" => "Error rendering score",
    "No file loaded" => "No file loaded",
    "MIDI exported successfully" => "MIDI exported successfully",
    "Error exporting MIDI" => "Error exporting MIDI",
    "Loading score..." => "Loading score...",
    "Tempo" => "Tempo",
    "Volume" => "Volume",
    "Loop" => "Loop",
    "Metronome" => "Metronome",
    "Export MIDI" => "Export MIDI",
    "Refresh" => "Refresh"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";