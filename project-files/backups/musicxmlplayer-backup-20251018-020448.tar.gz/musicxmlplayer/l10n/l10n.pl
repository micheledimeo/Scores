#!/usr/bin/env perl
use strict;
use warnings;

print "<?php\n";
print "\$TRANSLATIONS = array(\n";

my @files = glob("templates/*.php lib/**/*.php");
my %strings;

foreach my $file (@files) {
    open(my $fh, '<', $file) or next;
    while (my $line = <$fh>) {
        while ($line =~ /\bt\s*\(\s*['"]musicxmlplayer['"]\s*,\s*['"]([^'"]+)['"]\s*\)/g) {
            $strings{$1} = 1;
        }
    }
    close($fh);
}

foreach my $string (sort keys %strings) {
    print "    \"$string\" => \"$string\",\n";
}

print ");\n";
print "\$PLURAL_FORMS = \"nplurals=2; plural=(n != 1);\";\n";