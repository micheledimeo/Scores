<?php

declare(strict_types=1);

namespace OCA\FlatioPlayer\AppInfo;

use OCP\AppFramework\App;
use OCP\AppFramework\Bootstrap\IRegistrationContext;
use OCP\AppFramework\Bootstrap\IBootContext;
use OCP\AppFramework\Bootstrap\IBootstrap;
use Psr\Log\LoggerInterface;

/**
 * Flat.io Player Application Bootstrap
 * 
 * Auto-installation and configuration system for Nextcloud 31.0.7
 * with automatic owner detection and permission setup.
 */
class Application extends App implements IBootstrap {
    public const APP_ID = 'flatioplayer';
    public const APP_VERSION = '1.0.0';

    public function __construct(array $urlParams = []) {
        parent::__construct(self::APP_ID, $urlParams);
    }

    public function register(IRegistrationContext $context): void {
        // Register navigation entry
        $context->registerNavigationEntry(function () {
            return [
                'id' => self::APP_ID,
                'order' => 75,
                'name' => 'Flat.io Player',
                'href' => \OC::$server->getURLGenerator()->linkToRoute('flatioplayer.page.index'),
                'icon' => \OC::$server->getURLGenerator()->imagePath(self::APP_ID, 'app.svg'),
            ];
        });

        // Register CSP policy for Flat.io embed
        $context->registerContentSecurityPolicyProvider(\OCA\FlatioPlayer\Service\CSPProvider::class);

        // Register app enable/disable hooks
        $context->registerEventListener(\OCP\App\Events\AppEnableEvent::class, \OCA\FlatioPlayer\Listener\AppEnableListener::class);
        
        // Register OCC command for manual installation
        $context->registerCommand(\OCA\FlatioPlayer\Command\InstallCommand::class);
    }

    public function boot(IBootContext $context): void {
        // Application boot logic - optimized for performance
        $serverContainer = $context->getServerContainer();
        
        // Only initialize when actually needed (lazy loading)
        if ($this->isAppRequest()) {
            $this->initializeApp($serverContainer);
        }
    }

    /**
     * Check if current request is for this app
     */
    private function isAppRequest(): bool {
        $request = \OC::$server->getRequest();
        $pathInfo = $request->getPathInfo();
        
        return str_starts_with($pathInfo, '/apps/' . self::APP_ID);
    }

    /**
     * Initialize app-specific services
     */
    private function initializeApp(\OCP\IServerContainer $container): void {
        // Add any app-specific initialization here
        // This only runs when the app is actually being used
    }

    /**
     * Auto-installation system triggered on app enable
     */
    public static function runAutoInstallation(): void {
        $logger = \OC::$server->get(LoggerInterface::class);
        
        try {
            $logger->info('Flat.io Player: Starting auto-installation', ['app' => self::APP_ID]);
            
            // Use centralized installation service
            $installationService = new \OCA\FlatioPlayer\Service\InstallationService($logger);
            
            // Detect installation info
            $installInfo = $installationService->detectInstallationInfo();
            $logger->info('Flat.io Player: Installation info detected', [
                'app' => self::APP_ID,
                'path' => $installInfo['nextcloud_path'],
                'owner' => $installInfo['owner'],
                'group' => $installInfo['group']
            ]);
            
            // Set correct permissions
            $installationService->setupPermissions($installInfo);
            
            // Create app directories if needed
            $installationService->setupDirectories($installInfo);
            
            // Verify installation
            if ($installationService->verifyInstallation($installInfo)) {
                $logger->info('Flat.io Player: Auto-installation completed successfully', ['app' => self::APP_ID]);
            } else {
                $logger->warning('Flat.io Player: Auto-installation verification failed', ['app' => self::APP_ID]);
            }
            
        } catch (\Exception $e) {
            $logger->error('Flat.io Player: Auto-installation failed: ' . $e->getMessage(), [
                'app' => self::APP_ID,
                'exception' => $e
            ]);
        }
    }
}
