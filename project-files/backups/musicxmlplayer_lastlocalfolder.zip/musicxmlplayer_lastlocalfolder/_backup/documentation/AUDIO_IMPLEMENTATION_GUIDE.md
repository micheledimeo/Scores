# 🔊 AUDIO REALE - GUIDA IMPLEMENTAZIONE COMPLETA

## 🎯 **OBIETTIVO**
Trasformare il MusicXML Player da **"Visual Mode"** a **"Audio Mode"** con riproduzione audio reale delle note.

## 📋 **PREREQUISITI IMPLEMENTATI**
✅ **Web Audio API** integration pronta  
✅ **OSMD PlaybackManager** detection implementata  
✅ **AudioContext** management automatico  
✅ **Dual-mode system** (Audio/Visual) funzionante  
✅ **Error handling** robusto per fallback  

## 🛠️ **STEP 1: SOUNDFONT SETUP**

### **1.1 Download SoundFont**
```bash
# SoundFont consigliati (gratis):
wget https://musescore.org/sites/musescore.org/files/general_user_gs_v1.471.sf2
# O alternative:
# FluidR3_GM.sf2 (28MB) - Qualità media
# GeneralUser_GS_v1.471.sf2 (30MB) - Ottima qualità
# Timbres_Of_Heaven_v3.94.sf2 (208MB) - Qualità professionale
```

### **1.2 Upload sul Server**
```bash
# Creare directory per sounds
mkdir -p /path/to/nextcloud/apps/musicxmlplayer/sounds/

# Upload SoundFont
cp general_user_gs_v1.471.sf2 /path/to/nextcloud/apps/musicxmlplayer/sounds/
chmod 644 /path/to/nextcloud/apps/musicxmlplayer/sounds/*.sf2
```

### **1.3 Configurazione Path**
Aggiornare il path in `initializeOSMDPlayback()`:
```javascript
// In musicxmlplayer.js, riga ~540
this.workingOSMD.PlaybackManager.initialize({
    scoreFollowingMode: true,
    audioContext: this.audioContext,
    soundfontUrl: '/apps/musicxmlplayer/sounds/general_user_gs_v1.471.sf2',
    audioWorkletPath: '/apps/musicxmlplayer/js/osmd-audio-worklet.js'
});
```

## 🛠️ **STEP 2: AUDIO WORKLET**

### **2.1 Creare Audio Worklet File**
```bash
# Creare: /path/to/nextcloud/apps/musicxmlplayer/js/osmd-audio-worklet.js
```

**Contenuto del file:**
```javascript
// osmd-audio-worklet.js
class OSMDAudioProcessor extends AudioWorkletProcessor {
    constructor() {
        super();
        this.bufferSize = 128;
    }
    
    process(inputs, outputs, parameters) {
        const output = outputs[0];
        const input = inputs[0];
        
        // Simple passthrough for now
        if (input.length > 0) {
            for (let channel = 0; channel < output.length; ++channel) {
                output[channel].set(input[channel]);
            }
        }
        
        return true;
    }
}

registerProcessor('osmd-audio-processor', OSMDAudioProcessor);
```

### **2.2 Permissions e CORS**
```bash
# Assicurarsi che i file siano servibili
chmod 644 /path/to/nextcloud/apps/musicxmlplayer/js/osmd-audio-worklet.js

# In Apache/Nginx, aggiungere header CORS per .js files se necessario
# Apache (.htaccess):
# Header set Access-Control-Allow-Origin "*"
# Header set Access-Control-Allow-Headers "Content-Type"
```

## 🛠️ **STEP 3: OSMD PLAYBACK ENGINE UPDATE**

### **3.1 Verifica Versione OSMD**
Controllare che `opensheetmusicdisplay.min.js` includa PlaybackManager:
```javascript
// Test in console browser:
console.log(window.opensheetmusicdisplay.PlaybackManager ? 'AVAILABLE' : 'NOT AVAILABLE');
```

### **3.2 Update OSMD se Necessario**
Se PlaybackManager non è disponibile:
```bash
# Download ultima versione OSMD con playback:
wget https://github.com/opensheetmusicdisplay/opensheetmusicdisplay/releases/latest/download/opensheetmusicdisplay.min.js

# Replace nel progetto:
cp opensheetmusicdisplay.min.js /path/to/nextcloud/apps/musicxmlplayer/js/
```

## 🛠️ **STEP 4: ENHANCED INITIALIZATION**

### **4.1 Modificare initializeOSMDPlayback()**
Aggiornare il metodo nel file `musicxmlplayer.js`:

```javascript
async initializeOSMDPlayback() {
    try {
        console.log('🎼 Initializing OSMD Playback Engine...');
        
        // Check if OSMD has playback capabilities
        if (this.workingOSMD && window.opensheetmusicdisplay.PlaybackManager) {
            // Initialize the PlaybackManager
            this.workingOSMD.PlaybackManager = new window.opensheetmusicdisplay.PlaybackManager();
            
            // Set up audio context with user gesture requirement
            if (!this.audioContext) {
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                
                // Resume audio context if suspended (browser policy)
                if (this.audioContext.state === 'suspended') {
                    await this.audioContext.resume();
                }
            }
            
            // Load audio worklet
            try {
                await this.audioContext.audioWorklet.addModule('/apps/musicxmlplayer/js/osmd-audio-worklet.js');
                console.log('✅ Audio worklet loaded');
            } catch (error) {
                console.warn('⚠️ Audio worklet failed to load:', error);
            }
            
            // Initialize playback with enhanced configuration
            await this.workingOSMD.PlaybackManager.initialize({
                scoreFollowingMode: true,
                audioContext: this.audioContext,
                soundfontUrl: '/apps/musicxmlplayer/sounds/general_user_gs_v1.471.sf2',
                masterVolume: this.currentVolume / 100,
                bpm: this.currentTempo,
                enableCursor: true,
                cursorColor: '#ef4444'
            });
            
            console.log('✅ OSMD Playback Engine initialized with audio');
            return true;
        }
    } catch (error) {
        console.warn('⚠️ OSMD Playback initialization failed:', error);
    }
    return false;
}
```

## 🛠️ **STEP 5: BROWSER COMPATIBILITY**

### **5.1 User Gesture Requirement**
Aggiornare `startPlayback()` per gestire il requisito user gesture:

```javascript
async startPlayback(playButton) {
    console.log('▶️ Starting playback...');
    
    // Ensure audio context is running (user gesture requirement)
    if (this.audioContext && this.audioContext.state === 'suspended') {
        try {
            await this.audioContext.resume();
            console.log('🔊 Audio context resumed');
        } catch (error) {
            console.warn('⚠️ Could not resume audio context:', error);
        }
    }
    
    // Try to initialize OSMD Playback first
    if (this.workingOSMD && !this.workingOSMD.PlaybackManager) {
        await this.initializeOSMDPlayback();
    }
    
    // Check if OSMD Playback Engine is available and configured
    if (this.workingOSMD && this.workingOSMD.PlaybackManager) {
        try {
            console.log('🎵 Starting OSMD audio playback');
            await this.workingOSMD.PlaybackManager.play();
            this.isPlaying = true;
            playButton.innerHTML = '⏸️';
            this.statusDisplay.textContent = 'Playing (Audio)';
            this.statusDisplay.style.color = '#22c55e';
            this.startOSMDPositionTracking();
            return;
        } catch (error) {
            console.warn('⚠️ OSMD PlaybackManager failed:', error);
            console.log('📄 Falling back to visual playback mode');
        }
    }
    
    // Fallback: Visual playback mode
    this.simulatePlayback(playButton);
}
```

## 🛠️ **STEP 6: TESTING PROCEDURE**

### **6.1 Test Checklist**
```bash
✅ SoundFont file uploaded e accessibile
✅ Audio worklet file disponibile
✅ OSMD library con PlaybackManager
✅ CORS headers configurati se necessario
✅ Browser supporta Web Audio API
✅ HTTPS attivo (requisito per audio)
```

### **6.2 Debug Console Commands**
```javascript
// Test in browser console:

// 1. Verificare Web Audio API
console.log('Web Audio API:', !!window.AudioContext || !!window.webkitAudioContext);

// 2. Verificare OSMD PlaybackManager
console.log('OSMD PlaybackManager:', !!window.opensheetmusicdisplay?.PlaybackManager);

// 3. Test AudioContext
const ctx = new AudioContext();
console.log('AudioContext state:', ctx.state);

// 4. Test SoundFont accessibility
fetch('/apps/musicxmlplayer/sounds/general_user_gs_v1.471.sf2')
  .then(r => console.log('SoundFont accessible:', r.ok))
  .catch(e => console.log('SoundFont error:', e));

// 5. Test player state
console.log('Player state:', window.player?.getPlaybackState());
```

## 🚨 **TROUBLESHOOTING COMMON ISSUES**

### **Issue 1: "AudioContext suspended"**
```javascript
// Soluzione: User gesture required
// Il browser richiede interazione utente prima di audio
// ✅ Già implementato in startPlayback()
```

### **Issue 2: "SoundFont 404 not found"**
```bash
# Check path e permissions:
ls -la /path/to/nextcloud/apps/musicxmlplayer/sounds/
curl -I https://yourserver/apps/musicxmlplayer/sounds/general_user_gs_v1.471.sf2
```

### **Issue 3: "PlaybackManager undefined"**
```bash
# Update OSMD library:
# Scarica versione con playback support
# Verificare dimensioni file: deve essere > 2MB
```

### **Issue 4: "CORS policy error"**
```bash
# Apache .htaccess in js/ directory:
Header set Access-Control-Allow-Origin "*"
Header set Access-Control-Allow-Methods "GET, POST, OPTIONS"
Header set Access-Control-Allow-Headers "Content-Type"
```

## 📊 **RISULTATO ATTESO**

### **Dopo Implementazione Completa:**
```
Console Log:
🎼 Initializing OSMD Playback Engine...
✅ Audio worklet loaded
✅ OSMD Playback Engine initialized with audio
▶️ Starting playback...
🔊 Audio context resumed  
🎵 Starting OSMD audio playback
Status: "Playing (Audio)" (verde)
```

### **UI Changes:**
- ✅ Status cambia da **"Playing (Visual)"** a **"Playing (Audio)"**
- ✅ Colore status diventa **verde** invece di viola
- ✅ **Audio reale** suona dalle note del spartito
- ✅ **Cursore** segue la riproduzione audio
- ✅ **Timer** sincronizzato con audio OSMD

---

## 🎉 **RISULTATO FINALE**

Con questa implementazione, il **MusicXML Player v2.1** avrà:

🔊 **Audio reale** con SoundFont  
🎯 **Sincronizzazione** audio-visuale perfetta  
🎼 **Qualità audio** professionale  
⚡ **Performance** ottimizzate  
🌐 **Cross-browser** compatibility  
🎵 **Full OSMD** integration  

**Dal "Visual Mode" al "Audio Mode" completo!**

---

*Guida creata: 14 Agosto 2025*  
*Target: Audio playback reale*  
*Prerequisito: Visual playback funzionante*  
*Risultato: Audio + Visual synchronizzato*
