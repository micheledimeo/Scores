#!/bin/bash

# 🔧 OSMD Container Fix - Auto Installer
# Script per applicare automaticamente i fix al progetto MusicXML Player

echo "🎼 OSMD Container Fix - Auto Installer"
echo "====================================="

# Colori per output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funzione per logging colorato
log_info() { echo -e "${BLUE}ℹ️  $1${NC}"; }
log_success() { echo -e "${GREEN}✅ $1${NC}"; }
log_warning() { echo -e "${YELLOW}⚠️  $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }

# Verifica che siamo nella directory giusta
if [ ! -f "js/musicxmlplayer.js" ]; then
    log_error "File musicxmlplayer.js non trovato! Assicurati di essere nella directory del progetto."
    exit 1
fi

log_info "Progetto MusicXML Player trovato!"

# Creazione backup
log_info "Creazione backup dei file esistenti..."
mkdir -p _backup/fix-$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="_backup/fix-$(date +%Y%m%d-%H%M%S)"

cp js/musicxmlplayer.js "$BACKUP_DIR/"
cp css/style.css "$BACKUP_DIR/"
log_success "Backup creato in $BACKUP_DIR"

# Verifica se esistono i file di fix
if [ ! -f "js/musicxmlplayer-fix.js" ]; then
    log_error "File musicxmlplayer-fix.js non trovato! Assicurati di aver scaricato tutti i fix."
    exit 1
fi

log_info "Applicazione dei fix..."

# 1. Backup e patch del file JavaScript principale
log_info "Applicazione fix JavaScript..."

# Sostituisce il metodo waitForContainer
log_info "Aggiornamento metodo waitForContainer()..."
sed -i.bak '/async waitForContainer()/,/^    }$/c\
    async waitForContainer() {\
        return new Promise((resolve) => {\
            const container = document.getElementById('\''osmd-container'\'');\
            if (!container) {\
                console.log('\''⚠️ Container not found, proceeding anyway'\'');\
                resolve();\
                return;\
            }\
\
            let attempts = 0;\
            const maxAttempts = 30;\
            \
            const checkContainer = () => {\
                attempts++;\
                \
                container.style.display = '\''block'\'';\
                container.offsetHeight;\
                \
                const rect = container.getBoundingClientRect();\
                const computedStyle = window.getComputedStyle(container);\
                \
                const hasValidDimensions = rect.width > 100 && rect.height > 100;\
                const isVisible = computedStyle.display !== '\''none'\'' && \
                                computedStyle.visibility !== '\''hidden'\'' && \
                                parseFloat(computedStyle.opacity) > 0;\
                \
                if (hasValidDimensions && isVisible) {\
                    console.log('\''✅ Container ready:'\'', rect.width, '\''x'\'', rect.height);\
                    resolve();\
                } else if (attempts >= maxAttempts) {\
                    console.log('\''⏰ Container timeout, applying AGGRESSIVE fallback...'\'');\
                    \
                    const scoreContainer = document.getElementById('\''score-container'\'');\
                    if (scoreContainer) {\
                        scoreContainer.style.display = '\''block !important'\'';\
                        scoreContainer.style.visibility = '\''visible !important'\'';\
                        scoreContainer.style.opacity = '\''1 !important'\'';\
                    }\
                    \
                    container.style.cssText = `\
                        display: block !important;\
                        visibility: visible !important;\
                        opacity: 1 !important;\
                        width: 800px !important;\
                        height: 600px !important;\
                        min-width: 800px !important;\
                        min-height: 600px !important;\
                        background: white !important;\
                        position: relative !important;\
                        z-index: 1000 !important;\
                    `;\
                    \
                    container.offsetHeight;\
                    container.offsetWidth;\
                    document.body.offsetHeight;\
                    \
                    setTimeout(() => {\
                        console.log('\''🔧 Forced dimensions applied, proceeding...'\'');\
                        resolve();\
                    }, 100);\
                } else {\
                    setTimeout(checkContainer, 100);\
                }\
            };\
\
            this.ensureParentContainersVisible();\
            setTimeout(checkContainer, 200);\
        });\
    }' js/musicxmlplayer.js

log_success "Metodo waitForContainer() aggiornato"

# 2. Aggiunta CSS fix
log_info "Applicazione fix CSS..."
if [ -f "css/container-fix.css" ]; then
    echo "" >> css/style.css
    echo "/* === OSMD CONTAINER FIX - Auto-generated === */" >> css/style.css
    cat css/container-fix.css >> css/style.css
    log_success "CSS fix applicato"
else
    log_warning "File container-fix.css non trovato, saltando applicazione CSS"
fi

# 3. Aggiunta script di debug
log_info "Installazione script di debug..."
if [ -f "js/osmd-debug.js" ]; then
    log_success "Script di debug disponibile in js/osmd-debug.js"
else
    log_warning "Script di debug non trovato"
fi

# 4. Verifica template per inclusione dei nuovi file
log_info "Verifica template HTML..."
if grep -q "container-fix.css" templates/index.php; then
    log_success "CSS fix già incluso nel template"
else
    log_warning "Aggiungi manualmente nel template: <link rel=\"stylesheet\" href=\"css/container-fix.css\">"
fi

if grep -q "osmd-debug.js" templates/index.php; then
    log_success "Script debug già incluso nel template"
else
    log_info "Per includere lo script di debug, aggiungi nel template:"
    echo "    <script src=\"js/osmd-debug.js\"></script>"
fi

# 5. Test sintassi JavaScript
log_info "Verifica sintassi JavaScript..."
if command -v node &> /dev/null; then
    if node -c js/musicxmlplayer.js 2>/dev/null; then
        log_success "Sintassi JavaScript corretta"
    else
        log_error "Errore di sintassi JavaScript! Ripristinando backup..."
        cp "$BACKUP_DIR/musicxmlplayer.js" js/
        exit 1
    fi
else
    log_warning "Node.js non trovato, saltando verifica sintassi"
fi

# 6. Report finale
echo ""
echo "🎉 Fix applicati con successo!"
echo "=========================="
log_success "Backup salvato in: $BACKUP_DIR"
log_success "File JavaScript aggiornato"
log_success "CSS fix applicato"
log_info "Script debug disponibile"

echo ""
echo "📋 Prossimi passi:"
echo "1. Ricarica la pagina dell'applicazione"
echo "2. Testa il caricamento di un file MusicXML"
echo "3. Se ci sono problemi, esegui in console: window.osmdDebugger.runFullTest()"
echo "4. Per ripristinare il backup: cp $BACKUP_DIR/musicxmlplayer.js js/"

echo ""
echo "🧪 Comandi di debug disponibili:"
echo "• window.osmdDebugger.runFullTest() - Test completo"
echo "• window.osmdDebugger.applyQuickFix() - Fix rapido"
echo "• window.player.debugOSMDStatus() - Status del player"

echo ""
log_success "Installazione completata! 🎼"
