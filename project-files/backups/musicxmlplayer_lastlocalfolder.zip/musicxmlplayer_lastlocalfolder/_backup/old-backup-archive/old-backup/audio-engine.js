// Advanced Audio Engine with Virtual Instruments
class AdvancedAudioEngine {
    constructor() {
        this.context = null;
        this.instruments = new Map();
        this.mixer = null;
        this.transport = null;
        this.isPlaying = false;
        this.currentPosition = 0;
        this.totalDuration = 0;
        this.playbackRate = 1.0;
        this.currentNotes = [];
        this.scheduledEvents = [];
        this.onPositionChange = null;
        
        // Audio settings
        this.masterVolume = 0.7;
        this.reverbLevel = 0.2;
        
        this.initializeAudio();
    }

    async initializeAudio() {
        try {
            if (!window.Tone) {
                console.error('Tone.js not loaded');
                return;
            }

            await Tone.start();
            this.context = Tone.context;
            
            // Create master mixer
            this.createMasterMixer();
            
            // Initialize virtual instruments
            await this.initializeInstruments();
            
            // Setup transport
            this.setupTransport();
            
            console.log('🎹 Local Synthesized Piano Audio Engine initialized');
            
        } catch (error) {
            console.error('❌ Audio engine initialization failed:', error);
        }
    }

    createMasterMixer() {
        // Master reverb
        this.reverb = new Tone.Reverb({
            decay: 2,
            preDelay: 0.01,
            wet: this.reverbLevel
        }).toDestination();

        // Master compressor
        this.compressor = new Tone.Compressor({
            threshold: -24,
            ratio: 8,
            attack: 0.003,
            release: 0.1
        });

        // Master volume
        this.masterGain = new Tone.Gain(this.masterVolume);
        
        // Chain: instruments -> compressor -> reverb -> master -> destination
        this.compressor.connect(this.reverb);
        this.masterGain.connect(this.compressor);
        
        console.log('🎚️ Master mixer created');
    }

    async initializeInstruments() {
        // Piano Sintetizzato Locale - Nessun file esterno richiesto
        this.instruments.set('piano', {
            synth: new Tone.PolySynth(Tone.Synth, {
                oscillator: {
                    type: "triangle",
                    modulationType: "sine",
                    modulationIndex: 0.3,
                    harmonicity: 3.1
                },
                envelope: {
                    attack: 0.02,
                    decay: 0.1,
                    sustain: 0.3,
                    release: 1.2
                },
                filter: {
                    frequency: 4000,
                    Q: 1,
                    type: "lowpass"
                },
                filterEnvelope: {
                    attack: 0.01,
                    decay: 0.1,
                    sustain: 0.5,
                    release: 2
                }
            }),
            volume: new Tone.Gain(0.8),
            name: 'Synthesized Grand Piano'
        });

        // Connetti il piano al master mixer
        const piano = this.instruments.get('piano');
        piano.synth.connect(piano.volume);
        piano.volume.connect(this.masterGain);

        console.log('🎹 Synthesized Grand Piano loaded (no external files)');
    }

    setupTransport() {
        this.transport = Tone.Transport;
        
        // Transport events
        this.transport.on('start', () => {
            this.isPlaying = true;
            console.log('▶️ Playback started');
        });

        this.transport.on('stop', () => {
            this.isPlaying = false;
            this.stopAllNotes();
            console.log('⏹️ Playback stopped');
        });

        this.transport.on('pause', () => {
            this.isPlaying = false;
            this.stopAllNotes();
            console.log('⏸️ Playback paused');
        });

        // Position tracking
        this.startPositionTracking();
    }

    startPositionTracking() {
        const updatePosition = () => {
            if (this.isPlaying) {
                this.currentPosition = this.transport.seconds;
                if (this.onPositionChange) {
                    this.onPositionChange(this.currentPosition, this.totalDuration);
                }
            }
            requestAnimationFrame(updatePosition);
        };
        updatePosition();
    }

    // Load and parse MusicXML
    async loadScore(xmlContent) {
        try {
            const parser = new MusicXMLAudioParser();
            this.currentNotes = parser.parseXML(xmlContent);
            this.totalDuration = parser.getTotalDuration();
            
            // Clear previous events
            this.transport.cancel();
            this.scheduledEvents = [];
            
            // Schedule all notes
            this.scheduleNotes();
            
            console.log(`🎼 Score loaded: ${this.currentNotes.length} notes, ${this.totalDuration.toFixed(2)}s duration`);
            
            return {
                noteCount: this.currentNotes.length,
                duration: this.totalDuration,
                tempo: parser.tempo,
                timeSignature: parser.timeSignature,
                keySignature: parser.keySignature
            };
            
        } catch (error) {
            console.error('❌ Error loading score:', error);
            return null;
        }
    }

    scheduleNotes() {
        this.currentNotes.forEach(note => {
            if (note.type === 'note') {
                const instrument = this.selectInstrument(note);
                
                const event = this.transport.schedule(time => {
                    this.playNote(instrument, note, time);
                }, note.startTime);
                
                this.scheduledEvents.push(event);
            }
        });
        
        console.log(`📅 Scheduled ${this.scheduledEvents.length} note events`);
    }

    selectInstrument(note) {
        // Tutti gli spartiti usano sempre e solo il piano
        return 'piano';
    }

    playNote(instrumentName, note, time) {
        const instrument = this.instruments.get(instrumentName);
        if (!instrument) {
            console.warn(`Instrument ${instrumentName} not found`);
            return;
        }

        const frequency = Tone.Frequency(note.midi, "midi").toFrequency();
        const velocity = note.velocity / 127;
        
        try {
            // Per PolySynth non servono buffer - suona immediatamente
            instrument.synth.triggerAttackRelease(
                frequency,
                note.durationSeconds,
                time,
                velocity
            );
        } catch (error) {
            console.warn('Note playback error:', error.message);
        }
    }

    // Transport controls
    async play() {
        if (!this.isPlaying) {
            await Tone.start();
            this.transport.start();
        }
    }

    pause() {
        if (this.isPlaying) {
            this.transport.pause();
        }
    }

    stop() {
        this.transport.stop();
        this.transport.position = 0;
        this.currentPosition = 0;
    }

    seekTo(timeInSeconds) {
        const wasPlaying = this.isPlaying;
        this.transport.stop();
        this.transport.seconds = timeInSeconds;
        this.currentPosition = timeInSeconds;
        
        if (wasPlaying) {
            this.transport.start();
        }
    }

    // Audio controls
    setMasterVolume(volume) {
        this.masterVolume = Math.max(0, Math.min(1, volume));
        this.masterGain.gain.value = this.masterVolume;
    }

    setPianoVolume(volume) {
        const piano = this.instruments.get('piano');
        if (piano) {
            piano.volume.gain.value = Math.max(0, Math.min(1, volume));
        }
    }

    setInstrumentVolume(instrumentName, volume) {
        // Per compatibilità - reindirizza sempre al piano
        this.setPianoVolume(volume);
    }

    setTempo(bpm) {
        this.transport.bpm.value = bpm;
    }

    setReverbLevel(level) {
        this.reverbLevel = Math.max(0, Math.min(1, level));
        this.reverb.wet.value = this.reverbLevel;
    }

    // Utility
    stopAllNotes() {
        const piano = this.instruments.get('piano');
        if (piano && piano.synth.releaseAll) {
            piano.synth.releaseAll();
        }
    }

    getPlaybackInfo() {
        return {
            isPlaying: this.isPlaying,
            currentPosition: this.currentPosition,
            totalDuration: this.totalDuration,
            tempo: this.transport.bpm.value,
            masterVolume: this.masterVolume,
            instrument: 'Grand Piano',
            instrumentCount: 1
        };
    }

    // Cleanup
    dispose() {
        this.transport.cancel();
        this.stopAllNotes();
        
        const piano = this.instruments.get('piano');
        if (piano) {
            piano.synth.dispose();
            piano.volume.dispose();
        }
        
        this.reverb?.dispose();
        this.compressor?.dispose();
        this.masterGain?.dispose();
        
        console.log('🎹 Piano audio engine disposed');
    }
}

// Rendi la classe disponibile globalmente
window.AdvancedAudioEngine = AdvancedAudioEngine;
