// Professional Transport Controls
class TransportControls {
    constructor(audioEngine, osmdRenderer) {
        this.audioEngine = audioEngine;
        this.osmdRenderer = osmdRenderer;
        this.controlsContainer = null;
        this.progressBar = null;
        this.timeDisplay = null;
        this.tempoSlider = null;
        this.volumeSlider = null;
        this.playButton = null;
        this.isLooping = false;
        this.loopStart = 0;
        this.loopEnd = 0;
        
        // Playback cursor
        this.cursor = null;
        this.cursorPosition = 0;
        
        this.createControls();
        this.setupEventListeners();
    }

    createControls() {
        // Remove existing controls
        const existing = document.getElementById('transport-controls');
        if (existing) existing.remove();

        // Create main container - RESPONSIVE
        this.controlsContainer = document.createElement('div');
        this.controlsContainer.id = 'transport-controls';
        this.controlsContainer.style.cssText = `
            position: fixed !important;
            bottom: 10px !important;
            left: 50% !important;
            transform: translateX(-50%) !important;
            width: clamp(300px, 90vw, 1400px) !important;
            height: clamp(70px, 12vh, 90px) !important;
            background: linear-gradient(145deg, 
                rgba(15, 23, 42, 0.98) 0%, 
                rgba(30, 41, 59, 0.95) 50%, 
                rgba(51, 65, 85, 0.98) 100%) !important;
            backdrop-filter: blur(30px) saturate(1.5) !important;
            z-index: 10000 !important;
            display: flex !important;
            flex-direction: column !important;
            padding: clamp(8px, 2vh, 12px) clamp(15px, 3vw, 25px) !important;
            box-shadow: 
                0 -10px 40px rgba(0, 0, 0, 0.2),
                0 -2px 8px rgba(0, 0, 0, 0.1) !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            border-radius: 16px !important;
        `;

        // Progress section
        const progressSection = this.createProgressSection();
        
        // Controls section
        const controlsSection = this.createControlsSection();
        
        this.controlsContainer.appendChild(progressSection);
        this.controlsContainer.appendChild(controlsSection);
        
        document.body.appendChild(this.controlsContainer);
        
        console.log('🎛️ Professional transport controls created');
    }

    createProgressSection() {
        const section = document.createElement('div');
        section.style.cssText = `
            display: flex !important;
            align-items: center !important;
            gap: 12px !important;
            margin-bottom: 8px !important;
        `;

        // Current time
        this.timeDisplay = document.createElement('div');
        this.timeDisplay.className = 'time-display';
        this.timeDisplay.style.cssText = `
            color: white !important;
            font-family: 'SF Mono', 'Monaco', 'Courier New', monospace !important;
            font-size: 13px !important;
            font-weight: 600 !important;
            min-width: 100px !important;
            text-align: center !important;
            background: linear-gradient(145deg, 
                rgba(15, 23, 42, 0.8) 0%, 
                rgba(30, 41, 59, 0.6) 100%) !important;
            backdrop-filter: blur(10px) !important;
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
            border-radius: 8px !important;
            padding: 4px 10px !important;
            box-shadow: 
                0 2px 8px rgba(0, 0, 0, 0.1),
                inset 0 1px 0 rgba(255, 255, 255, 0.05) !important;
        `;
        this.timeDisplay.textContent = '00:00 / 00:00';

        // Progress bar container
        const progressContainer = document.createElement('div');
        progressContainer.style.cssText = `
            flex: 1 !important;
            position: relative !important;
            height: 8px !important;
            background: rgba(255, 255, 255, 0.1) !important;
            border-radius: 6px !important;
            cursor: pointer !important;
            margin: 0 10px !important;
            border: 1px solid rgba(255, 255, 255, 0.05) !important;
            box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1) !important;
        `;

        // Progress bar
        this.progressBar = document.createElement('div');
        this.progressBar.style.cssText = `
            height: 100% !important;
            background: linear-gradient(90deg, 
                #10b981 0%, 
                #34d399 50%, 
                #6ee7b7 100%) !important;
            border-radius: 6px !important;
            width: 0% !important;
            transition: width 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94) !important;
            box-shadow: 
                0 0 10px rgba(16, 185, 129, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.1) !important;
            position: relative !important;
        `;

        // Progress bar glow effect (smaller)
        const progressGlow = document.createElement('div');
        progressGlow.style.cssText = `
            position: absolute !important;
            top: -1px !important;
            right: -2px !important;
            width: 4px !important;
            height: 10px !important;
            background: radial-gradient(circle, rgba(16, 185, 129, 0.6) 0%, transparent 70%) !important;
            border-radius: 50% !important;
            filter: blur(1px) !important;
        `;
        
        this.progressBar.appendChild(progressGlow);

        progressContainer.appendChild(this.progressBar);

        // Progress click handler
        progressContainer.addEventListener('click', (e) => {
            const rect = progressContainer.getBoundingClientRect();
            const percentage = (e.clientX - rect.left) / rect.width;
            const seekTime = percentage * this.audioEngine.totalDuration;
            this.audioEngine.seekTo(seekTime);
        });

        section.appendChild(this.timeDisplay);
        section.appendChild(progressContainer);

        return section;
    }

    createControlsSection() {
        const section = document.createElement('div');
        section.style.cssText = `
            display: flex !important;
            align-items: center !important;
            justify-content: space-between !important;
            flex-wrap: wrap !important;
            gap: clamp(8px, 2vw, 15px) !important;
        `;

        // Transport buttons
        const transportGroup = this.createTransportButtons();
        
        // Tempo control
        const tempoGroup = this.createTempoControl();
        
        // Volume control  
        const volumeGroup = this.createVolumeControl();
        
        // Close button
        const closeGroup = this.createCloseButton();

        section.appendChild(transportGroup);
        section.appendChild(tempoGroup);
        section.appendChild(volumeGroup);
        section.appendChild(closeGroup);

        return section;
    }

    createTransportButtons() {
        const group = document.createElement('div');
        group.style.cssText = `
            display: flex !important;
            align-items: center !important;
            gap: 10px !important;
        `;

        // Stop button
        const stopBtn = this.createButton(`
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <rect x="6" y="6" width="12" height="12" rx="2"/>
            </svg>
        `, 'Stop', () => {
            this.audioEngine.stop();
            this.updatePlayButton(false);
        });

        // Play/Pause button (larger)
        this.playButton = this.createButton(`
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <polygon points="5,3 19,12 5,21"/>
            </svg>
        `, 'Play', async () => {
            if (this.audioEngine.isPlaying) {
                this.audioEngine.pause();
                this.updatePlayButton(false);
            } else {
                await this.audioEngine.play();
                this.updatePlayButton(true);
            }
        }, true);

        group.appendChild(stopBtn);
        group.appendChild(this.playButton);

        return group;
    }

    createTempoControl() {
        const group = document.createElement('div');
        group.className = 'control-group';
        group.style.cssText = `
            display: flex !important;
            align-items: center !important;
            gap: 10px !important;
            background: linear-gradient(145deg, 
                rgba(255, 255, 255, 0.08) 0%, 
                rgba(255, 255, 255, 0.04) 100%) !important;
            backdrop-filter: blur(15px) !important;
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
            border-radius: 12px !important;
            padding: 6px 12px !important;
            box-shadow: 
                0 2px 8px rgba(0, 0, 0, 0.05),
                inset 0 1px 0 rgba(255, 255, 255, 0.05) !important;
        `;

        // Tempo icon + label
        const label = document.createElement('div');
        label.style.cssText = `
            display: flex !important;
            align-items: center !important;
            gap: 6px !important;
            color: white !important;
            font-size: 12px !important;
            font-weight: 600 !important;
        `;
        label.innerHTML = `
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"/>
                <polyline points="12,6 12,12 16,14"/>
            </svg>
            Tempo
        `;

        // Tempo value display
        const tempoValue = document.createElement('span');
        tempoValue.id = 'tempo-value';
        tempoValue.textContent = '120';
        tempoValue.style.cssText = `
            background: linear-gradient(145deg, #10b981 0%, #059669 100%) !important;
            color: white !important;
            padding: 3px 8px !important;
            border-radius: 6px !important;
            font-weight: 700 !important;
            font-size: 11px !important;
            min-width: 30px !important;
            text-align: center !important;
            box-shadow: 
                0 1px 4px rgba(16, 185, 129, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.2) !important;
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
        `;

        // Tempo slider
        this.tempoSlider = document.createElement('input');
        this.tempoSlider.type = 'range';
        this.tempoSlider.min = '40';
        this.tempoSlider.max = '200';
        this.tempoSlider.value = '120';
        this.tempoSlider.style.cssText = `
            width: 80px !important;
            height: 4px !important;
            -webkit-appearance: none !important;
            appearance: none !important;
            background: rgba(255,255,255,0.3) !important;
            border-radius: 2px !important;
            outline: none !important;
        `;

        // Add CSS for slider thumb
        if (!document.getElementById('transport-slider-styles')) {
            const style = document.createElement('style');
            style.id = 'transport-slider-styles';
            style.textContent = `
                #transport-controls input[type="range"]::-webkit-slider-thumb {
                    -webkit-appearance: none;
                    appearance: none;
                    width: 16px;
                    height: 16px;
                    background: #4CAF50;
                    border-radius: 50%;
                    cursor: pointer;
                }
                #transport-controls input[type="range"]::-moz-range-thumb {
                    width: 16px;
                    height: 16px;
                    background: #4CAF50;
                    border-radius: 50%;
                    cursor: pointer;
                    border: none;
                }
            `;
            document.head.appendChild(style);
        }

        this.tempoSlider.addEventListener('input', (e) => {
            const tempo = parseInt(e.target.value);
            this.audioEngine.setTempo(tempo);
            tempoValue.textContent = tempo;
        });

        group.appendChild(label);
        group.appendChild(tempoValue);
        group.appendChild(this.tempoSlider);

        return group;
    }

    createVolumeControl() {
        const group = document.createElement('div');
        group.className = 'control-group';
        group.style.cssText = `
            display: flex !important;
            align-items: center !important;
            gap: 8px !important;
            background: linear-gradient(145deg, 
                rgba(255, 255, 255, 0.08) 0%, 
                rgba(255, 255, 255, 0.04) 100%) !important;
            backdrop-filter: blur(15px) !important;
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
            border-radius: 12px !important;
            padding: 6px 12px !important;
            box-shadow: 
                0 2px 8px rgba(0, 0, 0, 0.05),
                inset 0 1px 0 rgba(255, 255, 255, 0.05) !important;
        `;

        // Volume icon
        const label = document.createElement('div');
        label.style.cssText = `
            color: white !important;
            font-size: 14px !important;
            display: flex !important;
            align-items: center !important;
        `;
        label.innerHTML = `
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
                <path d="m19.07 4.93-1.414 1.414c2.828 2.828 2.828 7.414 0 10.242l1.414 1.414c3.598-3.598 3.598-9.442 0-13.04z"/>
            </svg>
        `;

        // Volume slider
        this.volumeSlider = document.createElement('input');
        this.volumeSlider.type = 'range';
        this.volumeSlider.min = '0';
        this.volumeSlider.max = '100';
        this.volumeSlider.value = '70';
        this.volumeSlider.style.cssText = `
            width: 60px !important;
            height: 4px !important;
            -webkit-appearance: none !important;
            appearance: none !important;
            background: rgba(255,255,255,0.3) !important;
            border-radius: 2px !important;
            outline: none !important;
        `;

        this.volumeSlider.addEventListener('input', (e) => {
            const volume = parseInt(e.target.value) / 100;
            this.audioEngine.setMasterVolume(volume);
        });

        group.appendChild(label);
        group.appendChild(this.volumeSlider);

        return group;
    }

    createCloseButton() {
        const group = document.createElement('div');
        
        const closeBtn = this.createButton('✕', 'Close Player', () => {
            this.closePlayer();
        });

        group.appendChild(closeBtn);
        return group;
    }

    createButton(icon, title, onClick, isLarge = false) {
        const button = document.createElement('button');
        button.innerHTML = icon;
        button.title = title;
        button.style.cssText = `
            background: linear-gradient(145deg, 
                rgba(255, 255, 255, 0.12) 0%, 
                rgba(255, 255, 255, 0.08) 100%) !important;
            color: white !important;
            border: 1px solid rgba(255, 255, 255, 0.15) !important;
            border-radius: ${isLarge ? '50%' : '8px'} !important;
            width: ${isLarge ? '48px' : '36px'} !important;
            height: ${isLarge ? '48px' : '36px'} !important;
            cursor: pointer !important;
            font-size: ${isLarge ? '18px' : '14px'} !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94) !important;
            backdrop-filter: blur(20px) !important;
            box-shadow: 
                0 2px 8px rgba(0, 0, 0, 0.1),
                inset 0 1px 0 rgba(255, 255, 255, 0.1) !important;
            position: relative !important;
            overflow: hidden !important;
        `;

        // Hover effect
        button.addEventListener('mouseenter', () => {
            button.style.background = `linear-gradient(145deg, 
                rgba(99, 102, 241, 0.8) 0%, 
                rgba(139, 92, 246, 0.7) 100%)`;
            button.style.transform = 'scale(1.05) translateY(-2px)';
            button.style.boxShadow = `
                0 8px 25px rgba(99, 102, 241, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.2)`;
        });

        button.addEventListener('mouseleave', () => {
            button.style.background = `linear-gradient(145deg, 
                rgba(255, 255, 255, 0.12) 0%, 
                rgba(255, 255, 255, 0.08) 100%)`;
            button.style.transform = 'scale(1) translateY(0)';
            button.style.boxShadow = `
                0 4px 15px rgba(0, 0, 0, 0.1),
                inset 0 1px 0 rgba(255, 255, 255, 0.1)`;
        });

        // Click effect
        button.addEventListener('mousedown', () => {
            button.style.transform = 'scale(0.95) translateY(0)';
        });

        button.addEventListener('mouseup', () => {
            button.style.transform = 'scale(1.05) translateY(-2px)';
        });

        button.addEventListener('click', onClick);
        return button;
    }

    setupEventListeners() {
        // Listen to audio engine position updates
        this.audioEngine.onPositionChange = (current, total) => {
            this.updateProgress(current, total);
            this.updateCursor(current, total);
        };

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.target.tagName.toLowerCase() === 'input') return;
            
            switch(e.code) {
                case 'Space':
                    e.preventDefault();
                    this.playButton.click();
                    break;
                case 'Home':
                    e.preventDefault();
                    this.audioEngine.seekTo(0);
                    break;
            }
        });
    }

    // Playback cursor management
    createPlaybackCursor() {
        const container = document.getElementById('overlay-osmd-container');
        if (!container) return;

        // Remove existing cursor
        if (this.cursor) {
            this.cursor.remove();
        }

        this.cursor = document.createElement('div');
        this.cursor.className = 'playback-cursor';
        this.cursor.style.cssText = `
            position: absolute !important;
            top: 0 !important;
            left: 0 !important;
            width: 4px !important;
            height: 100% !important;
            background: linear-gradient(to bottom, 
                #ef4444 0%, 
                #dc2626 50%, 
                #b91c1c 100%) !important;
            z-index: 1000 !important;
            transition: left 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94) !important;
            box-shadow: 
                0 0 20px rgba(239, 68, 68, 0.6),
                0 0 40px rgba(239, 68, 68, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.3) !important;
            border-radius: 3px !important;
            pointer-events: none !important;
        `;

        // Add glow effect
        const glow = document.createElement('div');
        glow.style.cssText = `
            position: absolute !important;
            top: -10px !important;
            left: -10px !important;
            width: 24px !important;
            height: calc(100% + 20px) !important;
            background: radial-gradient(ellipse, rgba(239, 68, 68, 0.3) 0%, transparent 70%) !important;
            pointer-events: none !important;
        `;
        
        this.cursor.appendChild(glow);

        container.appendChild(this.cursor);
        console.log('📍 Playback cursor created');
    }

    updateCursor(currentTime, totalTime) {
        if (!this.cursor) return;

        const container = document.getElementById('overlay-osmd-container');
        if (!container) return;

        // Simple linear progression across the score
        const progress = totalTime > 0 ? currentTime / totalTime : 0;
        const containerWidth = container.offsetWidth;
        const cursorLeft = progress * (containerWidth - 10);

        this.cursor.style.left = `${Math.max(0, Math.min(cursorLeft, containerWidth - 3))}px`;
    }

    // Progress bar updates
    updateProgress(current, total) {
        if (this.progressBar && total > 0) {
            const percentage = (current / total) * 100;
            this.progressBar.style.width = `${Math.max(0, Math.min(percentage, 100))}%`;
        }

        if (this.timeDisplay) {
            const currentFormatted = this.formatTime(current);
            const totalFormatted = this.formatTime(total);
            this.timeDisplay.textContent = `${currentFormatted} / ${totalFormatted}`;
        }
    }

    updatePlayButton(isPlaying) {
        if (this.playButton) {
            this.playButton.innerHTML = isPlaying ? 
                `<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <rect x="6" y="4" width="4" height="16"/>
                    <rect x="14" y="4" width="4" height="16"/>
                </svg>` :
                `<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <polygon points="5,3 19,12 5,21"/>
                </svg>`;
            this.playButton.title = isPlaying ? 'Pause' : 'Play';
        }
    }

    closePlayer() {
        this.audioEngine.stop();
        
        // Remove overlay
        const overlay = document.getElementById('music-overlay');
        if (overlay) {
            overlay.style.opacity = '0';
            setTimeout(() => overlay.remove(), 300);
        }
        
        // Remove transport controls
        if (this.controlsContainer) {
            this.controlsContainer.remove();
        }
    }

    // Utility functions
    formatTime(seconds) {
        if (isNaN(seconds) || seconds < 0) return '00:00';
        
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }

    // Public methods for external control
    show() {
        if (this.controlsContainer) {
            this.controlsContainer.style.display = 'flex';
        }
    }

    hide() {
        if (this.controlsContainer) {
            this.controlsContainer.style.display = 'none';
        }
    }

    updateScoreInfo(info) {
        if (info && this.tempoSlider) {
            this.tempoSlider.value = info.tempo || 120;
            const tempoValue = document.getElementById('tempo-value');
            if (tempoValue) {
                tempoValue.textContent = info.tempo || 120;
            }
        }
    }

    dispose() {
        if (this.controlsContainer) {
            this.controlsContainer.remove();
        }
        
        if (this.cursor) {
            this.cursor.remove();
        }
    }
}

// Rendi la classe disponibile globalmente
window.TransportControls = TransportControls;
