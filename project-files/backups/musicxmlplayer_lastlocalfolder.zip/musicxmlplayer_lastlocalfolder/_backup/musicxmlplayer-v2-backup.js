/**
 * MusicXML Player v2.1 - NEW CLEAN FILE
 * Save as: musicxmlplayer-v2.js (different filename to avoid cache issues)
 */
class MusicXMLPlayer {
    constructor() {
        this.workingOSMD = null;
        this.currentFile = null;
        this.isPlaying = false;
        this.currentPosition = 0;
        this.positionTimer = null;
        this.playButton = null;
        this.statusDisplay = null;
        this.positionDisplay = null;
        console.log('🎼 MusicXML Player v2.1 NEW FILE initialized');
    }

    async init() {
        console.log('🎼 Initializing MusicXML Player v2.1...');
        await this.loadFilesList();
        this.showWelcomeGuide(true);
        this.showScoreContainer(false);
        window.player = this;
        console.log('✨ MusicXML Player v2.1 initialized successfully');
    }

    showWelcomeGuide(show) {
        const guide = document.getElementById('welcome-guide');
        if (guide) {
            guide.style.display = show ? 'flex' : 'none';
        }
    }

    showScoreContainer(show) {
        const container = document.getElementById('score-container');
        if (container) {
            if (show) {
                container.style.position = 'absolute';
                container.style.top = '0';
                container.style.left = '0';
                container.style.right = '0';
                container.style.bottom = '0';
                container.style.width = '100%';
                container.style.height = '100%';
                container.style.background = '#ffffff';
                container.style.zIndex = '5';
                container.style.display = 'block';
                container.style.visibility = 'visible';
                container.style.opacity = '1';
                console.log('✅ Score container visible');
            } else {
                container.style.display = 'none';
            }
        }
    }

    async loadFilesList() {
        try {
            const response = await fetch(OC.generateUrl('/apps/musicxmlplayer/files'));
            const data = await response.json();
            this.renderFilesList(data.files || []);
        } catch (error) {
            console.error('❌ Error loading files:', error);
        }
    }

    renderFilesList(files) {
        const container = document.getElementById('files-list-container');
        if (!container) return;

        container.innerHTML = '';
        
        const self = this;
        files.forEach(function(file) {
            const fileElement = document.createElement('div');
            fileElement.style.padding = '12px 15px';
            fileElement.style.border = '1px solid #e2e8f0';
            fileElement.style.borderRadius = '8px';
            fileElement.style.background = '#f8fafc';
            fileElement.style.cursor = 'pointer';
            fileElement.style.marginBottom = '8px';
            fileElement.style.display = 'flex';
            fileElement.style.alignItems = 'center';
            fileElement.style.gap = '10px';
            
            const icon = document.createElement('div');
            icon.style.width = '32px';
            icon.style.height = '32px';
            icon.style.background = '#6366f1';
            icon.style.borderRadius = '6px';
            icon.style.display = 'flex';
            icon.style.alignItems = 'center';
            icon.style.justifyContent = 'center';
            icon.style.color = 'white';
            icon.textContent = '🎵';
            
            const text = document.createElement('div');
            text.style.flex = '1';
            
            const name = document.createElement('div');
            name.style.fontWeight = '600';
            name.style.color = '#1e293b';
            name.style.fontSize = '13px';
            name.textContent = file.name;
            
            const size = document.createElement('div');
            size.style.color = '#64748b';
            size.style.fontSize = '11px';
            size.textContent = self.formatFileSize(file.size);
            
            text.appendChild(name);
            text.appendChild(size);
            fileElement.appendChild(icon);
            fileElement.appendChild(text);
            
            fileElement.addEventListener('click', function() {
                self.selectFile(file);
            });
            
            container.appendChild(fileElement);
        });
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }

    async selectFile(file) {
        console.log('🎵 Loading file: ' + file.name);
        
        this.showWelcomeGuide(false);
        this.showScoreContainer(true);
        
        await new Promise(function(resolve) {
            setTimeout(resolve, 200);
        });
        
        try {
            const xmlContent = await this.fetchFileContent(file);
            await this.loadOSMD(xmlContent, file);
            this.currentFile = file;
        } catch (error) {
            console.error('❌ Error selecting file:', error);
            alert('Error loading ' + file.name);
        }
    }

    async loadOSMD(xmlContent, file) {
        console.log('🎼 Loading OSMD...');
        
        const container = document.getElementById('osmd-container');
        if (!container) {
            throw new Error('OSMD container not found');
        }
        
        container.style.width = '100%';
        container.style.height = '100%';
        container.style.minWidth = '800px';
        container.style.minHeight = '600px';
        container.style.background = 'white';
        container.style.padding = '20px';
        container.style.display = 'block';
        container.style.visibility = 'visible';
        container.innerHTML = '';
        
        // Header
        const header = document.createElement('div');
        header.style.background = '#6366f1';
        header.style.color = 'white';
        header.style.padding = '10px 15px';
        header.style.margin = '-20px -20px 15px -20px';
        header.style.fontWeight = 'bold';
        header.style.borderRadius = '6px 6px 0 0';
        header.style.display = 'flex';
        header.style.justifyContent = 'space-between';
        
        const title = document.createElement('span');
        title.textContent = '🎼 ' + file.name;
        
        const backBtn = document.createElement('button');
        backBtn.textContent = '← Back';
        backBtn.style.background = 'rgba(255,255,255,0.2)';
        backBtn.style.border = 'none';
        backBtn.style.color = 'white';
        backBtn.style.padding = '4px 8px';
        backBtn.style.borderRadius = '3px';
        backBtn.style.cursor = 'pointer';
        backBtn.style.fontSize = '11px';
        
        const self = this;
        backBtn.addEventListener('click', function() {
            self.showWelcomeGuide(true);
            self.showScoreContainer(false);
        });
        
        header.appendChild(title);
        header.appendChild(backBtn);
        container.appendChild(header);
        
        // Render area
        const renderArea = document.createElement('div');
        renderArea.style.width = '750px';
        renderArea.style.height = '500px';
        renderArea.style.background = 'white';
        renderArea.style.border = '1px solid #e2e8f0';
        renderArea.style.borderRadius = '6px';
        renderArea.style.padding = '15px';
        renderArea.style.margin = '0 auto';
        container.appendChild(renderArea);
        
        await new Promise(function(resolve) {
            setTimeout(resolve, 300);
        });
        
        const rect = renderArea.getBoundingClientRect();
        console.log('📐 Render area: ' + rect.width + 'x' + rect.height);
        
        if (rect.width > 500 && rect.height > 300) {
            try {
                if (typeof window.opensheetmusicdisplay === 'undefined') {
                    throw new Error('OSMD library not available');
                }
                
                this.workingOSMD = new window.opensheetmusicdisplay.OpenSheetMusicDisplay(renderArea, {
                    autoResize: false,
                    backend: 'svg',
                    drawTitle: true,
                    drawComposer: true,
                    pageFormat: 'Endless'
                });
                
                console.log('🎵 Loading XML...');
                await this.workingOSMD.load(xmlContent);
                
                console.log('🎨 Rendering...');
                await this.workingOSMD.render();
                
                console.log('✅ Score loaded!');
                
                this.addPlaybackControls();
                
            } catch (error) {
                console.error('❌ OSMD failed:', error);
                renderArea.innerHTML = '<div style="text-align: center; padding: 50px; color: #ef4444;"><h3>❌ Error</h3><p>' + error.message + '</p></div>';
            }
        } else {
            renderArea.innerHTML = '<div style="text-align: center; padding: 50px; color: #ef4444;"><h3>❌ Invalid Container</h3><p>Size: ' + rect.width + 'x' + rect.height + '</p></div>';
        }
    }

    addPlaybackControls() {
        console.log('🎮 Adding playback controls...');
        
        // Remove existing
        const existing = document.querySelector('.playback-controls-v2');
        if (existing) existing.remove();
        
        // Create controls
        const controls = document.createElement('div');
        controls.className = 'playback-controls-v2';
        controls.style.position = 'fixed';
        controls.style.bottom = '30px';
        controls.style.left = '50%';
        controls.style.transform = 'translateX(-50%)';
        controls.style.background = 'linear-gradient(135deg, #6366f1, #8b5cf6)';
        controls.style.color = 'white';
        controls.style.padding = '15px 25px';
        controls.style.borderRadius = '25px';
        controls.style.boxShadow = '0 10px 30px rgba(99, 102, 241, 0.4)';
        controls.style.display = 'flex';
        controls.style.gap = '15px';
        controls.style.alignItems = 'center';
        controls.style.zIndex = '99999';
        controls.style.fontFamily = 'system-ui';
        
        // Play button
        const playBtn = document.createElement('button');
        playBtn.textContent = '▶️';
        playBtn.style.background = 'rgba(255,255,255,0.9)';
        playBtn.style.color = '#6366f1';
        playBtn.style.border = 'none';
        playBtn.style.borderRadius = '12px';
        playBtn.style.padding = '8px 12px';
        playBtn.style.cursor = 'pointer';
        playBtn.style.fontSize = '14px';
        playBtn.style.minWidth = '40px';
        playBtn.style.height = '35px';
        
        // Stop button
        const stopBtn = document.createElement('button');
        stopBtn.textContent = '⏹️';
        stopBtn.style.background = 'rgba(239, 68, 68, 0.8)';
        stopBtn.style.color = 'white';
        stopBtn.style.border = 'none';
        stopBtn.style.borderRadius = '8px';
        stopBtn.style.padding = '6px 10px';
        stopBtn.style.cursor = 'pointer';
        stopBtn.style.fontSize = '12px';
        stopBtn.style.height = '35px';
        
        // Status
        const status = document.createElement('span');
        status.textContent = 'Ready';
        status.style.fontSize = '11px';
        status.style.fontWeight = '600';
        
        // Position
        const position = document.createElement('span');
        position.textContent = '00:00';
        position.style.fontSize = '11px';
        position.style.fontWeight = '600';
        position.style.fontFamily = 'monospace';
        
        // Event handlers
        const self = this;
        playBtn.addEventListener('click', function() {
            self.togglePlayback(playBtn);
        });
        
        stopBtn.addEventListener('click', function() {
            self.stopPlayback(playBtn);
        });
        
        controls.appendChild(playBtn);
        controls.appendChild(stopBtn);
        controls.appendChild(status);
        controls.appendChild(position);
        
        document.body.appendChild(controls);
        
        this.playButton = playBtn;
        this.statusDisplay = status;
        this.positionDisplay = position;
        
        console.log('✅ Playback controls added to body');
    }

    togglePlayback(playButton) {
        if (this.isPlaying) {
            this.pausePlayback(playButton);
        } else {
            this.startPlayback(playButton);
        }
    }

    startPlayback(playButton) {
        console.log('▶️ Starting playback...');
        this.isPlaying = true;
        playButton.textContent = '⏸️';
        this.statusDisplay.textContent = 'Playing';
        this.currentPosition = 0;
        this.startTimer();
        this.showInfo();
    }

    pausePlayback(playButton) {
        console.log('⏸️ Pausing playback...');
        this.isPlaying = false;
        playButton.textContent = '▶️';
        this.statusDisplay.textContent = 'Paused';
        this.stopTimer();
    }

    stopPlayback(playButton) {
        console.log('⏹️ Stopping playback...');
        this.isPlaying = false;
        playButton.textContent = '▶️';
        this.statusDisplay.textContent = 'Ready';
        this.positionDisplay.textContent = '00:00';
        this.stopTimer();
        this.currentPosition = 0;
    }

    startTimer() {
        this.stopTimer();
        const self = this;
        this.positionTimer = setInterval(function() {
            if (self.isPlaying) {
                self.currentPosition += 1;
                const minutes = Math.floor(self.currentPosition / 60);
                const seconds = self.currentPosition % 60;
                const mm = minutes.toString().padStart(2, '0');
                const ss = seconds.toString().padStart(2, '0');
                self.positionDisplay.textContent = mm + ':' + ss;
            }
        }, 1000);
    }

    stopTimer() {
        if (this.positionTimer) {
            clearInterval(this.positionTimer);
            this.positionTimer = null;
        }
    }

    showInfo() {
        const info = document.createElement('div');
        info.style.position = 'fixed';
        info.style.top = '20px';
        info.style.right = '20px';
        info.style.background = '#3b82f6';
        info.style.color = 'white';
        info.style.padding = '15px 20px';
        info.style.borderRadius = '10px';
        info.style.zIndex = '99998';
        info.style.maxWidth = '280px';
        info.style.fontSize = '13px';
        info.textContent = '🎼 Visual Playback - Timer simula riproduzione';
        
        document.body.appendChild(info);
        
        setTimeout(function() {
            if (info.parentElement) {
                info.remove();
            }
        }, 4000);
    }

    async fetchFileContent(file) {
        console.log('📡 Fetching: ' + file.name);
        const response = await fetch(OC.generateUrl('/apps/musicxmlplayer/file/{fileId}', {fileId: file.id}));
        const rawResponse = await response.text();
        
        let xmlContent;
        if (rawResponse.trim().startsWith('{')) {
            const jsonData = JSON.parse(rawResponse);
            xmlContent = jsonData.content || rawResponse;
        } else {
            xmlContent = rawResponse;
        }
        
        return this.cleanXML(xmlContent);
    }

    cleanXML(xmlContent) {
        console.log('🧹 Cleaning XML...');
        
        if (xmlContent.charCodeAt(0) === 0xFEFF) {
            xmlContent = xmlContent.slice(1);
        }
        
        xmlContent = xmlContent.trim();
        
        if (!xmlContent.startsWith('<?xml')) {
            xmlContent = '<?xml version="1.0" encoding="UTF-8"?>\n' + xmlContent;
        }
        
        console.log('✅ XML cleaned');
        return xmlContent;
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Initializing MusicXML Player v2.1 NEW...');
    const player = new MusicXMLPlayer();
    player.init();
    if (!window.OCA) window.OCA = {};
    window.OCA.MusicXMLPlayer = player;
    console.log('✨ MusicXML Player v2.1 NEW ready');
});