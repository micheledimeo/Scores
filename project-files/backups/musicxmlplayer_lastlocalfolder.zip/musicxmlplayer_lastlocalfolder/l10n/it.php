<?php
$TRANSLATIONS = array(
    "MusicXML Player" => "MusicXML Player",
    "Play MusicXML files directly in Nextcloud" => "Riproduci file MusicXML direttamente in Nextcloud",
    "Error loading MusicXML files" => "Errore nel caricamento dei file MusicXML",
    "Error loading MusicXML file" => "Errore nel caricamento del file MusicXML",
    "Error rendering score" => "Errore nella visualizzazione dello spartito",
    "No file loaded" => "Nessun file caricato",
    "MIDI exported successfully" => "MIDI esportato con successo",
    "Error exporting MIDI" => "Errore nell'esportazione MIDI",
    "Loading score..." => "Caricamento spartito...",
    "Tempo" => "Tempo",
    "Volume" => "Volume",
    "Loop" => "Ripeti",
    "Metronome" => "Metronomo",
    "Export MIDI" => "Esporta MIDI",
    "Refresh" => "Aggiorna"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";