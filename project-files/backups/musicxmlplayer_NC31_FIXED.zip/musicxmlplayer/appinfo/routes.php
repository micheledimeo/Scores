<?php
/**
 * Routes configuration for MusicXML Player
 */

return [
    'routes' => [
        ['name' => 'page#index', 'url' => '/', 'verb' => 'GET'],
        ['name' => 'page#listMusicFiles', 'url' => '/files', 'verb' => 'GET'],
        ['name' => 'page#getFileContent', 'url' => '/file/{fileId}', 'verb' => 'GET'],
    ]
];