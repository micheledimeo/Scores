<?php
declare(strict_types=1);

namespace OCA\MusicXMLPlayer\AppInfo;

use OCA\MusicXMLPlayer\Controller\PageController;
use OCA\MusicXMLPlayer\Service\CSPProvider;
use OCP\AppFramework\App;
use OCP\AppFramework\Bootstrap\IRegistrationContext;
use OCP\AppFramework\Bootstrap\IBootContext;
use OCP\AppFramework\Bootstrap\IBootstrap;
use OCP\Security\CSP\AddContentSecurityPolicyEvent;
use Psr\Container\ContainerInterface;

class Application extends App implements IBootstrap {
    public const APP_ID = 'musicxmlplayer';

    public function __construct(array $urlParams = []) {
        parent::__construct(self::APP_ID, $urlParams);
    }

    public function register(IRegistrationContext $context): void {
        // Registra il controller
        $context->registerService(PageController::class, function (ContainerInterface $c) {
            $server = $c->get(\OCP\IServerContainer::class);
            return new PageController(
                self::APP_ID,
                $c->get(\OCP\IRequest::class),
                $c->get(\OCP\IUserSession::class)->getUser()?->getUID(),
                $c->get(\OCP\Files\IRootFolder::class),
                $c->get(\OCP\IUserSession::class)
            );
        });

        // Register CSP Provider for OSMD integration
        $context->registerEventListener(
            AddContentSecurityPolicyEvent::class,
            CSPProvider::class
        );
    }

    public function boot(IBootContext $context): void {
        // Nothing to boot
    }
}