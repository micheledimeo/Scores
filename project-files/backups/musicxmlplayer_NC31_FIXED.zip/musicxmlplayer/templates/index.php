<?php
/** @var \OCP\IL10N $l */
/** @var array $_ */

// Load scripts with OSMD Playback Engine - Fixed Version v2.1
script('musicxmlplayer', 'opensheetmusicdisplay.min');
script('musicxmlplayer', 'osmd-playback-engine'); // OSMD Playback Engine with debug utilities
script('musicxmlplayer', 'musicxml-parser');
script('musicxmlplayer', 'musicxmlplayer'); // SYNTAX ERROR FIXED - all methods in class
style('musicxmlplayer', 'style');
?>

<div id="app" class="app-musicxmlplayer">
    <!-- Layout con lista files nella colonna -->
    <div id="app-content" class="app-content" style="margin-left: 0 !important; width: 100% !important;">
        <div id="app-content-wrapper" style="width: 100% !important;">
            <!-- Container principale -->
            <div id="main-container" style="
                width: 100%;
                height: 100vh;
                background: linear-gradient(145deg, #ffffff 0%, #f8fafc 100%);
                display: flex;
                flex-direction: column;
                position: relative;
            ">
                <!-- Header Music Library -->
                <div id="main-header" style="
                    padding: 30px 30px 20px 30px;
                    border-bottom: 1px solid rgba(226, 232, 240, 0.6);
                    background: linear-gradient(145deg, #ffffff 0%, #f8fafc 100%);
                    position: relative;
                ">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <div style="
                            width: 50px; 
                            height: 50px; 
                            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
                            border-radius: 12px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            font-size: 22px;
                            box-shadow: 0 4px 15px rgba(99, 102, 241, 0.25);
                            flex-shrink: 0;
                        ">🎼</div>
                        <div style="flex: 1;">
                            <h1 style="
                                color: #1e293b; 
                                margin: 0; 
                                font-size: 28px; 
                                font-weight: 700; 
                                letter-spacing: -0.3px;
                            ">Music Library</h1>
                            <p style="
                                color: #64748b; 
                                margin: 4px 0 0 0; 
                                font-size: 14px;
                                font-weight: 500;
                            ">Your collection</p>
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <select id="language-selector" style="
                                background: rgba(99, 102, 241, 0.1);
                                border: 1px solid rgba(99, 102, 241, 0.3);
                                border-radius: 6px;
                                padding: 6px 10px;
                                color: #6366f1;
                                font-size: 12px;
                                font-weight: 600;
                                cursor: pointer;
                                outline: none;
                            ">
                                <option value="en">🇬🇧 EN</option>
                                <option value="it">🇮🇹 IT</option>
                                <option value="es">🇪🇸 ES</option>
                                <option value="de">🇩🇪 DE</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- Area contenuto principale -->
                <div id="main-content-area" style="
                    flex: 1;
                    display: flex;
                    background: #ffffff;
                    position: relative;
                    overflow: hidden;
                ">
                    <!-- Colonna sinistra: Lista Files -->
                    <div id="files-column" style="
                        width: 320px;
                        background: #ffffff;
                        border-right: 1px solid rgba(226, 232, 240, 0.6);
                        overflow-y: auto;
                        padding: 20px;
                        flex-shrink: 0;
                    ">
                        <div id="files-list-container" style="
                            display: flex;
                            flex-direction: column;
                            gap: 8px;
                        ">
                            <!-- File list will be populated by JavaScript -->
                        </div>
                        
                        <div id="empty-files" style="
                            text-align: center;
                            padding: 40px 20px;
                            color: #64748b;
                            display: none;
                        ">
                            <div style="font-size: 32px; margin-bottom: 15px;">🎵</div>
                            <h3 style="color: #1e293b; margin-bottom: 8px; font-size: 16px;">No music files</h3>
                            <p style="font-size: 13px;">Upload MusicXML files to get started</p>
                        </div>
                    </div>
                    
                    <!-- Area destra: Spartito/Guida -->
                    <div id="score-area" style="
                        flex: 1;
                        background: #ffffff;
                        position: relative;
                        overflow: auto;
                        display: flex;
                        flex-direction: column;
                    ">
                        <!-- Guida iniziale -->
                        <div id="welcome-guide" style="
                            padding: 40px;
                            text-align: center;
                            color: #64748b;
                            max-width: 600px;
                            margin: auto;
                            align-self: center;
                            justify-self: center;
                            display: flex;
                            flex-direction: column;
                            justify-content: center;
                            min-height: 100%;
                        ">
                            <div style="font-size: 64px; margin-bottom: 25px;">🎼</div>
                            <h2 id="welcome-title" style="
                                color: #1e293b; 
                                margin-bottom: 20px; 
                                font-size: 24px;
                                font-weight: 700;
                            ">Welcome to MusicXML Player</h2>
                            <div style="text-align: left; margin-bottom: 30px;">
                                <h3 id="quick-guide-title" style="color: #374151; margin-bottom: 15px; font-size: 18px;">Quick Start Guide:</h3>
                                <ul style="
                                    color: #64748b; 
                                    line-height: 1.6;
                                    font-size: 14px;
                                    list-style: none;
                                    padding: 0;
                                ">
                                    <li style="margin-bottom: 10px; display: flex; align-items: center; gap: 10px;">
                                        <span style="color: #6366f1; font-size: 16px;">📁</span>
                                        <span id="guide-select-file">Select a music file from the library on the left</span>
                                    </li>
                                    <li style="margin-bottom: 10px; display: flex; align-items: center; gap: 10px;">
                                        <span style="color: #6366f1; font-size: 16px;">🎵</span>
                                        <span id="guide-view-sheet">View your sheet music with professional rendering</span>
                                    </li>
                                    <li style="margin-bottom: 10px; display: flex; align-items: center; gap: 10px;">
                                        <span style="color: #6366f1; font-size: 16px;">▶️</span>
                                        <span id="guide-play-audio">Play audio with synchronized score highlighting</span>
                                    </li>
                                    <li style="margin-bottom: 10px; display: flex; align-items: center; gap: 10px;">
                                        <span style="color: #6366f1; font-size: 16px;">⏯️</span>
                                        <span id="guide-control-playback">Control playback with professional transport controls</span>
                                    </li>
                                    <li style="margin-bottom: 10px; display: flex; align-items: center; gap: 10px;">
                                        <span style="color: #6366f1; font-size: 16px;">🎹</span>
                                        <span id="guide-adjust-tempo">Adjust tempo and volume for practice sessions</span>
                                    </li>
                                </ul>
                            </div>
                            <p id="guide-choose-file" style="
                                color: #94a3b8; 
                                font-size: 13px;
                                font-style: italic;
                            ">Choose a file from the library to begin your musical journey ✨</p>
                        </div>
                        
                        <!-- Score container (hidden initially) -->
                        <div id="score-container" style="display: none;">
                            <div id="osmd-container"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>