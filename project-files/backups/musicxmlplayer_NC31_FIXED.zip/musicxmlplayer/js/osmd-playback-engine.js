/**
 * OSMD Playback Engine Integration - Production Version
 * Fixes for SkyBottomLineBatchCalculatorBackend NaN width errors
 * Version: 2.0 - Stable Release
 */

class OSMDPlaybackEngine {
    constructor() {
        this.osmd = null;
        this.playbackEngine = null;
        this.cursor = null;
        this.isInitialized = false;
        this.isPlaying = false;
        this.currentTempo = 120;
        this.currentVolume = 80;
        this.initializationRetries = 0;
        this.maxRetries = 3;
        
        console.log('🎹 OSMD Playback Engine v2.0 created');
    }

    /**
     * Initialize OSMD with complete playback support
     */
    async initialize(container) {
        try {
            console.log('🎼 Initializing OSMD with PlaybackEngine...');
            
            if (!window.opensheetmusicdisplay) {
                throw new Error('OpenSheetMusicDisplay library not loaded');
            }

            // Validate container dimensions
            const rect = container.getBoundingClientRect();
            if (rect.width <= 0 || rect.height <= 0) {
                console.warn(`⚠️ Invalid container dimensions: ${rect.width}x${rect.height}, applying fix...`);
                
                // Emergency fix for container dimensions
                container.style.width = '800px';
                container.style.height = '600px';
                container.style.minWidth = '800px';
                container.style.minHeight = '600px';
                container.style.display = 'block';
                container.offsetHeight; // Force reflow
                
                const newRect = container.getBoundingClientRect();
                console.log('🔧 Fixed container dimensions:', newRect.width, 'x', newRect.height);
            }

            const finalRect = container.getBoundingClientRect();
            console.log('📐 Final container dimensions:', finalRect.width, 'x', finalRect.height);

            // Create OSMD instance with fixed configuration to prevent NaN errors
            this.osmd = new window.opensheetmusicdisplay.OpenSheetMusicDisplay(container, {
                autoResize: false, // Critical: disable auto-resize to prevent timing issues
                backend: 'svg',
                drawTitle: true,
                drawComposer: true,
                drawCredits: false,
                drawPartNames: true,
                
                // Fixed page format to ensure stable dimensions
                pageFormat: 'Endless',
                pageBackgroundColor: '#FFFFFF',
                
                // Explicit dimensions to prevent calculation errors
                width: Math.max(760, finalRect.width - 40),
                height: Math.max(560, finalRect.height - 40),
                
                // Playback configuration
                followCursor: true,
                
                // Enhanced cursor configuration
                drawingParameters: {
                    // Enable cursor
                    DrawCursors: true,
                    
                    // Cursor styling  
                    CursorColor: '#ef4444',
                    CursorAlpha: 0.8,
                    CursorWidth: 3,
                    
                    // Prevent layout calculation errors
                    systemLeftMargin: 20,
                    systemRightMargin: 20,
                    systemLabelsRightMargin: 10,
                    measureNumberInterval: 5,
                    
                    // Stabilize measure calculations
                    minimumMeasureWidth: 50,
                    maxMeasureWidth: 300,
                    
                    // Page layout parameters to prevent overflow
                    pageTopMargin: 20,
                    pageBottomMargin: 20,
                    titleTopDistance: 10,
                }
            });

            console.log('✅ OSMD instance created with playback support');
            this.isInitialized = true;
            
            return this.osmd;
            
        } catch (error) {
            console.error('❌ OSMD Playback Engine initialization failed:', error);
            throw error;
        }
    }

    /**
     * Load MusicXML and setup playback with error handling
     */
    async loadScore(xmlContent) {
        if (!this.osmd) {
            throw new Error('OSMD not initialized');
        }

        try {
            console.log('📜 Loading MusicXML for playback...');
            
            // Validate XML content
            if (!xmlContent || xmlContent.trim().length === 0) {
                throw new Error('Empty XML content');
            }

            // Load the score with retry mechanism
            await this.loadScoreWithRetry(xmlContent);
            
            // Wait for DOM to settle before rendering
            await new Promise(resolve => setTimeout(resolve, 100));
            
            // Render with dimension validation
            await this.renderWithValidation();
            
            console.log('✅ Score loaded and rendered');
            
            // Initialize playback engine
            await this.initializePlaybackEngine();
            
            // Initialize cursor
            this.initializeCursor();
            
            console.log('✅ OSMD Playback Engine fully ready');
            
        } catch (error) {
            console.error('❌ Score loading failed:', error);
            throw error;
        }
    }

    /**
     * Load score with retry mechanism for stability
     */
    async loadScoreWithRetry(xmlContent) {
        for (let attempt = 0; attempt < this.maxRetries; attempt++) {
            try {
                console.log(`📝 Loading attempt ${attempt + 1}/${this.maxRetries}`);
                await this.osmd.load(xmlContent);
                console.log('✅ Score loaded successfully');
                return;
            } catch (error) {
                console.warn(`⚠️ Load attempt ${attempt + 1} failed:`, error.message);
                if (attempt === this.maxRetries - 1) {
                    throw error;
                }
                // Wait before retry
                await new Promise(resolve => setTimeout(resolve, 200 * (attempt + 1)));
            }
        }
    }

    /**
     * Render with dimension validation to prevent NaN errors
     */
    async renderWithValidation() {
        try {
            // Validate container before rendering
            const container = this.osmd.container;
            if (container) {
                const rect = container.getBoundingClientRect();
                if (rect.width <= 0 || rect.height <= 0) {
                    console.warn('⚠️ Container dimensions invalid before render:', rect.width, 'x', rect.height);
                    
                    // Force container dimensions
                    container.style.width = '800px';
                    container.style.height = '600px';
                    container.style.minWidth = '800px';
                    container.style.minHeight = '600px';
                    
                    // Force reflow
                    container.offsetHeight;
                }
            }

            // Set a safe zoom level
            this.osmd.zoom = 1.0;
            
            // Render with error handling
            console.log('🎨 Rendering OSMD score...');
            await this.osmd.render();
            
            console.log('✅ OSMD render completed successfully');
            
        } catch (error) {
            console.error('❌ Render failed:', error);
            
            // Try fallback render with smaller zoom
            try {
                console.log('🔄 Attempting fallback render...');
                this.osmd.zoom = 0.8;
                await this.osmd.render();
                console.log('✅ Fallback render successful');
            } catch (fallbackError) {
                console.error('❌ Fallback render also failed:', fallbackError);
                throw fallbackError;
            }
        }
    }

    /**
     * Initialize OSMD PlaybackEngine
     */
    async initializePlaybackEngine() {
        try {
            console.log('🎵 Initializing OSMD PlaybackEngine...');
            
            // Check if PlaybackEngine is available in this version
            if (this.osmd.PlaybackManager) {
                console.log('✅ Using OSMD PlaybackManager');
                this.playbackEngine = this.osmd.PlaybackManager;
                this.setupPlaybackEvents();
                
            } else if (window.opensheetmusicdisplay.PlaybackEngine) {
                console.log('✅ Creating OSMD PlaybackEngine');
                this.playbackEngine = new window.opensheetmusicdisplay.PlaybackEngine();
                
                // Initialize with the loaded sheet
                try {
                    await this.playbackEngine.loadScore(this.osmd.Sheet);
                } catch (loadError) {
                    console.warn('⚠️ PlaybackEngine loadScore failed:', loadError);
                }
                
                this.setupPlaybackEvents();
                
            } else {
                console.warn('⚠️ OSMD PlaybackEngine not available, using fallback');
                this.initializeFallbackPlayback();
            }
            
        } catch (error) {
            console.error('❌ PlaybackEngine initialization failed:', error);
            this.initializeFallbackPlayback();
        }
    }

    /**
     * Initialize OSMD Cursor with error handling
     */
    initializeCursor() {
        try {
            console.log('🎯 Initializing OSMD Cursor...');
            
            if (this.osmd.cursor) {
                // Native OSMD cursor
                this.cursor = this.osmd.cursor;
                this.cursor.show();
                console.log('✅ OSMD native cursor initialized');
                
            } else if (this.osmd.Sheet) {
                // Create cursor from sheet
                this.cursor = this.osmd.Sheet.getIterator();
                if (this.cursor) {
                    this.cursor.reset();
                    console.log('✅ OSMD iterator cursor created');
                }
            }
            
            if (this.cursor) {
                this.cursor.reset();
                console.log('🎯 Cursor positioned at start');
            }
            
        } catch (error) {
            console.error('❌ Cursor initialization failed:', error);
        }
    }

    /**
     * Setup playback event listeners
     */
    setupPlaybackEvents() {
        if (!this.playbackEngine) return;
        
        try {
            // Playback state events
            if (this.playbackEngine.on) {
                this.playbackEngine.on('playbackStart', () => {
                    this.isPlaying = true;
                    console.log('▶️ OSMD Playback started');
                });
                
                this.playbackEngine.on('playbackPause', () => {
                    this.isPlaying = false;
                    console.log('⏸️ OSMD Playback paused');
                });
                
                this.playbackEngine.on('playbackStop', () => {
                    this.isPlaying = false;
                    this.resetCursor();
                    console.log('⏹️ OSMD Playback stopped');
                });
                
                // Most important: cursor updates
                this.playbackEngine.on('playbackPosition', (position) => {
                    this.updateCursorPosition(position);
                });
                
                console.log('✅ Playback events configured');
            }
        } catch (error) {
            console.error('❌ Event setup failed:', error);
        }
    }

    /**
     * Start playback with error handling
     */
    async startPlayback() {
        try {
            console.log('▶️ Starting OSMD playback...');
            
            if (this.playbackEngine && this.playbackEngine.play) {
                // Reset cursor to start
                this.resetCursor();
                
                // Start OSMD playback
                await this.playbackEngine.play();
                this.isPlaying = true;
                
                console.log('✅ OSMD playback started');
                
            } else {
                console.warn('⚠️ PlaybackEngine not available');
                throw new Error('PlaybackEngine not available');
            }
            
        } catch (error) {
            console.error('❌ Playback start failed:', error);
            throw error;
        }
    }

    /**
     * Pause playback
     */
    async pausePlayback() {
        try {
            if (this.playbackEngine && this.playbackEngine.pause) {
                await this.playbackEngine.pause();
                this.isPlaying = false;
                console.log('⏸️ OSMD playback paused');
            }
        } catch (error) {
            console.error('❌ Playback pause failed:', error);
        }
    }

    /**
     * Stop playback
     */
    async stopPlayback() {
        try {
            if (this.playbackEngine && this.playbackEngine.stop) {
                await this.playbackEngine.stop();
                this.isPlaying = false;
                this.resetCursor();
                console.log('⏹️ OSMD playback stopped');
            }
        } catch (error) {
            console.error('❌ Playback stop failed:', error);
        }
    }

    /**
     * Set tempo with validation
     */
    setTempo(tempo) {
        this.currentTempo = Math.max(60, Math.min(200, tempo));
        
        try {
            if (this.playbackEngine && this.playbackEngine.setTempo) {
                this.playbackEngine.setTempo(this.currentTempo);
                console.log(`🎵 Tempo set to ${this.currentTempo} BPM`);
            }
        } catch (error) {
            console.error('❌ Tempo setting failed:', error);
        }
    }

    /**
     * Set volume with validation
     */
    setVolume(volume) {
        this.currentVolume = Math.max(0, Math.min(100, volume));
        
        try {
            if (this.playbackEngine && this.playbackEngine.setVolume) {
                this.playbackEngine.setVolume(this.currentVolume / 100);
                console.log(`🔊 Volume set to ${this.currentVolume}%`);
            }
        } catch (error) {
            console.error('❌ Volume setting failed:', error);
        }
    }

    /**
     * Update cursor position during playback
     */
    updateCursorPosition(position) {
        if (!this.cursor) return;
        
        try {
            if (this.cursor.update) {
                this.cursor.update(position);
            } else if (this.cursor.moveTo) {
                this.cursor.moveTo(position);
            }
            
        } catch (error) {
            console.warn('⚠️ Cursor update failed:', error);
        }
    }

    /**
     * Reset cursor to beginning
     */
    resetCursor() {
        if (this.cursor && this.cursor.reset) {
            try {
                this.cursor.reset();
                console.log('🔄 Cursor reset to start');
            } catch (error) {
                console.warn('⚠️ Cursor reset failed:', error);
            }
        }
    }

    /**
     * Fallback playback initialization (if native OSMD playback not available)
     */
    initializeFallbackPlayback() {
        console.log('🔄 Initializing fallback playback system...');
        console.log('⚠️ Fallback playback not implemented - native OSMD preferred');
    }

    /**
     * Handle container resize to prevent NaN errors
     */
    handleResize() {
        if (!this.osmd) return;
        
        try {
            const container = this.osmd.container;
            if (container) {
                const rect = container.getBoundingClientRect();
                
                if (rect.width > 0 && rect.height > 0) {
                    console.log('🔄 Handling OSMD resize:', rect.width, 'x', rect.height);
                    
                    // Update OSMD dimensions
                    if (this.osmd.setOptions) {
                        this.osmd.setOptions({
                            width: rect.width - 40,
                            height: rect.height - 40
                        });
                    }
                    
                    // Re-render if stable dimensions
                    setTimeout(() => {
                        if (this.osmd.render) {
                            this.osmd.render().catch(error => {
                                console.warn('⚠️ Resize render failed:', error);
                            });
                        }
                    }, 100);
                }
            }
        } catch (error) {
            console.warn('⚠️ Resize handling failed:', error);
        }
    }

    /**
     * Get playback state with enhanced info
     */
    getState() {
        return {
            isInitialized: this.isInitialized,
            isPlaying: this.isPlaying,
            tempo: this.currentTempo,
            volume: this.currentVolume,
            hasPlaybackEngine: !!this.playbackEngine,
            hasCursor: !!this.cursor,
            retries: this.initializationRetries,
            containerDimensions: this.osmd?.container ? 
                this.osmd.container.getBoundingClientRect() : null
        };
    }

    /**
     * Cleanup with comprehensive error handling
     */
    destroy() {
        try {
            console.log('🗑️ Cleaning up OSMD Playback Engine...');
            
            if (this.playbackEngine && this.playbackEngine.stop) {
                this.playbackEngine.stop();
            }
            
            this.isPlaying = false;
            this.playbackEngine = null;
            this.cursor = null;
            
            if (this.osmd) {
                if (this.osmd.clear) {
                    this.osmd.clear();
                }
                this.osmd = null;
            }
            
            this.isInitialized = false;
            console.log('✅ OSMD Playback Engine cleaned up');
            
        } catch (error) {
            console.error('❌ Cleanup failed:', error);
        }
    }

    /**
     * Debug method to check OSMD state
     */
    debugState() {
        console.log('🔍 === OSMD Engine Debug ===');
        console.log('Initialized:', this.isInitialized);
        console.log('Playing:', this.isPlaying);
        console.log('OSMD Instance:', !!this.osmd);
        console.log('Playback Engine:', !!this.playbackEngine);
        console.log('Cursor:', !!this.cursor);
        console.log('Retries Used:', this.initializationRetries);
        
        if (this.osmd?.container) {
            const rect = this.osmd.container.getBoundingClientRect();
            console.log('Container Dimensions:', rect.width, 'x', rect.height);
        }
        
        console.log('🔍 === End Debug ===');
    }
}

// Export for global use
window.OSMDPlaybackEngine = OSMDPlaybackEngine;
console.log('📦 OSMD Playback Engine v2.0 loaded');
