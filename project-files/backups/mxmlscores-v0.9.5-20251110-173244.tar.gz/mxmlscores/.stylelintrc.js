module.exports = {
	extends: '@nextcloud/stylelint-config',
}
