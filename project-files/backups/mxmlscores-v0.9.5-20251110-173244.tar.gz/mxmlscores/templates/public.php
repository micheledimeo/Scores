<!-- Public share view - data provided via InitialState API -->
<div id="app"></div>
