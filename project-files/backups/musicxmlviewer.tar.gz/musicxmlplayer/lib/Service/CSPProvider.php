<?php

declare(strict_types=1);

namespace OCA\MusicXMLPlayer\Service;

use OCP\AppFramework\Http\ContentSecurityPolicy;
use OCP\Security\CSP\AddContentSecurityPolicyEvent;
use OCP\EventDispatcher\Event;
use OCP\EventDispatcher\IEventListener;

/**
 * Content Security Policy Provider for MusicXML Player
 * 
 * Ensures proper CSP headers for OSMD (OpenSheetMusicDisplay) Integration
 * while maintaining security for Nextcloud 31.0.7+
 */
class CSPProvider implements IEventListener {

    public function handle(Event $event): void {
        if (!($event instanceof AddContentSecurityPolicyEvent)) {
            return;
        }

        // Create a new CSP policy (compatible with Nextcloud 31+)
        $csp = new ContentSecurityPolicy();

        // Allow OSMD resources if using CDN
        // $csp->addAllowedScriptDomain('https://cdn.jsdelivr.net');
        // $csp->addAllowedScriptDomain('https://unpkg.com');
        
        // Allow inline styles for OSMD rendering
        $csp->allowInlineStyle();
        
        // Allow data URIs for embedded content (OSMD uses SVG data URIs)
        $csp->addAllowedImageDomain('data:');
        $csp->addAllowedMediaDomain('data:');
        $csp->addAllowedImageDomain('blob:');

        // Allow WebWorkers for audio processing
        $csp->addAllowedWorkerSrcDomain("'self'");
        $csp->addAllowedWorkerSrcDomain('blob:');

        // Apply the new policy to the event
        $event->addPolicy($csp);
    }
}