# ⚡ QUICK DEPLOY - MusicXML Player NC31

## 🚀 Deploy Rapido in 5 Passi

### 1️⃣ Upload Archivio

```bash
# Dal tuo Mac, esegui:
scp /Users/Michele/musicxmlplayer_NC31_FIXED.zip ottoniascoppio:/home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/
```

### 2️⃣ Connessione Server

```bash
ssh ottoniascoppio
cd /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/
```

### 3️⃣ Rimozione Versione Precedente (se esiste)

```bash
php ../occ app:disable musicxmlplayer 2>/dev/null
rm -rf musicxmlplayer/
```

### 4️⃣ Installazione Nuova Versione

```bash
unzip musicxmlplayer_NC31_FIXED.zip
chown -R ottoniascoppio:ottoniascoppio musicxmlplayer/
chmod -R 755 musicxmlplayer/
php ../occ app:enable musicxmlplayer
php ../occ maintenance:repair
```

### 5️⃣ Verifica

```bash
# Controlla app abilitata
php ../occ app:list | grep musicxmlplayer

# Controlla ultimi log (dovrebbero essere puliti)
tail -20 /mnt/volume-8nico/Armadio/nextcloud.log | jq -r 'select(.level >= 3) | "\(.time) [\(.level)] \(.message)"'
```

## ✅ Test Rapido

1. Vai a: https://cloud.ottoniascoppio.org/index.php/apps/musicxmlplayer
2. Apri Console (F12)
3. Verifica nessun errore 500 o CSP
4. Carica un file musicale e verifica rendering

## 🔥 One-Liner Deploy Completo

```bash
# Esegui questo comando completo dopo aver fatto SCP dell'archivio:
ssh ottoniascoppio "cd /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/ && php ../occ app:disable musicxmlplayer 2>/dev/null; rm -rf musicxmlplayer/; unzip -q musicxmlplayer_NC31_FIXED.zip; chown -R ottoniascoppio:ottoniascoppio musicxmlplayer/; chmod -R 755 musicxmlplayer/; php ../occ app:enable musicxmlplayer && php ../occ maintenance:repair && echo '✅ Deploy completato!' && php ../occ app:list | grep musicxmlplayer"
```

---

**Tempo stimato**: ~2 minuti
**Richiede**: Accesso SSH, file zip pronto
