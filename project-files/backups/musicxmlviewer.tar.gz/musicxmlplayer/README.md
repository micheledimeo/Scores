# 🎼 MusicXML Player for Nextcloud 31.0.7+

## 📖 Overview

MusicXML Player è un'app per Nextcloud che permette di visualizzare e riprodurre file musicali MusicXML direttamente nel browser usando [OpenSheetMusicDisplay (OSMD)](https://github.com/opensheetmusicdisplay/opensheetmusicdisplay).

## ✨ Features

- 🎵 Visualizzazione spartiti musicali (MusicXML, .mxml, .xml)
- 🎹 Rendering professionale con OSMD
- ▶️ Controlli playback integrati
- 🎚️ Controllo tempo e volume
- 📚 Integrazione con Files app di Nextcloud
- 🔒 Content Security Policy compatibile con NC 31+

## 🚀 Quick Start

### Installazione

```bash
# 1. Upload dell'archivio
scp musicxmlplayer_NC31_FIXED.zip user@server:/path/to/nextcloud/apps/

# 2. Connessione al server
ssh user@server
cd /path/to/nextcloud/apps/

# 3. Installazione
unzip musicxmlplayer_NC31_FIXED.zip
chown -R www-data:www-data musicxmlplayer/
chmod -R 755 musicxmlplayer/
php occ app:enable musicxmlplayer
```

### Utilizzo

1. Carica file `.musicxml` nella tua libreria Nextcloud
2. Apri l'app MusicXML Player
3. Seleziona un file dalla lista
4. Visualizza e riproduci il tuo spartito!

## 📋 Requisiti

- Nextcloud **31.0.0** o superiore
- PHP **8.1** o superiore
- Browser moderno con supporto Web Audio API

## 🔧 Compatibilità Nextcloud 31

Questa versione include i fix necessari per Nextcloud 31.0.7:

- ✅ CSP Provider aggiornato per nuove API
- ✅ Compatibilità con `AddContentSecurityPolicyEvent`
- ✅ Rimozione metodi deprecati (`getPolicy()`, `allowInlineScript()`)

## 📚 Documentazione

- **[COMPLETE_SUMMARY.md](COMPLETE_SUMMARY.md)** - Riepilogo completo del progetto
- **[NEXTCLOUD_31_FIX_SUMMARY.md](NEXTCLOUD_31_FIX_SUMMARY.md)** - Dettagli tecnici fix NC31
- **[INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md)** - Guida installazione completa
- **[QUICK_DEPLOY.md](QUICK_DEPLOY.md)** - Procedura deploy rapido

## 🏗️ Struttura Progetto

```
musicxmlplayer/
├── appinfo/
│   ├── info.xml              # App metadata
│   └── routes.php            # API routes
├── lib/
│   ├── AppInfo/
│   │   └── Application.php   # App bootstrap
│   ├── Controller/
│   │   └── PageController.php # Main controller
│   └── Service/
│       └── CSPProvider.php   # Content Security Policy
├── templates/
│   └── index.php             # Main UI template
├── js/
│   ├── musicxmlplayer.js     # Player logic
│   ├── opensheetmusicdisplay.min.js
│   ├── osmd-playback-engine.js
│   └── ...                   # Altri file JS
├── css/
│   └── style.css             # Styling
└── img/
    └── app.svg               # App icon
```

## 🔒 Security (CSP)

Il CSP Provider configura le policy di sicurezza per permettere:
- OSMD rendering (SVG, Canvas)
- Web Workers per audio processing
- Data URIs per contenuti embed
- Blob URIs per risorse generate dinamicamente

## 🐛 Troubleshooting

### App non si abilita

```bash
php occ app:check musicxmlplayer
php occ maintenance:repair
```

### Errori CSP

Verifica che `lib/Service/CSPProvider.php` usi le API corrette di NC31:
- `new ContentSecurityPolicy()` invece di `$event->getPolicy()`
- `$event->addPolicy($csp)` per applicare la policy

### Spartiti non si caricano

1. Controlla console browser per errori
2. Verifica che i file OSMD JS siano presenti
3. Controlla permessi file

## 🤝 Contributing

Contributi benvenuti! Per problemi o suggerimenti, apri una issue.

## 📝 License

AGPL-3.0

## 👨‍💻 Author

Michele - Specialista in tassazione internazionale e sviluppatore Python/JavaScript

## 🔗 Links

- [OSMD GitHub](https://github.com/opensheetmusicdisplay/opensheetmusicdisplay)
- [Nextcloud Apps](https://apps.nextcloud.com/)
- [Nextcloud Developer Docs](https://docs.nextcloud.com/server/latest/developer_manual/)

---

**Version**: 1.0.0-NC31
**Nextcloud**: 31.0.7+
**Last Updated**: 17 Ottobre 2025
