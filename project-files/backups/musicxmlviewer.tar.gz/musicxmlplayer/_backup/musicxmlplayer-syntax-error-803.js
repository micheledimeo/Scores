/**
 * MusicXML Player v2.1 - FINAL CLEAN VERSION
 * Rebuilt from scratch - No orphan code, duplications or syntax errors
 * Comprehensive analysis and reconstruction completed
 */
console.log('🔄 MusicXML Player v2.1 - COMPLETELY REBUILT VERSION - Timestamp:', new Date().toISOString());

class MusicXMLPlayer {
    constructor() {
        this.osmd = null;
        this.workingOSMD = null;
        this.currentFile = null;
        this.isInitialized = false;
        this.isPlaying = false;
        this.currentTempo = 120;
        this.currentVolume = 80;
        this.currentPosition = 0;
        this.positionTimer = null;
        this.visualProgressTimer = null;
        this.audioContext = null;
        this.playButton = null;
        this.statusDisplay = null;
        this.positionDisplay = null;
        this.playbackInfoShown = false;
        console.log('🎼 MusicXML Player v2.1 initialized');
    }

    async init() {
        try {
            console.log('🎼 Initializing MusicXML Player v2.1...');
            await this.loadFilesList();
            this.showWelcomeGuide(true);
            this.showScoreContainer(false);
            
            console.log('✅ MusicXML Player v2.1 initialized successfully');
            window.player = this;
            this.isInitialized = true;
        } catch (error) {
            console.error('❌ Player initialization failed:', error);
        }
    }

    showWelcomeGuide(show) {
        const guide = document.getElementById('welcome-guide');
        if (guide) {
            if (show) {
                guide.style.display = 'flex';
                guide.style.visibility = 'visible';
                guide.style.opacity = '1';
                guide.style.zIndex = '100';
            } else {
                guide.style.display = 'none';
                guide.style.visibility = 'hidden';
                guide.style.opacity = '0';
                guide.style.zIndex = '-1000';
            }
        }
    }

    showScoreContainer(show) {
        const container = document.getElementById('score-container');
        if (container) {
            if (show) {
                container.style.cssText = `
                    position: absolute !important;
                    top: 0 !important;
                    left: 0 !important;
                    right: 0 !important;
                    bottom: 0 !important;
                    width: 100% !important;
                    height: 100% !important;
                    background: #ffffff !important;
                    z-index: 5 !important;
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                `;
                container.offsetHeight;
                console.log('✅ Score container forced visible');
            } else {
                container.style.display = 'none';
            }
        }
    }

    async loadFilesList() {
        try {
            const response = await fetch(OC.generateUrl('/apps/musicxmlplayer/files'));
            const data = await response.json();
            this.renderFilesList(data.files || []);
        } catch (error) {
            console.error('❌ Error loading files:', error);
            this.renderFilesList([]);
        }
    }

    renderFilesList(files) {
        const container = document.getElementById('files-list-container');
        if (!container) return;

        container.innerHTML = '';
        
        files.forEach(file => {
            const fileElement = document.createElement('div');
            fileElement.className = 'file-item';
            fileElement.style.cssText = `
                padding: 12px 15px;
                border: 1px solid #e2e8f0;
                border-radius: 8px;
                background: #f8fafc;
                cursor: pointer;
                margin-bottom: 8px;
            `;
            
            fileElement.innerHTML = `
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div style="
                        width: 32px; height: 32px; 
                        background: #6366f1;
                        border-radius: 6px; display: flex; align-items: center; justify-content: center;
                        color: white;
                    ">🎵</div>
                    <div style="flex: 1;">
                        <div style="font-weight: 600; color: #1e293b; font-size: 13px;">${file.name}</div>
                        <div style="color: #64748b; font-size: 11px;">${this.formatFileSize(file.size)}</div>
                    </div>
                </div>
            `;
            
            fileElement.addEventListener('click', () => this.selectFile(file));
            container.appendChild(fileElement);
        });
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }

    async selectFile(file) {
        console.log('🎵 Loading file:', file.name);
        
        try {
            this.showWelcomeGuide(false);
            this.showScoreContainer(true);
            
            await new Promise(resolve => setTimeout(resolve, 200));
            
            const xmlContent = await this.fetchFileContent(file);
            await this.loadOSMD(xmlContent, file);
            
            this.currentFile = file;
            
            // FORCE TEST AUDIO after loading
            console.log('🔊 POST-LOAD: Testing audio availability...');
            if (this.simpleAudioPlayer) {
                console.log('🎵 Simple Audio Player is available - testing...');
                
                // Test single note
                setTimeout(() => {
                    if (this.simpleAudioPlayer && this.simpleAudioPlayer.playNote) {
                        this.simpleAudioPlayer.playNote(440, 0.3); // A4 test note
                        console.log('🎵 Test note played: 440Hz');
                    }
                }, 1000);
            }
            
            
        } catch (error) {
            console.error('❌ Error selecting file:', error);
            alert(`Error loading ${file.name}: ${error.message}`);
        }
    }

    async loadOSMD(xmlContent, file) {
        console.log('🎼 Loading OSMD...');
        
        const container = document.getElementById('osmd-container');
        if (!container) {
            throw new Error('OSMD container not found');
        }
        
        // Setup container with proper dimensions
        container.style.cssText = `
            width: 100% !important;
            height: 100% !important;
            min-width: 800px !important;
            min-height: 600px !important;
            background: white !important;
            padding: 20px !important;
            display: block !important;
            visibility: visible !important;
        `;
        
        container.innerHTML = '';
        
        // Create header with back button
        const header = document.createElement('div');
        header.style.cssText = `
            background: #6366f1;
            color: white;
            padding: 10px 15px;
            margin: -20px -20px 15px -20px;
            font-weight: bold;
            border-radius: 6px 6px 0 0;
            display: flex;
            justify-content: space-between;
        `;
        header.innerHTML = `
            <span>🎼 ${file.name}</span>
            <button id="back-to-library-btn" style="
                background: rgba(255,255,255,0.2);
                border: none;
                color: white;
                padding: 4px 8px;
                border-radius: 3px;
                cursor: pointer;
                font-size: 11px;
            ">← Back</button>
        `;
        container.appendChild(header);
        
        // Add event listener to back button
        const backBtn = header.querySelector('#back-to-library-btn');
        backBtn.addEventListener('click', () => {
            this.showWelcomeGuide(true);
            this.showScoreContainer(false);
        });
        
        // Create render area with fixed dimensions
        const renderArea = document.createElement('div');
        renderArea.style.cssText = `
            width: 750px !important;
            height: 500px !important;
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 15px;
            margin: 0 auto;
        `;
        container.appendChild(renderArea);
        
        // Force DOM update and wait
        renderArea.offsetHeight;
        await new Promise(resolve => setTimeout(resolve, 300));
        
        const rect = renderArea.getBoundingClientRect();
        console.log(`📐 Render area: ${rect.width}x${rect.height}`);
        
        if (rect.width > 500 && rect.height > 300) {
            try {
                if (typeof window.opensheetmusicdisplay === 'undefined') {
                    throw new Error('OSMD library not available');
                }
                
                // Initialize OSMD
                this.workingOSMD = new window.opensheetmusicdisplay.OpenSheetMusicDisplay(renderArea, {
                    autoResize: false,
                    backend: 'svg',
                    drawTitle: true,
                    drawComposer: true,
                    pageFormat: 'Endless'
                });
                
                console.log('🎵 Loading XML...');
                await this.workingOSMD.load(xmlContent);
                
                console.log('🎨 Rendering...');
                await this.workingOSMD.render();
                
                console.log('✅ Score loaded!');
                
                // Initialize cursor for visual playback
                if (this.workingOSMD.cursor) {
                    this.workingOSMD.cursor.reset();
                    this.workingOSMD.cursor.hide();
                    console.log('🎯 Playback cursor initialized');
                } else {
                    console.warn('⚠️ OSMD cursor not available');
                }
                
                // Debug OSMD capabilities
                console.log('🔍 OSMD Debug Info:');
                console.log('- PlaybackManager available:', !!window.opensheetmusicdisplay.PlaybackManager);
                console.log('- Cursor available:', !!this.workingOSMD.cursor);
                console.log('- Audio support:', !!window.AudioContext || !!window.webkitAudioContext);
                
                // FORCE audio initialization immediately
                console.log('🔄 Force-initializing audio systems...');
                const audioInit = await this.initializeOSMDPlayback();
                
                if (!audioInit) {
                    console.log('🎵 OSMD audio failed, forcing Simple Audio Player...');
                    await this.forceSimpleAudio();
                }
                
                // Add controls
                console.log('🎮 Adding transport controls...');
                this.addControls(container);
                
                // Force controls visibility check
                setTimeout(() => {
                    const controls = container.querySelector('.transport-controls');
                    if (controls) {
                        console.log('✅ Controls added and found in DOM');
                        console.log('Controls position:', controls.getBoundingClientRect());
                    } else {
                        console.error('❌ Controls not found after adding - trying emergency fix');
                        this.addEmergencyControls(container);
                    }
                }, 500);
                
            } catch (error) {
                console.error('❌ OSMD failed:', error);
                renderArea.innerHTML = `
                    <div style="text-align: center; padding: 50px; color: #ef4444;">
                        <h3>❌ Cannot Display Score</h3>
                        <p>${error.message}</p>
                    </div>
                `;
            }
        } else {
            renderArea.innerHTML = `
                <div style="text-align: center; padding: 50px; color: #ef4444;">
                    <h3>❌ Invalid Container</h3>
                    <p>Dimensions: ${rect.width}x${rect.height}</p>
                </div>
            `;
        }
    }

    addControls(container) {
        // Remove any existing controls
        const existing = container.querySelector('.transport-controls');
        if (existing) existing.remove();
        
        const controls = document.createElement('div');
        controls.className = 'transport-controls';
        controls.style.cssText = `
            position: absolute;
            bottom: 15px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(255,255,255,0.95);
            padding: 12px 20px;
            border-radius: 25px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            display: flex;
            gap: 15px;
            align-items: center;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(99, 102, 241, 0.2);
        `;
        
        // Play/Pause Button
        const playBtn = document.createElement('button');
        playBtn.innerHTML = '▶️';
        playBtn.title = 'Play/Pause';
        playBtn.style.cssText = `
            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 8px 15px;
            cursor: pointer;
            font-size: 16px;
            min-width: 45px;
            height: 35px;
            transition: all 0.2s ease;
            box-shadow: 0 2px 8px rgba(99, 102, 241, 0.3);
        `;
        
        playBtn.addEventListener('mouseenter', () => {
            playBtn.style.transform = 'translateY(-1px)';
            playBtn.style.boxShadow = '0 4px 12px rgba(99, 102, 241, 0.4)';
        });
        
        playBtn.addEventListener('mouseleave', () => {
            playBtn.style.transform = 'translateY(0)';
            playBtn.style.boxShadow = '0 2px 8px rgba(99, 102, 241, 0.3)';
        });
        
        playBtn.onclick = () => this.togglePlayback(playBtn);
        
        // Stop Button
        const stopBtn = document.createElement('button');
        stopBtn.innerHTML = '⏹️';
        stopBtn.title = 'Stop';
        stopBtn.style.cssText = `
            background: #ef4444;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 6px 12px;
            cursor: pointer;
            font-size: 14px;
            height: 35px;
            transition: all 0.2s ease;
        `;
        stopBtn.onclick = () => this.stopPlayback(playBtn);
        
        // Status Display
        const status = document.createElement('span');
        status.textContent = 'Ready';
        status.style.cssText = 'color: #10b981; font-size: 10px; font-weight: 600; opacity: 0.8;';
        
        // Position Display
        const position = document.createElement('span');
        position.textContent = '00:00';
        position.style.cssText = 'color: #64748b; font-size: 11px; font-weight: 600; font-family: monospace;';
        
        // Assemble controls
        controls.appendChild(playBtn);
        controls.appendChild(stopBtn);
        controls.appendChild(status);
        controls.appendChild(position);
        
        container.appendChild(controls);
        
        // Store references
        this.playButton = playBtn;
        this.statusDisplay = status;
        this.positionDisplay = position;
        
        console.log('🎮 Transport controls added');
    }

    addEmergencyControls(container) {
        console.log('🚨 Adding emergency controls - forcing visibility');
        
        // Remove any existing controls
        const existing = document.querySelectorAll('.transport-controls');
        existing.forEach(el => el.remove());
        
        const controls = document.createElement('div');
        controls.className = 'transport-controls emergency-controls';
        controls.style.cssText = `
            position: fixed !important;
            bottom: 30px !important;
            left: 50% !important;
            transform: translateX(-50%) !important;
            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%) !important;
            color: white !important;
            padding: 15px 25px !important;
            border-radius: 25px !important;
            box-shadow: 0 10px 30px rgba(99, 102, 241, 0.4) !important;
            display: flex !important;
            gap: 15px !important;
            align-items: center !important;
            z-index: 99999 !important;
            font-family: system-ui !important;
            border: 2px solid rgba(255,255,255,0.2) !important;
        `;
        
        // Emergency play button
        const playBtn = document.createElement('button');
        playBtn.innerHTML = '▶️';
        playBtn.title = 'Play/Pause';
        playBtn.style.cssText = `
            background: rgba(255,255,255,0.9) !important;
            color: #6366f1 !important;
            border: none !important;
            border-radius: 12px !important;
            padding: 8px 12px !important;
            cursor: pointer !important;
            font-size: 14px !important;
            min-width: 40px !important;
            height: 35px !important;
        `;
        
        playBtn.addEventListener('click', () => {
            this.togglePlayback(playBtn);
        });
        
        // Emergency stop button
        const stopBtn = document.createElement('button');
        stopBtn.innerHTML = '⏹️';
        stopBtn.title = 'Stop';
        stopBtn.style.cssText = `
            background: rgba(239, 68, 68, 0.8) !important;
            color: white !important;
            border: none !important;
            border-radius: 8px !important;
            padding: 6px 10px !important;
            cursor: pointer !important;
            font-size: 12px !important;
            height: 35px !important;
        `;
        
        stopBtn.addEventListener('click', () => {
            this.stopPlayback(playBtn);
        });
        
        // Status and position
        const status = document.createElement('span');
        status.textContent = 'Emergency Mode';
        status.style.cssText = 'color: rgba(255,255,255,0.9) !important; font-size: 11px !important; font-weight: 600 !important;';
        
        const position = document.createElement('span');
        position.textContent = '00:00';
        position.style.cssText = 'color: rgba(255,255,255,0.8) !important; font-size: 11px !important; font-weight: 600 !important; font-family: monospace !important;';
        
        controls.appendChild(playBtn);
        controls.appendChild(stopBtn);
        controls.appendChild(status);
        controls.appendChild(position);
        
        document.body.appendChild(controls);
        
        // Store references
        this.playButton = playBtn;
        this.statusDisplay = status;
        this.positionDisplay = position;
        
        console.log('🚨 Emergency controls added to body');
        
        // Add warning notice
        const notice = document.createElement('div');
        notice.style.cssText = `
            position: fixed !important;
            top: 20px !important;
            right: 20px !important;
            background: #f59e0b !important;
            color: white !important;
            padding: 10px 15px !important;
            border-radius: 8px !important;
            font-size: 12px !important;
            z-index: 99998 !important;
            max-width: 250px !important;
        `;
        notice.innerHTML = `
            ⚠️ <strong>Emergency Controls Mode</strong><br>
            Controlli posizionati forzatamente in fondo alla pagina
        `;
        document.body.appendChild(notice);
        
        setTimeout(() => notice.remove(), 5000);
    }

    // === PLAYBACK METHODS ===
    
    togglePlayback(playButton) {
        if (this.isPlaying) {
            this.pausePlayback(playButton);
        } else {
            this.startPlayback(playButton);
        }
    }

    async startPlayback(playButton) {
        console.log('▶️ Starting playback...');
        
        // Ensure audio context is running
        if (this.audioContext && this.audioContext.state === 'suspended') {
            try {
                await this.audioContext.resume();
                console.log('🔊 Audio context resumed');
            } catch (error) {
                console.warn('⚠️ Could not resume audio context:', error);
            }
        }
        
        // Try to initialize OSMD Playback first
        if (this.workingOSMD && !this.workingOSMD.PlaybackManager) {
            await this.initializeOSMDPlayback();
        }
        
        // Check if OSMD Playback Engine is available
        if (this.workingOSMD && this.workingOSMD.PlaybackManager) {
            try {
                console.log('🎵 Starting OSMD audio playback');
                await this.workingOSMD.PlaybackManager.play();
                this.isPlaying = true;
                playButton.innerHTML = '⏸️';
                this.statusDisplay.textContent = 'Playing (Audio)';
                this.statusDisplay.style.color = '#22c55e';
                this.startOSMDPositionTracking();
                return;
            } catch (error) {
                console.warn('⚠️ OSMD PlaybackManager failed:', error);
                console.log('📄 Trying simple audio fallback');
            }
        }
        
        // Try simple audio player
        if (this.simpleAudioPlayer) {
            try {
                console.log('🎵 Starting simple audio playback');
                this.simpleAudioPlayer.start();
                this.isPlaying = true;
                playButton.innerHTML = '⏸️';
                this.statusDisplay.textContent = 'Playing (Simple Audio)';
                this.statusDisplay.style.color = '#22c55e';
                this.startPositionTimer();
                this.startVisualHighlighting();
                return;
            } catch (error) {
                console.warn('⚠️ Simple audio failed:', error);
            }
        }
        
        // Fallback: Visual playback mode
        this.simulatePlayback(playButton);
    }

    async initializeOSMDPlayback() {
        try {
            console.log('🎼 Initializing OSMD Playback Engine with Audio...');
            
            // Check if OSMD PlaybackManager is available
            if (!window.opensheetmusicdisplay.PlaybackManager) {
                console.warn('⚠️ OSMD PlaybackManager not available in this build');
                console.log('🔄 Trying alternative audio approach...');
                return await this.initializeSimpleAudio();
            }
            
            if (this.workingOSMD && window.opensheetmusicdisplay.PlaybackManager) {
                this.workingOSMD.PlaybackManager = new window.opensheetmusicdisplay.PlaybackManager();
                
                // Setup Audio Context
                if (!this.audioContext) {
                    this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                    console.log('🔊 Audio context created, state:', this.audioContext.state);
                    
                    if (this.audioContext.state === 'suspended') {
                        await this.audioContext.resume();
                        console.log('🔊 Audio context resumed');
                    }
                }
                
                // Load Audio Worklet
                try {
                    await this.audioContext.audioWorklet.addModule('/apps/musicxmlplayer/js/osmd-audio-worklet.js');
                    console.log('✅ Audio worklet loaded successfully');
                } catch (workletError) {
                    console.warn('⚠️ Audio worklet failed to load:', workletError);
                    // Continue without worklet
                }
                
                // Initialize PlaybackManager with SoundFont
                const config = {
                    scoreFollowingMode: true,
                    audioContext: this.audioContext,
                    masterVolume: this.currentVolume / 100,
                    bpm: this.currentTempo,
                    enableCursor: true,
                    cursorColor: '#ef4444'
                };
                
                // Add SoundFont if available
                try {
                    config.soundfontUrl = '/apps/musicxmlplayer/sounds/GeneralUser_GS.sf2';
                    console.log('🎵 Configuring with SoundFont:', config.soundfontUrl);
                } catch (sfError) {
                    console.warn('⚠️ SoundFont not configured:', sfError);
                }
                
                await this.workingOSMD.PlaybackManager.initialize(config);
                
                console.log('✅ OSMD Playback Engine initialized with audio');
                return true;
            }
        } catch (error) {
            console.warn('⚠️ OSMD Playback initialization failed:', error);
            console.log('🔄 Falling back to simple audio...');
            return await this.initializeSimpleAudio();
        }
        return false;
    }

    async initializeSimpleAudio() {
        try {
            console.log('🎵 Initializing Simple Audio Player...');
            
            if (!this.audioContext) {
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                
                if (this.audioContext.state === 'suspended') {
                    await this.audioContext.resume();
                }
            }
            
            // Load simple audio player if not already loaded
            if (!window.SimpleAudioPlayer) {
                const script = document.createElement('script');
                script.src = '/apps/musicxmlplayer/js/simple-audio-player.js';
                document.head.appendChild(script);
                
                await new Promise((resolve, reject) => {
                    script.onload = resolve;
                    script.onerror = reject;
                });
            }
            
            this.simpleAudioPlayer = new window.SimpleAudioPlayer(this.audioContext);
            console.log('✅ Simple Audio Player initialized');
            return true;
            
        } catch (error) {
            console.warn('⚠️ Simple audio initialization failed:', error);
            return false;
        }
    }

    async forceSimpleAudio() {
        console.log('🔊 FORCE: Initializing Simple Audio Player...');
        
        try {
            // Create audio context immediately
            if (!this.audioContext) {
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                console.log('🔊 Audio context created:', this.audioContext.state);
            }
            
            // Resume if suspended
            if (this.audioContext.state === 'suspended') {
                await this.audioContext.resume();
                console.log('🔊 Audio context resumed');
            }
            
            // Create simple audio player inline (don't wait for external script)
            this.simpleAudioPlayer = {
                audioContext: this.audioContext,
                isPlaying: false,
                gain: null,
                currentNoteIndex: 0,
                
                init() {
                    this.gain = this.audioContext.createGain();
                    this.gain.connect(this.audioContext.destination);
                    this.gain.gain.value = 0.3;
                },
                
                getNoteFrequency(noteIndex) {
                    const frequencies = [261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25]; // C major scale
                    return frequencies[noteIndex % frequencies.length];
                },
                
                playNote(frequency, duration = 0.8) {
                    const oscillator = this.audioContext.createOscillator();
                    const noteGain = this.audioContext.createGain();
                    
                    oscillator.type = 'sine';
                    oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime);
                    
                    // Envelope
                    noteGain.gain.setValueAtTime(0, this.audioContext.currentTime);
                    noteGain.gain.linearRampToValueAtTime(0.3, this.audioContext.currentTime + 0.01);
                    noteGain.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration);
                    
                    oscillator.connect(noteGain);
                    noteGain.connect(this.gain);
                    
                    oscillator.start(this.audioContext.currentTime);
                    oscillator.stop(this.audioContext.currentTime + duration);
                    
                    console.log('🎵 Playing note:', frequency.toFixed(2), 'Hz');
                },
                
                start() {
                    this.isPlaying = true;
                    this.playSequence();
                },
                
                playSequence() {
                    if (!this.isPlaying) return;
                    
                    const freq = this.getNoteFrequency(this.currentNoteIndex);
                    this.playNote(freq);
                    this.currentNoteIndex++;
                    
                    if (this.currentNoteIndex >= 8) {
                        this.currentNoteIndex = 0; // Loop
                    }
                    
                    setTimeout(() => this.playSequence(), 600);
                },
                
                pause() {
                    this.isPlaying = false;
                },
                
                stop() {
                    this.isPlaying = false;
                    this.currentNoteIndex = 0;
                }
            };
            
            this.simpleAudioPlayer.init();
            console.log('✅ FORCE: Simple Audio Player ready');
            
            return true;
            
        } catch (error) {
            console.error('❌ FORCE: Simple audio initialization failed:', error);
            return false;
        }
    }
                
                console.log('✅ OSMD Playback Engine initialized with audio');
                return true;
            }
        } catch (error) {
            console.warn('⚠️ OSMD Playback initialization failed:', error);
        }
        return false;
    }

    startOSMDPositionTracking() {
        if (this.workingOSMD.PlaybackManager && this.workingOSMD.PlaybackManager.CurrentTimeInMS !== undefined) {
            this.stopPositionTimer();
            this.positionTimer = setInterval(() => {
                if (this.isPlaying && this.workingOSMD.PlaybackManager) {
                    const currentTimeMs = this.workingOSMD.PlaybackManager.CurrentTimeInMS || 0;
                    const currentTimeSec = Math.floor(currentTimeMs / 1000);
                    const minutes = Math.floor(currentTimeSec / 60);
                    const seconds = currentTimeSec % 60;
                    this.positionDisplay.textContent = 
                        `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                    this.currentPosition = currentTimeSec;
                }
            }, 100);
        } else {
            this.startPositionTimer();
        }
    }

    pausePlayback(playButton) {
        console.log('⏸️ Pausing playback...');
        
        if (this.workingOSMD && this.workingOSMD.PlaybackManager) {
            try {
                this.workingOSMD.PlaybackManager.pause();
                console.log('🎵 OSMD audio paused');
            } catch (error) {
                console.warn('⚠️ OSMD pause failed:', error);
            }
        }
        
        if (this.simpleAudioPlayer) {
            try {
                this.simpleAudioPlayer.pause();
                console.log('🎵 Simple audio paused');
            } catch (error) {
                console.warn('⚠️ Simple audio pause failed:', error);
            }
        }
        
        this.isPlaying = false;
        playButton.innerHTML = '▶️';
        this.statusDisplay.textContent = 'Paused';
        this.statusDisplay.style.color = '#f59e0b';
        this.stopPositionTimer();
        this.stopVisualHighlighting();
    }

    stopPlayback(playButton) {
        console.log('⏹️ Stopping playback...');
        
        if (this.workingOSMD && this.workingOSMD.PlaybackManager) {
            try {
                this.workingOSMD.PlaybackManager.stop();
                console.log('🎵 OSMD audio stopped');
            } catch (error) {
                console.warn('⚠️ OSMD stop failed:', error);
            }
        }
        
        if (this.simpleAudioPlayer) {
            try {
                this.simpleAudioPlayer.stop();
                console.log('🎵 Simple audio stopped');
            } catch (error) {
                console.warn('⚠️ Simple audio stop failed:', error);
            }
        }
        
        this.isPlaying = false;
        playButton.innerHTML = '▶️';
        this.statusDisplay.textContent = 'Ready';
        this.statusDisplay.style.color = '#10b981';
        this.positionDisplay.textContent = '00:00';
        this.stopPositionTimer();
        this.stopVisualHighlighting();
        this.currentPosition = 0;
        
        if (this.workingOSMD && this.workingOSMD.cursor) {
            try {
                this.workingOSMD.cursor.reset();
                this.workingOSMD.cursor.hide();
            } catch (error) {
                // Ignore cursor errors
            }
        }
    }

    simulatePlayback(playButton) {
        console.log('🎼 Starting visual playback mode (no audio)');
        
        this.isPlaying = true;
        playButton.innerHTML = '⏸️';
        this.statusDisplay.textContent = 'Playing (Visual)';
        this.statusDisplay.style.color = '#8b5cf6';
        this.currentPosition = 0;
        this.startPositionTimer();
        
        this.showPlaybackInfo();
        this.startVisualHighlighting();
    }

    startVisualHighlighting() {
        if (this.workingOSMD && this.workingOSMD.cursor) {
            try {
                console.log('🎯 Starting visual highlighting with cursor');
                this.workingOSMD.cursor.reset();
                this.workingOSMD.cursor.show();
                
                // Force cursor visibility with custom styling
                setTimeout(() => {
                    const cursorElements = document.querySelectorAll('.cursor');
                    cursorElements.forEach(el => {
                        el.style.fill = '#ef4444';
                        el.style.opacity = '0.8';
                        el.style.stroke = '#dc2626';
                        el.style.strokeWidth = '2px';
                        console.log('🎯 Cursor element styled:', el);
                    });
                }, 100);
                
                this.visualProgressTimer = setInterval(() => {
                    if (this.isPlaying && this.workingOSMD.cursor) {
                        try {
                            this.workingOSMD.cursor.next();
                            
                            // Re-style cursor after each move
                            const cursorElements = document.querySelectorAll('.cursor');
                            cursorElements.forEach(el => {
                                el.style.fill = '#ef4444';
                                el.style.opacity = '0.8';
                            });
                            
                            if (this.workingOSMD.cursor.Iterator.EndReached) {
                                console.log('🎯 Cursor reached end of score');
                                this.stopPlayback(this.playButton);
                            }
                        } catch (error) {
                            console.log('📄 Visual highlighting completed or error:', error.message);
                        }
                    }
                }, 600);
            } catch (error) {
                console.log('📄 Visual highlighting not available:', error.message);
            }
        }
    }

    stopVisualHighlighting() {
        if (this.visualProgressTimer) {
            clearInterval(this.visualProgressTimer);
            this.visualProgressTimer = null;
        }
        
        if (this.workingOSMD && this.workingOSMD.cursor) {
            try {
                this.workingOSMD.cursor.hide();
            } catch (error) {
                // Ignore cursor errors
            }
        }
    }

    startPositionTimer() {
        if (this.positionTimer) {
            clearInterval(this.positionTimer);
        }
        
        this.positionTimer = setInterval(() => {
            if (this.isPlaying) {
                this.currentPosition += 1;
                const minutes = Math.floor(this.currentPosition / 60);
                const seconds = this.currentPosition % 60;
                this.positionDisplay.textContent = 
                    `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
        }, 1000);
    }

    stopPositionTimer() {
        if (this.positionTimer) {
            clearInterval(this.positionTimer);
            this.positionTimer = null;
        }
    }

    // === UI METHODS ===
    
    showPlaybackInfo() {
        if (this.playbackInfoShown) return;
        this.playbackInfoShown = true;
        
        const info = document.createElement('div');
        info.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px 35px;
            border-radius: 15px;
            z-index: 9999;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            text-align: center;
            max-width: 400px;
            backdrop-filter: blur(20px);
        `;
        
        info.innerHTML = `
            <div style="font-size: 48px; margin-bottom: 20px;">🎼</div>
            <div style="font-weight: 700; margin-bottom: 12px; font-size: 18px;">Visual Playback Mode</div>
            <div style="font-size: 14px; margin-bottom: 20px; opacity: 0.9; line-height: 1.4;">
                Il timer e i controlli simulano la riproduzione con evidenziazione visuale delle note. 
                Per l'audio completo è necessario configurare l'OSMD Playback Engine con Web Audio API.
            </div>
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 15px; flex-wrap: wrap;">
                <div style="background: rgba(255,255,255,0.2); padding: 4px 8px; border-radius: 12px; font-size: 11px;">
                    ▶️ Play/Pause Visuale
                </div>
                <div style="background: rgba(255,255,255,0.2); padding: 4px 8px; border-radius: 12px; font-size: 11px;">
                    🎯 Cursore Note
                </div>
                <div style="background: rgba(255,255,255,0.2); padding: 4px 8px; border-radius: 12px; font-size: 11px;">
                    ⏱️ Timer Posizione
                </div>
            </div>
            <div style="font-size: 12px; margin-bottom: 20px; opacity: 0.8; line-height: 1.3;">
                <strong>🔊 Per Audio Reale:</strong><br>
                • Configurare Web Audio API<br>
                • Caricare SoundFont (SF2)<br>
                • Abilitare OSMD PlaybackManager
            </div>
            <button id="playback-info-close-btn" style="
                background: rgba(255, 255, 255, 0.25);
                border: 1px solid rgba(255, 255, 255, 0.3);
                color: white;
                padding: 8px 20px;
                border-radius: 20px;
                cursor: pointer;
                font-weight: 600;
                transition: all 0.2s ease;
            ">
                Perfetto, Continua
            </button>
        `;
        
        document.body.appendChild(info);
        
        const closeBtn = info.querySelector('#playback-info-close-btn');
        closeBtn.addEventListener('click', () => {
            info.remove();
        });
        
        closeBtn.addEventListener('mouseenter', () => {
            closeBtn.style.background = 'rgba(255,255,255,0.35)';
        });
        
        closeBtn.addEventListener('mouseleave', () => {
            closeBtn.style.background = 'rgba(255,255,255,0.25)';
        });
        
        setTimeout(() => {
            if (info.parentElement) {
                info.remove();
            }
        }, 10000);
    }

    // === FILE PROCESSING METHODS ===
    
    async fetchFileContent(file) {
        try {
            console.log('📡 Fetching:', file.name);
            const response = await fetch(OC.generateUrl('/apps/musicxmlplayer/file/{fileId}', {fileId: file.id}));
            const rawResponse = await response.text();
            
            let xmlContent;
            if (rawResponse.trim().startsWith('{')) {
                const jsonData = JSON.parse(rawResponse);
                xmlContent = jsonData.content || rawResponse;
            } else {
                xmlContent = rawResponse;
            }
            
            return this.cleanXML(xmlContent);
        } catch (error) {
            console.error('❌ Fetch failed:', error);
            throw error;
        }
    }

    cleanXML(xmlContent) {
        console.log('🧹 Cleaning XML...');
        
        if (xmlContent.charCodeAt(0) === 0xFEFF) {
            xmlContent = xmlContent.slice(1);
        }
        
        xmlContent = xmlContent.trim();
        
        if (!xmlContent.startsWith('<?xml')) {
            xmlContent = '<?xml version="1.0" encoding="UTF-8"?>\n' + xmlContent;
        }
        
        console.log('✅ XML cleaned');
        return xmlContent;
    }

    // === UTILITY METHODS ===
    
    destroy() {
        console.log('🗑️ Cleaning up MusicXML Player...');
        
        this.stopPositionTimer();
        this.stopVisualHighlighting();
        
        if (this.workingOSMD) {
            try {
                if (this.workingOSMD.PlaybackManager && this.workingOSMD.PlaybackManager.stop) {
                    this.workingOSMD.PlaybackManager.stop();
                }
                if (this.workingOSMD.cursor) {
                    this.workingOSMD.cursor.hide();
                }
                this.workingOSMD.clear();
            } catch (error) {
                console.warn('⚠️ OSMD cleanup failed:', error);
            }
        }
        
        if (this.audioContext && this.audioContext.state !== 'closed') {
            try {
                this.audioContext.close();
            } catch (error) {
                console.warn('⚠️ Audio context cleanup failed:', error);
            }
        }
        
        this.isPlaying = false;
        this.currentPosition = 0;
        this.workingOSMD = null;
        this.currentFile = null;
        this.audioContext = null;
        
        console.log('✅ Cleanup completed');
    }

    getPlaybackState() {
        return {
            isPlaying: this.isPlaying,
            currentPosition: this.currentPosition,
            tempo: this.currentTempo,
            volume: this.currentVolume,
            hasOSMD: !!this.workingOSMD,
            currentFile: this.currentFile?.name || 'None'
        };
    }
}

// === INITIALIZATION ===
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Initializing MusicXML Player v2.1 - COMPLETELY REBUILT...');
    console.log('🕐 Timestamp:', new Date().toISOString());
    const player = new MusicXMLPlayer();
    player.init();
    if (!window.OCA) window.OCA = {};
    window.OCA.MusicXMLPlayer = player;
    console.log('✅ MusicXML Player v2.1 ready');
});
