/**
 * Quick Test Script for OSMD Integration
 * Add this to debug issues with container dimensions
 */

// Quick test function for debugging
window.testOSMDContainer = function() {
    console.log('🧪 Testing OSMD Container Setup...');
    
    const scoreArea = document.getElementById('score-area');
    const container = document.getElementById('osmd-container');
    
    console.log('📏 Score Area:', scoreArea ? scoreArea.getBoundingClientRect() : 'NOT FOUND');
    console.log('📏 OSMD Container:', container ? container.getBoundingClientRect() : 'NOT FOUND');
    
    if (container) {
        const computed = window.getComputedStyle(container);
        console.log('💄 Container CSS:', {
            display: computed.display,
            visibility: computed.visibility,
            width: computed.width,
            height: computed.height,
            minWidth: computed.minWidth,
            minHeight: computed.minHeight
        });
    }
    
    // Try emergency fix if needed
    if (container) {
        const rect = container.getBoundingClientRect();
        if (rect.width <= 0 || rect.height <= 0) {
            console.log('🚨 Container has invalid dimensions, applying emergency fix...');
            container.style.cssText += `
                width: 800px !important;
                height: 600px !important;
                min-width: 800px !important;
                min-height: 600px !important;
                display: block !important;
                visibility: visible !important;
                background: #fff !important;
                position: relative !important;
            `;
            container.offsetHeight; // Force reflow
            console.log('✅ Emergency fix applied, new dimensions:', container.getBoundingClientRect());
        } else {
            console.log('✅ Container dimensions are valid');
        }
    }
    
    return {
        scoreArea: scoreArea?.getBoundingClientRect(),
        container: container?.getBoundingClientRect(),
        ready: container && container.getBoundingClientRect().width > 0
    };
};

// Auto-run basic test when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        if (window.location.search.includes('debug')) {
            window.testOSMDContainer();
        }
    }, 1000);
});

console.log('🧪 OSMD Test utilities loaded. Run testOSMDContainer() to debug.');
