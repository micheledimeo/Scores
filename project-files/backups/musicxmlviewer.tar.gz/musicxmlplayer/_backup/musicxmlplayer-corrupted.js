/**
 * MusicXML Player v2.1 - COMPLETE WITH PLAYBACK CONTROLS
 * All methods properly structured within class
 */
class MusicXMLPlayer {
    constructor() {
        this.osmd = null;
        this.workingOSMD = null;
        this.currentFile = null;
        this.isInitialized = false;
        this.isPlaying = false;
        this.currentTempo = 120;
        this.currentVolume = 80;
        this.currentPosition = 0;
        this.positionTimer = null;
        this.playButton = null;
        this.statusDisplay = null;
        this.positionDisplay = null;
        this.playbackInfoShown = false;
        console.log('🎼 MusicXML Player v2.1 initialized');
    }

    async init() {
        try {
            console.log('🎼 Initializing MusicXML Player v2.1...');
            await this.loadFilesList();
            this.showWelcomeGuide(true);
            this.showScoreContainer(false);
            
            console.log('✅ MusicXML Player v2.1 initialized successfully');
            window.player = this;
            this.isInitialized = true;
        } catch (error) {
            console.error('❌ Player initialization failed:', error);
        }
    }

    showWelcomeGuide(show) {
        const guide = document.getElementById('welcome-guide');
        if (guide) {
            if (show) {
                guide.style.display = 'flex';
                guide.style.visibility = 'visible';
                guide.style.opacity = '1';
                guide.style.zIndex = '100';
            } else {
                guide.style.display = 'none';
                guide.style.visibility = 'hidden';
                guide.style.opacity = '0';
                guide.style.zIndex = '-1000';
            }
        }
    }

    showScoreContainer(show) {
        const container = document.getElementById('score-container');
        if (container) {
            if (show) {
                container.style.cssText = `
                    position: absolute !important;
                    top: 0 !important;
                    left: 0 !important;
                    right: 0 !important;
                    bottom: 0 !important;
                    width: 100% !important;
                    height: 100% !important;
                    background: #ffffff !important;
                    z-index: 5 !important;
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                `;
                container.offsetHeight;
                console.log('✅ Score container forced visible');
            } else {
                container.style.display = 'none';
            }
        }
    }

    async loadFilesList() {
        try {
            const response = await fetch(OC.generateUrl('/apps/musicxmlplayer/files'));
            const data = await response.json();
            this.renderFilesList(data.files || []);
        } catch (error) {
            console.error('❌ Error loading files:', error);
            this.renderFilesList([]);
        }
    }

    renderFilesList(files) {
        const container = document.getElementById('files-list-container');
        if (!container) return;

        container.innerHTML = '';
        
        files.forEach(file => {
            const fileElement = document.createElement('div');
            fileElement.className = 'file-item';
            fileElement.style.cssText = `
                padding: 12px 15px;
                border: 1px solid #e2e8f0;
                border-radius: 8px;
                background: #f8fafc;
                cursor: pointer;
                margin-bottom: 8px;
            `;
            
            fileElement.innerHTML = `
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div style="
                        width: 32px; height: 32px; 
                        background: #6366f1;
                        border-radius: 6px; display: flex; align-items: center; justify-content: center;
                        color: white;
                    ">🎵</div>
                    <div style="flex: 1;">
                        <div style="font-weight: 600; color: #1e293b; font-size: 13px;">${file.name}</div>
                        <div style="color: #64748b; font-size: 11px;">${this.formatFileSize(file.size)}</div>
                    </div>
                </div>
            `;
            
            fileElement.addEventListener('click', () => this.selectFile(file));
            container.appendChild(fileElement);
        });
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }

    async selectFile(file) {
        console.log('🎵 Loading file:', file.name);
        
        try {
            this.showWelcomeGuide(false);
            this.showScoreContainer(true);
            
            await new Promise(resolve => setTimeout(resolve, 200));
            
            const xmlContent = await this.fetchFileContent(file);
            await this.loadOSMD(xmlContent, file);
            
            this.currentFile = file;
            
        } catch (error) {
            console.error('❌ Error selecting file:', error);
            alert(`Error loading ${file.name}: ${error.message}`);
        }
    }

    async loadOSMD(xmlContent, file) {
        console.log('🎼 Loading OSMD...');
        
        const container = document.getElementById('osmd-container');
        if (!container) {
            throw new Error('OSMD container not found');
        }
        
        container.style.cssText = `
            width: 100% !important;
            height: 100% !important;
            min-width: 800px !important;
            min-height: 600px !important;
            background: white !important;
            padding: 20px !important;
            display: block !important;
            visibility: visible !important;
        `;
        
        container.innerHTML = '';
        
        const header = document.createElement('div');
        header.style.cssText = `
            background: #6366f1;
            color: white;
            padding: 10px 15px;
            margin: -20px -20px 15px -20px;
            font-weight: bold;
            border-radius: 6px 6px 0 0;
            display: flex;
            justify-content: space-between;
        `;
        header.innerHTML = `
            <span>🎼 ${file.name}</span>
            <button id="back-to-library-btn" style="
                background: rgba(255,255,255,0.2);
                border: none;
                color: white;
                padding: 4px 8px;
                border-radius: 3px;
                cursor: pointer;
                font-size: 11px;
            ">← Back</button>
        `;
        container.appendChild(header);
        
        // Add event listener to back button (CSP compliant)
        const backBtn = header.querySelector('#back-to-library-btn');
        backBtn.addEventListener('click', () => {
            this.showWelcomeGuide(true);
            this.showScoreContainer(false);
        });
        
        const renderArea = document.createElement('div');
        renderArea.style.cssText = `
            width: 750px !important;
            height: 500px !important;
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 15px;
            margin: 0 auto;
        `;
        container.appendChild(renderArea);
        
        renderArea.offsetHeight;
        await new Promise(resolve => setTimeout(resolve, 300));
        
        const rect = renderArea.getBoundingClientRect();
        console.log(`📐 Render area: ${rect.width}x${rect.height}`);
        
        if (rect.width > 500 && rect.height > 300) {
            try {
                if (typeof window.opensheetmusicdisplay === 'undefined') {
                    throw new Error('OSMD library not available');
                }
                
                this.workingOSMD = new window.opensheetmusicdisplay.OpenSheetMusicDisplay(renderArea, {
                    autoResize: false,
                    backend: 'svg',
                    drawTitle: true,
                    drawComposer: true,
                    pageFormat: 'Endless'
                });
                
                console.log('🎵 Loading XML...');
                await this.workingOSMD.load(xmlContent);
                
                console.log('🎨 Rendering...');
                await this.workingOSMD.render();
                
                console.log('✅ Score loaded!');
                
                // Add controls with debug logging
                console.log('🎮 Adding transport controls...');
                this.addControls(container);
                
                // Force controls visibility check
                setTimeout(() => {
                    const controls = container.querySelector('.transport-controls');
                    if (controls) {
                        console.log('✅ Controls added and found in DOM');
                        console.log('Controls position:', controls.getBoundingClientRect());
                    } else {
                        console.error('❌ Controls not found after adding - trying emergency fix');
                        this.addEmergencyControls(container);
                    }
                }, 500);
                
            } catch (error) {
                console.error('❌ OSMD failed:', error);
                renderArea.innerHTML = `
                    <div style="text-align: center; padding: 50px; color: #ef4444;">
                        <h3>❌ Cannot Display Score</h3>
                        <p>${error.message}</p>
                    </div>
                `;
            }
        } else {
            renderArea.innerHTML = `
                <div style="text-align: center; padding: 50px; color: #ef4444;">
                    <h3>❌ Invalid Container</h3>
                    <p>Dimensions: ${rect.width}x${rect.height}</p>
                </div>
            `;
        }
    }

    addControls(container) {
        if (this.isPlaying) {
            this.pausePlayback(playButton);
        } else {
            this.startPlayback(playButton);
        }
    }

    startPlayback(playButton) {
        console.log('▶️ Starting playback...');
        
        // Check if OSMD Playback Engine is available
        if (window.OSMDPlaybackEngine && this.workingOSMD) {
            try {
                // Try to use OSMD native playback
                if (this.workingOSMD.PlaybackManager) {
                    console.log('🎵 Using OSMD PlaybackManager');
                    this.workingOSMD.PlaybackManager.play();
                    this.isPlaying = true;
                    playButton.innerHTML = '⏸️';
                    this.statusDisplay.textContent = 'Playing';
                    this.statusDisplay.style.color = '#ef4444';
                    this.startPositionTimer();
                    return;
                }
            } catch (error) {
                console.warn('⚠️ OSMD PlaybackManager failed:', error);
            }
        }
        
        // Fallback: Simulate playback with visual feedback
        this.simulatePlayback(playButton);
    }

    pausePlayback(playButton) {
        console.log('⏸️ Pausing playback...');
        
        if (window.OSMDPlaybackEngine && this.workingOSMD) {
            try {
                if (this.workingOSMD.PlaybackManager) {
                    this.workingOSMD.PlaybackManager.pause();
                }
            } catch (error) {
                console.warn('⚠️ Pause failed:', error);
            }
        }
        
        this.isPlaying = false;
        playButton.innerHTML = '▶️';
        this.statusDisplay.textContent = 'Paused';
        this.statusDisplay.style.color = '#f59e0b';
        this.stopPositionTimer();
    }

    stopPlayback(playButton) {
        console.log('⏹️ Stopping playback...');
        
        if (window.OSMDPlaybackEngine && this.workingOSMD) {
            try {
                if (this.workingOSMD.PlaybackManager) {
                    this.workingOSMD.PlaybackManager.stop();
                }
            } catch (error) {
                console.warn('⚠️ Stop failed:', error);
            }
        }
        
        this.isPlaying = false;
        playButton.innerHTML = '▶️';
        this.statusDisplay.textContent = 'Ready';
        this.statusDisplay.style.color = '#10b981';
        this.positionDisplay.textContent = '00:00';
        this.stopPositionTimer();
        this.currentPosition = 0;
    }

    simulatePlayback(playButton) {
        console.log('🎼 Simulating playback (no audio)');
        
        this.isPlaying = true;
        playButton.innerHTML = '⏸️';
        this.statusDisplay.textContent = 'Playing (Visual)';
        this.statusDisplay.style.color = '#8b5cf6';
        this.currentPosition = 0;
        this.startPositionTimer();
        
        // Show info about playback simulation
        this.showPlaybackInfo();
    }

    startPositionTimer() {
        if (this.positionTimer) {
            clearInterval(this.positionTimer);
        }
        
        this.positionTimer = setInterval(() => {
            if (this.isPlaying) {
                this.currentPosition += 1;
                const minutes = Math.floor(this.currentPosition / 60);
                const seconds = this.currentPosition % 60;
                this.positionDisplay.textContent = 
                    `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
        }, 1000);
    }

    stopPositionTimer() {
        if (this.positionTimer) {
            clearInterval(this.positionTimer);
            this.positionTimer = null;
        }
    }

    showPlaybackInfo() {
        // Only show once per session
        if (this.playbackInfoShown) return;
        this.playbackInfoShown = true;
        
        const info = document.createElement('div');
        info.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px 35px;
            border-radius: 15px;
            z-index: 9999;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            text-align: center;
            max-width: 400px;
            backdrop-filter: blur(20px);
        `;
        
        info.innerHTML = `
            <div style="font-size: 48px; margin-bottom: 20px;">🎼</div>
            <div style="font-weight: 700; margin-bottom: 12px; font-size: 18px;">Visual Playback Mode</div>
            <div style="font-size: 14px; margin-bottom: 20px; opacity: 0.9; line-height: 1.4;">
                Il timer e i controlli simulano la riproduzione. Per l'audio completo è necessario configurare l'OSMD Playback Engine con Web Audio API.
            </div>
            <button id="playback-info-close-btn" style="
                background: rgba(255, 255, 255, 0.25);
                border: 1px solid rgba(255, 255, 255, 0.3);
                color: white;
                padding: 8px 20px;
                border-radius: 20px;
                cursor: pointer;
                font-weight: 600;
                transition: all 0.2s ease;
            ">
                Perfetto, Continua
            </button>
        `;
        
        document.body.appendChild(info);
        
        // Add event listener to close button (CSP compliant)
        const closeBtn = info.querySelector('#playback-info-close-btn');
        closeBtn.addEventListener('click', () => {
            info.remove();
        });
        
        closeBtn.addEventListener('mouseenter', () => {
            closeBtn.style.background = 'rgba(255,255,255,0.35)';
        });
        
        closeBtn.addEventListener('mouseleave', () => {
            closeBtn.style.background = 'rgba(255,255,255,0.25)';
        });
        
        // Auto-remove after 10 seconds
        setTimeout(() => {
            if (info.parentElement) {
                info.remove();
            }
        }, 10000);
    }

    async fetchFileContent(file) {
        try {
            console.log('📡 Fetching:', file.name);
            const response = await fetch(OC.generateUrl('/apps/musicxmlplayer/file/{fileId}', {fileId: file.id}));
            const rawResponse = await response.text();
            
            let xmlContent;
            if (rawResponse.trim().startsWith('{')) {
                const jsonData = JSON.parse(rawResponse);
                xmlContent = jsonData.content || rawResponse;
            } else {
                xmlContent = rawResponse;
            }
            
            return this.cleanXML(xmlContent);
        } catch (error) {
            console.error('❌ Fetch failed:', error);
            throw error;
        }
    }

    cleanXML(xmlContent) {
        console.log('🧹 Cleaning XML...');
        
        if (xmlContent.charCodeAt(0) === 0xFEFF) {
            xmlContent = xmlContent.slice(1);
        }
        
        xmlContent = xmlContent.trim();
        
        if (!xmlContent.startsWith('<?xml')) {
            xmlContent = '<?xml version="1.0" encoding="UTF-8"?>\n' + xmlContent;
        }
        
        console.log('✅ XML cleaned');
        return xmlContent;
    }

    destroy() {
        console.log('🗑️ Cleaning up MusicXML Player...');
        
        // Stop any playing audio
        this.stopPositionTimer();
        
        if (this.workingOSMD) {
            try {
                if (this.workingOSMD.PlaybackManager && this.workingOSMD.PlaybackManager.stop) {
                    this.workingOSMD.PlaybackManager.stop();
                }
                this.workingOSMD.clear();
            } catch (error) {
                console.warn('⚠️ OSMD cleanup failed:', error);
            }
        }
        
        // Reset state
        this.isPlaying = false;
        this.currentPosition = 0;
        this.workingOSMD = null;
        this.currentFile = null;
        
        console.log('✅ Cleanup completed');
    }

    getPlaybackState() {
        return {
            isPlaying: this.isPlaying,
            currentPosition: this.currentPosition,
            tempo: this.currentTempo,
            volume: this.currentVolume,
            hasOSMD: !!this.workingOSMD,
            currentFile: this.currentFile?.name || 'None'
        };
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Initializing MusicXML Player v2.1...');
    const player = new MusicXMLPlayer();
    player.init();
    if (!window.OCA) window.OCA = {};
    window.OCA.MusicXMLPlayer = player;
    console.log('✅ MusicXML Player v2.1 ready');
});
