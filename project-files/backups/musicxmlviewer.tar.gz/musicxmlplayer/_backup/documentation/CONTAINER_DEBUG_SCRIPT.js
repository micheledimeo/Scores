// DEBUG SCRIPT - Esegui questo nella console per diagnosticare il problema

console.log('🔍 === CONTAINER DIAGNOSIS ===');

// Test 1: Verifica esistenza elementi
const elements = [
    'score-area',
    'score-container', 
    'osmd-container',
    'welcome-guide'
];

elements.forEach(id => {
    const el = document.getElementById(id);
    console.log(`${id}:`, el ? 'EXISTS' : 'NOT FOUND');
    if (el) {
        const rect = el.getBoundingClientRect();
        const style = window.getComputedStyle(el);
        console.log(`  Dimensions: ${rect.width}x${rect.height}`);
        console.log(`  Display: ${style.display}, Visibility: ${style.visibility}`);
        console.log(`  Position: ${style.position}, Z-index: ${style.zIndex}`);
    }
});

// Test 2: Force score container visible
const scoreContainer = document.getElementById('score-container');
if (scoreContainer) {
    console.log('🔧 Forcing score-container visible...');
    scoreContainer.style.cssText = `
        position: absolute !important;
        top: 0 !important;
        left: 0 !important;
        right: 0 !important;
        bottom: 0 !important;
        width: 100% !important;
        height: 100% !important;
        background: red !important;
        z-index: 1000 !important;
        display: block !important;
        visibility: visible !important;
        opacity: 1 !important;
    `;
    scoreContainer.offsetHeight;
    
    const newRect = scoreContainer.getBoundingClientRect();
    console.log(`✅ Score container forced: ${newRect.width}x${newRect.height}`);
}

// Test 3: Force OSMD container visible  
const osmdContainer = document.getElementById('osmd-container');
if (osmdContainer) {
    console.log('🔧 Forcing osmd-container visible...');
    osmdContainer.style.cssText = `
        width: 800px !important;
        height: 600px !important;
        background: blue !important;
        display: block !important;
        visibility: visible !important;
        opacity: 1 !important;
        position: relative !important;
        padding: 20px !important;
        border: 5px solid yellow !important;
    `;
    osmdContainer.offsetHeight;
    
    const newRect = osmdContainer.getBoundingClientRect();
    console.log(`✅ OSMD container forced: ${newRect.width}x${newRect.height}`);
}

console.log('🔍 === END DIAGNOSIS ===');
console.log('💡 If containers are now visible with colors, the CSS is working');
console.log('💡 Try selecting a file again after running this script');
