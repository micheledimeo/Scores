# 🔍 DEBUG SCRIPT - Controlli Playback Non Visibili

## ESEGUI QUESTO NELLA CONSOLE PER DIAGNOSTICARE:

```javascript
// === DEBUG CONTROLLI PLAYBACK ===
console.log('🔍 === PLAYBACK CONTROLS DEBUG ===');

// 1. Verifica se il player è inizializzato
console.log('Player available:', !!window.player);
console.log('Player state:', window.player ? window.player.getPlaybackState() : 'N/A');

// 2. Verifica container spartito
const scoreContainer = document.getElementById('score-container');
const osmdContainer = document.getElementById('osmd-container');
console.log('Score container:', scoreContainer ? 'EXISTS' : 'NOT FOUND');
console.log('OSMD container:', osmdContainer ? 'EXISTS' : 'NOT FOUND');

// 3. Cerca i controlli esistenti
const existingControls = document.querySelector('.transport-controls') || 
                        document.querySelector('[style*="transport"]') ||
                        document.querySelector('[style*="bottom"]');
console.log('Existing controls:', existingControls ? 'FOUND' : 'NOT FOUND');

if (existingControls) {
    console.log('Controls element:', existingControls);
    console.log('Controls style:', existingControls.style.cssText);
}

// 4. Verifica se addControls è stato chiamato
if (window.player && window.player.currentFile) {
    console.log('Current file loaded:', window.player.currentFile.name);
    console.log('Play button ref:', !!window.player.playButton);
    console.log('Status display ref:', !!window.player.statusDisplay);
} else {
    console.log('❌ No file loaded or player not ready');
}

// 5. Force add controls manually
if (window.player && osmdContainer) {
    console.log('🔧 Attempting to manually add controls...');
    try {
        window.player.addControls(osmdContainer);
        console.log('✅ Controls manually added');
    } catch (error) {
        console.error('❌ Manual controls failed:', error);
    }
}

console.log('🔍 === END DEBUG ===');
```

## SE I CONTROLLI NON APPAIONO, PROVA QUESTO FIX IMMEDIATO:

```javascript
// === EMERGENCY CONTROLS FIX ===
if (window.player && document.getElementById('osmd-container')) {
    const container = document.getElementById('osmd-container');
    
    // Remove any existing controls
    const existing = container.querySelector('.transport-controls');
    if (existing) existing.remove();
    
    // Force add controls with emergency styling
    const controls = document.createElement('div');
    controls.className = 'transport-controls';
    controls.style.cssText = `
        position: fixed !important;
        bottom: 20px !important;
        left: 50% !important;
        transform: translateX(-50%) !important;
        background: rgba(99, 102, 241, 0.9) !important;
        color: white !important;
        padding: 15px 25px !important;
        border-radius: 30px !important;
        box-shadow: 0 8px 25px rgba(0,0,0,0.3) !important;
        display: flex !important;
        gap: 15px !important;
        align-items: center !important;
        z-index: 9999 !important;
        font-family: system-ui !important;
    `;
    
    // Simple play button
    const playBtn = document.createElement('button');
    playBtn.innerHTML = '▶️ PLAY';
    playBtn.style.cssText = `
        background: white !important;
        color: #6366f1 !important;
        border: none !important;
        padding: 8px 15px !important;
        border-radius: 15px !important;
        font-weight: bold !important;
        cursor: pointer !important;
    `;
    playBtn.onclick = () => {
        alert('🎼 Controlli Playback Attivi!\n\nI controlli sono ora visibili e funzionali.');
        if (window.player.togglePlayback) {
            window.player.togglePlayback(playBtn);
        }
    };
    
    // Status
    const status = document.createElement('span');
    status.textContent = 'CONTROLLI ATTIVI';
    status.style.cssText = 'font-weight: bold; font-size: 12px;';
    
    controls.appendChild(playBtn);
    controls.appendChild(status);
    document.body.appendChild(controls);
    
    console.log('🚨 EMERGENCY CONTROLS ADDED - Should be visible at bottom of screen');
}
```
