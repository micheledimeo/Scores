# 🚀 GUIDA INSTALLAZIONE - MusicXML Player per Nextcloud 31.0.7

## 📦 File da Caricare

Hai a disposizione l'archivio:
- **`musicxmlplayer_NC31_FIXED.zip`** (28 MB)
  - ✅ Compatibile con Nextcloud 31.0.7
  - ✅ CSP Provider corretto
  - ✅ Tutti i fix applicati

## 🔧 Installazione sul Server

### Metodo 1: Upload e Installazione Completa (Consigliato)

```bash
# 1. Connettiti al server
ssh ottoniascoppio

# 2. Vai nella directory delle app
cd /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/

# 3. Se esiste già l'app, disabilitala e rimuovila
php ../occ app:disable musicxmlplayer
rm -rf musicxmlplayer/

# 4. Carica l'archivio zip
# (usa SCP o FTP per caricare musicxmlplayer_NC31_FIXED.zip nella directory apps/)

# Esempio con SCP dal tuo Mac:
# scp /Users/Michele/musicxmlplayer_NC31_FIXED.zip ottoniascoppio:/home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/

# 5. Estrai l'archivio
unzip musicxmlplayer_NC31_FIXED.zip

# 6. Imposta permessi corretti
chown -R ottoniascoppio:ottoniascoppio musicxmlplayer/
chmod -R 755 musicxmlplayer/

# 7. Abilita l'app
php ../occ app:enable musicxmlplayer

# 8. Pulisci la cache
php ../occ maintenance:repair
```

### Metodo 2: Upload Solo File Modificati (Più veloce)

Se preferisci aggiornare solo i file cambiati:

```bash
# Carica questi file sul server:
# - lib/Service/CSPProvider.php (NUOVO)
# - lib/AppInfo/Application.php (MODIFICATO)

# Poi ricarica l'app:
php occ app:disable musicxmlplayer
php occ app:enable musicxmlplayer
```

## ✅ Verifica Installazione

### 1. Controlla App Abilitata

```bash
php occ app:list | grep musicxmlplayer
# Output atteso: musicxmlplayer: 1.0.0
```

### 2. Verifica Assenza Errori nei Log

```bash
# Monitora i log in tempo reale
tail -f /mnt/volume-8nico/Armadio/nextcloud.log | grep -E "(musicxmlplayer|CSP|error)"

# Oppure controlla gli ultimi errori
tail -50 /mnt/volume-8nico/Armadio/nextcloud.log | jq -r 'select(.level >= 3) | "\(.time) [\(.level)] \(.app): \(.message)"'
```

### 3. Test Web UI

1. Apri browser e vai a: `https://cloud.ottoniascoppio.org/index.php/apps/musicxmlplayer`
2. Apri Developer Console (F12)
3. Verifica:
   - ✅ Nessun errore 500 (Internal Server Error)
   - ✅ Nessuna violazione CSP
   - ✅ App carica correttamente
   - ✅ Lista file musicali viene popolata

### 4. Test Caricamento Spartito

1. Carica un file `.musicxml` nella tua libreria Nextcloud
2. Apri l'app MusicXML Player
3. Seleziona il file
4. Verifica:
   - ✅ Spartito si carica e viene visualizzato
   - ✅ OSMD rendering funziona
   - ✅ Controlli playback appaiono
   - ✅ Audio funziona (se implementato)

## 🐛 Risoluzione Problemi

### Errore: "App could not be enabled"

```bash
# Controlla i requisiti dell'app
php occ app:check musicxmlplayer

# Verifica la sintassi PHP
find musicxmlplayer/ -name "*.php" -exec php -l {} \;
```

### Errore CSP persistente

```bash
# Verifica che il CSPProvider sia corretto
cat apps/musicxmlplayer/lib/Service/CSPProvider.php

# Ricarica configurazione
php occ app:disable musicxmlplayer
php occ maintenance:repair
php occ app:enable musicxmlplayer
```

### File non trovati (404)

```bash
# Verifica presenza file JS
ls -lh apps/musicxmlplayer/js/

# Verifica permessi
chmod -R 755 apps/musicxmlplayer/
chown -R ottoniascoppio:ottoniascoppio apps/musicxmlplayer/
```

## 📊 Confronto Versioni

| Aspetto | Versione Vecchia | Versione NC31 Fixed |
|---------|------------------|---------------------|
| CSP API | `getPolicy()` | `new ContentSecurityPolicy()` |
| Inline Scripts | `allowInlineScript(true)` | Non necessario/rimosso |
| Compatibilità | NC 29-30 | NC 31.0.7+ |
| Errori 500 | ❌ Presenti | ✅ Risolti |
| CSP Violations | ❌ Multiple | ✅ Nessuna |

## 🔍 File Critici Modificati

### 1. `lib/Service/CSPProvider.php` ✨ NUOVO
**Cambiamenti chiave:**
- Usa `new ContentSecurityPolicy()` invece di `$event->getPolicy()`
- Rimuove chiamata a `allowInlineScript()`
- Aggiunge supporto per blob: URIs (per OSMD)
- Supporta Web Workers per audio processing

### 2. `lib/AppInfo/Application.php` 🔧 AGGIORNATO
**Cambiamenti chiave:**
- Importa `CSPProvider` e `AddContentSecurityPolicyEvent`
- Registra CSP Provider come event listener
- Mantiene compatibilità con NC 31+

## 📝 Note Importanti

1. **Backup Prima dell'Installazione**
   ```bash
   # Fai backup dell'app esistente
   cp -r apps/musicxmlplayer apps/musicxmlplayer.backup
   ```

2. **Verifica Versione Nextcloud**
   ```bash
   php occ -V
   # Deve essere >= 31.0.0
   ```

3. **Dipendenze PHP**
   ```bash
   # Verifica PHP >= 8.1
   php -v
   ```

## 🎯 Checklist Post-Installazione

- [ ] App appare nella lista app abilitate
- [ ] Nessun errore nei log Nextcloud
- [ ] App accessibile da web UI
- [ ] Lista file musicali si carica
- [ ] Spartiti si visualizzano correttamente
- [ ] Nessuna violazione CSP in console browser
- [ ] Controlli playback funzionano
- [ ] Performance accettabile

## 📞 Supporto

Se riscontri problemi:

1. Controlla log dettagliati:
   ```bash
   tail -100 /mnt/volume-8nico/Armadio/nextcloud.log | jq .
   ```

2. Verifica stato app:
   ```bash
   php occ app:list
   php occ app:check musicxmlplayer
   ```

3. Consulta documentazione Nextcloud:
   - https://docs.nextcloud.com/server/latest/developer_manual/

---

**Versione**: 1.0.0-NC31-FIXED
**Data**: 17 Ottobre 2025
**Compatibilità**: Nextcloud 31.0.7+
**Status**: ✅ Pronto per Deploy
