/**
 * OSMD Audio Worklet Processor
 * Handles Web Audio API processing for OSMD PlaybackManager
 */
class OSMDAudioProcessor extends AudioWorkletProcessor {
    constructor() {
        super();
        this.bufferSize = 128;
        this.sampleRate = 44100;
    }
    
    process(inputs, outputs, parameters) {
        const output = outputs[0];
        const input = inputs[0];
        
        // Simple passthrough with optional processing
        if (input.length > 0 && output.length > 0) {
            for (let channel = 0; channel < Math.min(input.length, output.length); ++channel) {
                if (input[channel] && output[channel]) {
                    output[channel].set(input[channel]);
                }
            }
        }
        
        return true; // Keep the processor alive
    }
}

registerProcessor('osmd-audio-processor', OSMDAudioProcessor);
