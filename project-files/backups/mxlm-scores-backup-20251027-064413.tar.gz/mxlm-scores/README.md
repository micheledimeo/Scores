# MusicXML Viewer for Nextcloud

Display, play, and manage MusicXML files directly in Nextcloud using OpenSheetMusicDisplay.

## Features

- 🎼 Display MusicXML, MusicXML compressed (.mxl), and other music notation formats
- ▶️ Interactive playback with tempo control
- 🎵 Transpose scores up or down
- 🔍 Zoom in/out for better readability
- 🖨️ Print support
- 📱 Responsive design
- 🔄 Full Nextcloud Files integration

## Supported Formats

- MusicXML (.xml, .musicxml)
- MusicXML Compressed (.mxl)
- MEI (Music Encoding Initiative)
- Guitar Pro files (.gp, .gp3, .gp4, .gp5, .gpx)

## Installation

### Prerequisites

- Nextcloud 28 or later
- Node.js 20 or later
- npm 10 or later

### Development Setup

1. Clone or copy this directory to your Nextcloud `apps/` folder
2. Install dependencies:
   ```bash
   npm install
   ```
3. Build the app:
   ```bash
   npm run build
   ```
4. Enable the app in Nextcloud:
   ```bash
   php occ app:enable musicxmlviewer
   ```

### Production Build

For production, run:
```bash
npm run build
```

This will create optimized files in the `js/` directory.

### Development Mode

For development with hot reload:
```bash
npm run watch
```

## Usage

1. Navigate to the MusicXML Viewer app in Nextcloud
2. Click "Upload MusicXML file" or select a file from the sidebar
3. The score will be displayed automatically
4. Use the playback controls to play, pause, and adjust tempo
5. Use zoom controls for better readability
6. Transpose the score using the transpose buttons

## Project Structure

```
musicxmlviewer/
├── appinfo/
│   ├── info.xml          # App metadata
│   └── routes.php        # App routes
├── lib/
│   └── Controller/       # PHP controllers
│       ├── PageController.php
│       └── ApiController.php
├── src/
│   ├── main.js           # Vue app entry point
│   ├── components/       # Vue components
│   │   ├── App.vue
│   │   └── MusicViewer.vue
│   └── css/
│       └── main.scss     # Global styles
├── templates/
│   └── main.php          # Main template
├── package.json          # Node dependencies
├── vite.config.js        # Vite configuration
└── README.md             # This file
```

## Development

### Adding New Features

1. Create new Vue components in `src/components/`
2. Add new routes in `appinfo/routes.php`
3. Create corresponding controllers in `lib/Controller/`
4. Build and test

### Debugging

- Enable Nextcloud debug mode in `config.php`:
  ```php
  'debug' => true,
  ```
- Check browser console for JavaScript errors
- Check Nextcloud logs for PHP errors: `data/nextcloud.log`

## Technologies Used

- **OpenSheetMusicDisplay**: Music notation rendering
- **Vue 3**: Frontend framework
- **Vite**: Build tool
- **Nextcloud Vue Components**: UI components
- **PHP**: Backend API

## License

AGPL-3.0-or-later

## Credits

- Built with [OpenSheetMusicDisplay](https://opensheetmusicdisplay.org/)
- Inspired by the WordPress OpenSheetMusicDisplay plugin

## Support

For issues and feature requests, please use the issue tracker on the repository.
