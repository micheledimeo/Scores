<template>
	<div id="content" class="app-scores">
		<NcAppNavigation v-if="!isPublicShare">
			<!-- Folder/File list -->
			<template #list>
				<!-- Search box -->
				<div class="search-box">
					<span class="icon-search"></span>
					<input
						v-model="searchQuery"
						type="text"
						placeholder="Search scores..."
						@input="filterFiles">
					<span v-if="getTotalFileCount() > 0" class="file-count">
						{{ getTotalFileCount() }}
					</span>
				</div>

				<ul class="app-navigation-list">
						<li v-if="filteredFolders.length === 0 && filteredFiles.length === 0" class="empty-list">
							<span class="icon-music"></span>
							<p v-if="folderStructure.folders.length === 0 && folderStructure.files.length === 0">No music files found</p>
							<p v-else>No matches found</p>
						</li>

						<!-- Folders (visualizzazione flat - solo primo livello) -->
						<NcAppNavigationItem
							v-for="folder in filteredFolders"
							:key="'folder-' + folder.id"
							:name="folder.name"
							:open="expandedFolders.has(folder.id)"
							@click="toggleFolder(folder.id)">
							<template #icon>
								<span class="icon-folder"></span>
							</template>
							<template #counter>
								<NcCounterBubble :count="folder.files?.length || 0" />
							</template>

							<!-- Files in folder (inclusi quelli nelle sottocartelle) -->
							<!-- Files will be shown as children -->
								<NcAppNavigationItem
									v-if="expandedFolders.has(folder.id)" v-for="file in folder.files"
									:key="'file-' + file.id"
									:name="getFileNameWithoutExtension(file.name)"
									:active="currentFile && currentFile.id === file.id"
									@click.stop="loadFile(file.id)">
									<template #icon>
										<span :class="isPlaying && currentFile && currentFile.id === file.id ? 'icon-sound' : 'icon-music'"></span>
									</template>
								</NcAppNavigationItem>
							
						</NcAppNavigationItem>

						<!-- Files at root level (if any) -->
						<NcAppNavigationItem
							v-for="file in filteredFiles"
							:key="'rootfile-' + file.id"
							:name="getFileNameWithoutExtension(file.name)"
							:active="currentFile && currentFile.id === file.id"
							@click="loadFile(file.id)">
							<template #icon>
								<span :class="isPlaying && currentFile && currentFile.id === file.id ? 'icon-sound' : 'icon-music'"></span>
							</template>
						</NcAppNavigationItem>
					</ul>
				</template>

				<!-- Welcome button in footer -->
				<template #footer>
					<div class="app-navigation-footer">
						<button @click="showWelcomeInfo" class="welcome-button">
							<span class="icon-info"></span>
							Welcome to Scores
						</button>
					</div>
				</template>
			</NcAppNavigation>

			<!-- Main content -->
			<NcAppContent>
				<div v-if="!currentFile" class="empty-content">
					<div class="empty-icon">
						<span class="icon-music"></span>
					</div>
					<h2>Welcome to Scores</h2>
					<p>Select a music score from the sidebar to begin</p>

					<!-- Quick Tips -->
					<div class="quick-tips">
						<h4>Quick Tips</h4>
						<ul>
							<li><kbd>Space</kbd> Play / Pause playback</li>
							<li><kbd>←</kbd> <kbd>→</kbd> Navigate between measures</li>
							<li><kbd>+</kbd> <kbd>-</kbd> Zoom in / out</li>
							<li>Click on any measure to jump to it</li>
							<li>Adjust tempo and volume in the playback bar</li>
						</ul>
					</div>

					<!-- Admin Settings - Button only -->
					<div v-if="isAdmin" class="admin-settings-button">
						<button
							v-if="scoresFolderPath === ''"
							class="configure-button primary"
							@click="openSettingsModal">
							<span class="icon-settings"></span>
							Configura Cartella Spartiti
						</button>
						<button
							v-else
							class="configure-button secondary"
							@click="openSettingsModal">
							<span class="icon-rename"></span>
							Modifica Impostazioni
						</button>
					</div>

					<!-- Settings Modal -->
					<div v-if="showSettingsModal" class="modal-backdrop" @click.self="closeSettingsModal">
						<div class="settings-modal">
							<div class="modal-header">
								<h3>
									<span class="icon-settings"></span>
									Impostazioni Cartella Spartiti
								</h3>
								<button class="close-button" @click="closeSettingsModal">
									<span class="icon-close"></span>
								</button>
							</div>

							<div class="modal-body">
								<div class="settings-section">
									<label for="scores-folder">Percorso Cartella:</label>
									<div class="folder-input-group">
										<input
											id="scores-folder"
											v-model="scoresFolderPath"
											type="text"
											placeholder="es. Musica/Spartiti o lascia vuoto per la root"
											class="folder-input"
											readonly
											@click="showFolderBrowser">
										<button
											class="browse-button"
											@click="showFolderBrowser">
											<span class="icon-folder"></span>
											Sfoglia
										</button>
									</div>
									<p class="settings-hint">
										Specifica il percorso della cartella dove sono memorizzati gli spartiti musicali (relativo alla home di ogni utente).
										Lascia vuoto per scansionare tutti i file degli utenti.
									</p>
									<p class="settings-hint">
										<strong>Nota sulla visualizzazione:</strong> Nella sidebar saranno elencate le cartelle che contengono più di un file visualizabile
										(contando ricorsivamente anche i file nelle sottocartelle). Se una cartella contiene un solo spartito,
										verrà elencato direttamente il file invece della cartella.
									</p>
									<div v-if="settingsSaved" class="success-message">
										<span class="icon-checkmark"></span>
										Impostazioni salvate con successo!
									</div>
									<div v-if="settingsError" class="error-message">
										<span class="icon-error"></span>
										{{ settingsError }}
									</div>
								</div>
							</div>

							<div class="modal-footer">
								<button class="secondary-button" @click="closeSettingsModal">
									Annulla
								</button>
								<button
									class="primary-button"
									:disabled="savingSettings"
									@click="saveScoresFolder">
									<span v-if="savingSettings" class="icon-loading-small"></span>
									<span v-else class="icon-checkmark"></span>
									Salva
								</button>
							</div>
						</div>
					</div>

					<!-- Folder Browser Modal -->
					<div v-if="showBrowserModal" class="modal-backdrop" @click.self="closeFolderBrowser">
						<div class="folder-browser-modal">
							<div class="modal-header">
								<h3>
									<span class="icon-folder"></span>
									Select Scores Folder
								</h3>
								<button class="close-button" @click="closeFolderBrowser">
									<span class="icon-close"></span>
								</button>
							</div>

							<div class="modal-body">
								<!-- Breadcrumb navigation -->
								<div class="breadcrumb">
									<span class="breadcrumb-item" @click="navigateToFolder('')">
										<span class="icon-home"></span>
										Home
									</span>
									<template v-for="(part, index) in breadcrumbParts" :key="index">
										<span class="breadcrumb-separator">/</span>
										<span class="breadcrumb-item" @click="navigateToFolder(getBreadcrumbPath(index))">
											{{ part }}
										</span>
									</template>
								</div>

								<!-- Folder list -->
								<div class="folder-list-browser">
									<div v-if="loadingFolders" class="loading-folders">
										<span class="icon-loading"></span>
										Loading folders...
									</div>
									<div v-else-if="browserFolders.length === 0" class="empty-folders">
										<span class="icon-folder"></span>
										<p>No folders found</p>
									</div>
									<div
										v-else
										v-for="folder in browserFolders"
										:key="folder.id"
										class="browser-folder-item"
										@dblclick="navigateToFolder(folder.path)">
										<span class="icon-folder"></span>
										<span class="folder-name-browser">{{ folder.name }}</span>
										<button class="select-folder-button" @click="selectFolder(folder.path)">
											Select
										</button>
									</div>
								</div>
							</div>

							<div class="modal-footer">
								<div class="current-selection">
									<strong>Selected:</strong>
									<span>{{ currentBrowserPath || '(root)' }}</span>
								</div>
								<div class="modal-actions">
									<button class="secondary-button" @click="closeFolderBrowser">
										Cancel
									</button>
									<button class="primary-button" @click="confirmFolderSelection">
										<span class="icon-checkmark"></span>
										Confirm
									</button>
								</div>
							</div>
						</div>
					</div>

				</div>

				<div v-else-if="loading" class="loading-content">
					<div class="loading-spinner">
						<span class="icon-loading"></span>
					</div>
					<p>Loading score...</p>
				</div>

				<MusicViewer
					v-else-if="currentFile && currentFile.content"
					:file-content="currentFile.content"
					:file-name="currentFile.name"
					:file-id="currentFile.id"
					:force-show-welcome="showWelcomeScreen"
					@playback-state-changed="handlePlaybackStateChange"
					@welcome-closed="showWelcomeScreen = false" />
			</NcAppContent>
	</div>
</template>

<script>
import { ref, computed, onMounted, onBeforeUnmount } from 'vue'
import axios from '@nextcloud/axios'
import { generateUrl } from '@nextcloud/router'
import { showError } from '@nextcloud/dialogs'
import { loadState } from '@nextcloud/initial-state'

import {
	NcAppNavigation,
	NcAppNavigationItem,
	NcAppContent,
	NcCounterBubble
} from '@nextcloud/vue'

import MusicViewer from './MusicViewer.vue'

export default {
	name: 'App',
	components: {
		MusicViewer,
		NcAppNavigation,
		NcAppNavigationItem,
		NcAppContent,
		NcCounterBubble,
	},
	setup() {
		const folderStructure = ref({ folders: [], files: [] })
		const filteredFolders = ref([])
		const filteredFiles = ref([])
		const expandedFolders = ref(new Set())
		const currentFile = ref(null)
		const loading = ref(false)
		const searchQuery = ref('')
		const isPlaying = ref(false)
		const isPublicShare = ref(false)
		const showWelcomeScreen = ref(false)
		const isAdmin = ref(false)
		const scoresFolderPath = ref('')
		const savingSettings = ref(false)
		const settingsSaved = ref(false)
		const settingsError = ref('')
		const showSettingsModal = ref(false)
		const showBrowserModal = ref(false)
		const browserFolders = ref([])
		const currentBrowserPath = ref('')
		const loadingFolders = ref(false)

		// Check if this is a public share using Nextcloud InitialState API
		try {
			const publicShareData = loadState('mxlmscores', 'publicShare')
			console.log('✓ Public share detected via InitialState!')
			isPublicShare.value = true

			// Load file data from InitialState
			currentFile.value = {
				id: null,
				name: publicShareData.fileName,
				content: publicShareData.fileContent,
				mimeType: 'application/vnd.recordare.musicxml+xml',
				size: 0
			}
			console.log('✓ Public share file loaded:', currentFile.value.name)
		} catch (e) {
			// Not a public share - load user's file list
			console.log('ℹ️ Not a public share - normal app mode')
		}

		const loadFiles = async () => {
			// Skip loading file list in public share view
			if (isPublicShare.value) {
				return
			}

			try {
				const response = await axios.get(generateUrl('/apps/mxlmscores/api/files'))
				folderStructure.value = response.data
				filterFiles()
			} catch (error) {
				showError('Failed to load music files')
				console.error(error)
			}
		}

		const filterFiles = () => {
			const query = searchQuery.value.toLowerCase().trim()
			if (!query) {
				filteredFolders.value = folderStructure.value.folders
				filteredFiles.value = folderStructure.value.files
			} else {
				// Filter folders and files recursively
				filteredFolders.value = filterFoldersRecursive(folderStructure.value.folders, query)
				filteredFiles.value = folderStructure.value.files.filter(file =>
					file.name.toLowerCase().includes(query)
				)
			}
		}

		const filterFoldersRecursive = (folders, query) => {
			return folders.map(folder => {
				const filteredSubfolders = filterFoldersRecursive(folder.folders || [], query)
				const filteredFiles = folder.files.filter(file =>
					file.name.toLowerCase().includes(query)
				)

				// Include folder if it has matching files or subfolders
				if (filteredFiles.length > 0 || filteredSubfolders.length > 0 || folder.name.toLowerCase().includes(query)) {
					return {
						...folder,
						folders: filteredSubfolders,
						files: filteredFiles
					}
				}
				return null
			}).filter(folder => folder !== null)
		}

		const toggleFolder = (folderId) => {
			if (expandedFolders.value.has(folderId)) {
				expandedFolders.value.delete(folderId)
			} else {
				expandedFolders.value.add(folderId)
			}
			// Trigger reactivity
			expandedFolders.value = new Set(expandedFolders.value)
		}

		const getFolderFileCount = (folder) => {
			let count = folder.files.length
			folder.folders.forEach(subfolder => {
				count += getFolderFileCount(subfolder)
			})
			return count
		}

		const getTotalFileCount = () => {
			let count = filteredFiles.value.length
			filteredFolders.value.forEach(folder => {
				count += getFolderFileCount(folder)
			})
			return count
		}

		const getFileNameWithoutExtension = (filename) => {
			// Remove common music file extensions
			// IMPORTANTE: mxml è l'estensione principale per MusicXML non compresso
			if (!filename) return ''
			return filename.toString().replace(/\.(mxml|xml|musicxml|mxl|mei|gp|gpx|gp3|gp4|gp5)$/i, '')
		}

		const loadFile = async (fileId) => {
			try {
				loading.value = true
				const response = await axios.get(generateUrl('/apps/mxlmscores/api/file/{fileId}', { fileId }))
				currentFile.value = {
					id: fileId,
					name: response.data.name,
					content: response.data.content,
					mimeType: response.data.mimeType,
					size: response.data.size
				}
			} catch (error) {
				showError('Failed to load file')
				console.error(error)
			} finally {
				loading.value = false
			}
		}

		const handlePlaybackStateChange = (playing) => {
			isPlaying.value = playing
		}

		const showWelcomeInfo = () => {
			// Torna alla home dell'app (nessun file caricato)
			currentFile.value = null
			loading.value = false
			showWelcomeScreen.value = false
		}

		// Admin settings functions
		const checkIsAdmin = async () => {
			try {
				const response = await axios.get(generateUrl('/apps/mxlmscores/api/settings/isAdmin'))
				isAdmin.value = response.data.isAdmin
			} catch (error) {
				console.error('Failed to check admin status:', error)
			}
		}

		const loadScoresFolder = async () => {
			if (!isAdmin.value) return

			try {
				const response = await axios.get(generateUrl('/apps/mxlmscores/api/settings/folder'))
				scoresFolderPath.value = response.data.folderPath
			} catch (error) {
				console.error('Failed to load scores folder setting:', error)
			}
		}

		const openSettingsModal = () => {
			showSettingsModal.value = true
			settingsSaved.value = false
			settingsError.value = ''
		}

		const closeSettingsModal = () => {
			showSettingsModal.value = false
			settingsSaved.value = false
			settingsError.value = ''
		}

		const saveScoresFolder = async () => {
			savingSettings.value = true
			settingsSaved.value = false
			settingsError.value = ''

			try {
				await axios.post(generateUrl('/apps/mxlmscores/api/settings/folder'), {
					folderPath: scoresFolderPath.value
				})
				settingsSaved.value = true
				// Reload files with new folder path
				await loadFiles()
				// Hide success message and close modal after 2 seconds
				setTimeout(() => {
					settingsSaved.value = false
					closeSettingsModal()
				}, 2000)
			} catch (error) {
				settingsError.value = error.response?.data?.error || 'Failed to save settings'
				setTimeout(() => {
					settingsError.value = ''
				}, 5000)
			} finally {
				savingSettings.value = false
			}
		}

		// Folder browser functions
		const breadcrumbParts = computed(() => {
			if (!currentBrowserPath.value) return []
			return currentBrowserPath.value.split('/')
		})

		const getBreadcrumbPath = (index) => {
			return breadcrumbParts.value.slice(0, index + 1).join('/')
		}

		const showFolderBrowser = async () => {
			showBrowserModal.value = true
			currentBrowserPath.value = scoresFolderPath.value
			await loadBrowserFolders(currentBrowserPath.value)
		}

		const closeFolderBrowser = () => {
			showBrowserModal.value = false
			browserFolders.value = []
			currentBrowserPath.value = ''
		}

		const loadBrowserFolders = async (path) => {
			loadingFolders.value = true
			try {
				const response = await axios.get(generateUrl('/apps/mxlmscores/api/settings/browse'), {
					params: { path }
				})
				browserFolders.value = response.data.folders
				currentBrowserPath.value = response.data.currentPath
			} catch (error) {
				showError('Failed to load folders')
				console.error(error)
			} finally {
				loadingFolders.value = false
			}
		}

		const navigateToFolder = async (path) => {
			await loadBrowserFolders(path)
		}

		const selectFolder = (path) => {
			currentBrowserPath.value = path
		}

		const confirmFolderSelection = () => {
			scoresFolderPath.value = currentBrowserPath.value
			closeFolderBrowser()
		}

		onMounted(async () => {
			// Skip admin checks and file loading in public share view
			if (!isPublicShare.value) {
				await checkIsAdmin()
				if (isAdmin.value) {
					await loadScoresFolder()
				}
				await loadFiles()
			}
		})

		return {
			folderStructure,
			filteredFolders,
			filteredFiles,
			expandedFolders,
			currentFile,
			loading,
			searchQuery,
			isPlaying,
			isPublicShare,
			showWelcomeScreen,
			isAdmin,
			scoresFolderPath,
			savingSettings,
			settingsSaved,
			settingsError,
			showSettingsModal,
			showBrowserModal,
			browserFolders,
			currentBrowserPath,
			loadingFolders,
			breadcrumbParts,
			loadFiles,
			loadFile,
			filterFiles,
			toggleFolder,
			showWelcomeInfo,
			openSettingsModal,
			closeSettingsModal,
			saveScoresFolder,
			showFolderBrowser,
			closeFolderBrowser,
			navigateToFolder,
			selectFolder,
			confirmFolderSelection,
			getBreadcrumbPath,
			getFileNameWithoutExtension,
			getFolderFileCount,
			getTotalFileCount,
			handlePlaybackStateChange,
		}
	},
}
</script>

<style scoped>
.app-scores {
	display: flex;
	width: 100%;
	height: 100%;
}

/* Remove all margins, padding and top positioning from content - increased specificity */
body #content.app-scores,
html body #content.app-scores,
body div#content.app-scores,
#content.app-scores,
.app-scores :deep(.app-content),
.app-scores :deep(.content),
.app-scores :deep(#content) {
	margin-top: 0 !important;
	padding-top: 0 !important;
	margin: 0 !important;
	top: 0 !important;
	position: relative !important;
}

/* Position toggle wrapper at top-right of sidebar */
.app-scores :deep(.app-navigation-toggle-wrapper) {
	position: absolute;
	top: 0;
	right: 0;
	z-index: 101;
}

/* Search box - same height as playback-controls, sticky when scrolling */
.search-box {
	position: sticky;
	top: 0;
	z-index: 100;
	padding: 12px 16px;
	border-bottom: 1px solid var(--color-border);
	display: flex;
	align-items: center;
	gap: 8px;
	background-color: var(--color-main-background);
	min-height: calc(44px + 24px); /* Same height as playback-controls */
	box-sizing: border-box;
}

.search-box input {
	flex: 1;
	border: 1px solid var(--color-border);
	border-radius: 4px;
	padding: 8px 12px;
	font-size: 14px;
	background-color: var(--color-main-background);
	color: var(--color-main-text);
}

.search-box input:focus {
	outline: none;
	border-color: var(--color-primary-element);
}

.search-box .file-count {
	background-color: var(--color-primary-element);
	color: var(--color-primary-text);
	padding: 4px 10px;
	border-radius: 12px;
	font-size: 13px;
	font-weight: 600;
	margin-left: auto;
}

/* App navigation list */
.app-navigation-list {
	padding: 0;
	margin: 0;
	list-style: none;
}

.empty-list {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	padding: 32px 16px;
	text-align: center;
	color: var(--color-text-maxcontrast);
}

.empty-list .icon-music {
	font-size: 48px;
	opacity: 0.3;
	margin-bottom: 16px;
}

/* Welcome button in footer */
.app-navigation-footer {
	border-top: 1px solid var(--color-border);
	padding: 12px;
}

.welcome-button {
	display: flex;
	align-items: center;
	justify-content: center;
	gap: 8px;
	padding: 12px 16px;
	border: none;
	background: var(--color-primary-element);
	color: var(--color-primary-text);
	cursor: pointer;
	width: 100%;
	text-align: center;
	border-radius: var(--border-radius);
	font-weight: 600;
	transition: all 0.2s;
	box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.welcome-button:hover {
	background-color: var(--color-primary-element-hover);
	transform: translateY(-1px);
	box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
}

.welcome-button:active {
	transform: translateY(0);
	box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.welcome-button span[class^="icon-"] {
	font-size: 18px;
}

/* Main content */
.empty-content,
.loading-content {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	height: 100%;
	padding: 3rem;
	text-align: center;
}

.empty-icon {
	width: 80px;
	height: 80px;
	border-radius: 50%;
	background-color: var(--color-background-hover);
	display: flex;
	align-items: center;
	justify-content: center;
	margin-bottom: 1.5rem;
}

.empty-icon .icon-music {
	font-size: 40px;
	opacity: 0.5;
}

.empty-content h2 {
	margin-bottom: 0.5rem;
	font-size: 24px;
	color: var(--color-main-text);
}

.empty-content p {
	color: var(--color-text-maxcontrast);
	margin-bottom: 2rem;
}

.quick-tips {
	background-color: var(--color-background-hover);
	padding: 20px;
	border-radius: 8px;
	max-width: 400px;
	text-align: left;
}

.quick-tips h4 {
	margin: 0 0 12px 0;
	font-size: 16px;
}

.quick-tips ul {
	list-style: none;
	padding: 0;
	margin: 0;
}

.quick-tips li {
	padding: 6px 0;
	color: var(--color-text-maxcontrast);
}

.quick-tips kbd {
	background-color: var(--color-main-background);
	border: 1px solid var(--color-border);
	border-radius: 3px;
	padding: 2px 6px;
	font-family: 'SF Mono', 'Monaco', monospace;
	font-size: 12px;
	font-weight: 600;
	color: var(--color-primary-element);
	margin: 0 2px;
}

/* Admin Settings Button */
.admin-settings-button {
	margin: 24px 0;
}

.configure-button {
	padding: 14px 28px;
	border: none;
	border-radius: var(--border-radius-large);
	font-weight: 600;
	font-size: 15px;
	cursor: pointer;
	transition: all 0.2s ease;
	display: inline-flex;
	align-items: center;
	gap: 10px;
	box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.configure-button.primary {
	background-color: var(--color-primary-element);
	color: var(--color-primary-text);
}

.configure-button.primary:hover {
	background-color: var(--color-primary-element-hover);
	transform: translateY(-2px);
	box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.configure-button.secondary {
	background-color: var(--color-background-dark);
	color: var(--color-main-text);
	border: 2px solid var(--color-border-dark);
}

.configure-button.secondary:hover {
	background-color: var(--color-background-hover);
	border-color: var(--color-primary-element);
	transform: translateY(-2px);
	box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

/* Settings Modal */
.settings-modal {
	background-color: var(--color-main-background);
	border-radius: var(--border-radius-large);
	box-shadow: 0 16px 48px rgba(0, 0, 0, 0.3);
	width: 90%;
	max-width: 600px;
	max-height: 85vh;
	display: flex;
	flex-direction: column;
	animation: slideUp 0.3s ease-out;
}

.settings-modal .modal-header h3 {
	margin: 0;
	font-size: 20px;
	display: flex;
	align-items: center;
	gap: 10px;
	color: var(--color-primary-element);
}

.settings-section {
	margin-bottom: 16px;
}

.settings-section label {
	display: block;
	margin-bottom: 8px;
	font-weight: 500;
	color: var(--color-main-text);
}

.folder-input-group {
	display: flex;
	gap: 8px;
	margin-bottom: 8px;
}

.folder-input {
	flex: 1;
	padding: 10px 12px;
	border: 1px solid var(--color-border);
	border-radius: 6px;
	font-size: 14px;
	background-color: var(--color-main-background);
	color: var(--color-main-text);
}

.folder-input:focus {
	outline: none;
	border-color: var(--color-primary-element);
}

.save-button {
	padding: 10px 20px;
	background-color: var(--color-primary-element);
	color: var(--color-primary-text);
	border: none;
	border-radius: 6px;
	font-weight: 600;
	cursor: pointer;
	transition: all 0.2s;
	display: flex;
	align-items: center;
	gap: 8px;
}

.save-button:hover:not(:disabled) {
	background-color: var(--color-primary-element-hover);
	transform: translateY(-1px);
	box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.save-button:disabled {
	opacity: 0.6;
	cursor: not-allowed;
}

.browse-button {
	padding: 10px 16px;
	background-color: var(--color-background-dark);
	color: var(--color-main-text);
	border: 1px solid var(--color-border);
	border-radius: 6px;
	font-weight: 600;
	cursor: pointer;
	transition: all 0.2s;
	display: flex;
	align-items: center;
	gap: 6px;
}

.browse-button:hover {
	background-color: var(--color-background-hover);
	transform: translateY(-1px);
}

.settings-hint {
	font-size: 13px;
	color: var(--color-text-maxcontrast);
	margin: 4px 0;
}

.success-message {
	padding: 12px;
	background-color: var(--color-success);
	color: white;
	border-radius: 6px;
	display: flex;
	align-items: center;
	gap: 8px;
	margin-top: 12px;
	animation: slideIn 0.3s ease-out;
}

.error-message {
	padding: 12px;
	background-color: var(--color-error);
	color: white;
	border-radius: 6px;
	display: flex;
	align-items: center;
	gap: 8px;
	margin-top: 12px;
	animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
	from {
		opacity: 0;
		transform: translateY(-10px);
	}
	to {
		opacity: 1;
		transform: translateY(0);
	}
}

/* Modal Backdrop & Animations */
.modal-backdrop {
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background-color: rgba(0, 0, 0, 0.6);
	backdrop-filter: blur(2px);
	display: flex;
	align-items: center;
	justify-content: center;
	z-index: 10000;
	animation: fadeIn 0.25s ease-out;
	padding: 20px;
}

@keyframes fadeIn {
	from {
		opacity: 0;
		backdrop-filter: blur(0);
	}
	to {
		opacity: 1;
		backdrop-filter: blur(2px);
	}
}

@keyframes slideUp {
	from {
		opacity: 0;
		transform: translateY(30px) scale(0.95);
	}
	to {
		opacity: 1;
		transform: translateY(0) scale(1);
	}
}

/* Folder Browser Modal */
.folder-browser-modal {
	background-color: var(--color-main-background);
	border-radius: var(--border-radius-large);
	box-shadow: 0 16px 48px rgba(0, 0, 0, 0.3);
	width: 90%;
	max-width: 750px;
	max-height: 85vh;
	display: flex;
	flex-direction: column;
	animation: slideUp 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
}

/* Modal Header */
.modal-header {
	padding: 24px;
	border-bottom: 2px solid var(--color-border);
	display: flex;
	align-items: center;
	justify-content: space-between;
	background: linear-gradient(135deg, var(--color-primary-element-light) 0%, transparent 100%);
}

.modal-header h3 {
	margin: 0;
	font-size: 22px;
	font-weight: 700;
	display: flex;
	align-items: center;
	gap: 12px;
	color: var(--color-primary-element);
}

.close-button {
	background: var(--color-background-hover);
	border: none;
	cursor: pointer;
	padding: 10px;
	border-radius: var(--border-radius);
	transition: all 0.2s ease;
	color: var(--color-main-text);
	width: 40px;
	height: 40px;
	display: flex;
	align-items: center;
	justify-content: center;
}

.close-button:hover {
	background-color: var(--color-error);
	color: white;
	transform: rotate(90deg);
}

.close-button .icon-close {
	font-size: 18px;
}

.modal-body {
	flex: 1;
	overflow-y: auto;
	padding: 28px;
	background-color: var(--color-main-background);
}

.breadcrumb {
	display: flex;
	align-items: center;
	flex-wrap: wrap;
	gap: 6px;
	padding: 14px 16px;
	background: linear-gradient(to right, var(--color-background-hover) 0%, var(--color-main-background) 100%);
	border: 2px solid var(--color-border);
	border-radius: var(--border-radius);
	margin-bottom: 20px;
	font-size: 14px;
	box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.05);
}

.breadcrumb-item {
	cursor: pointer;
	padding: 6px 12px;
	border-radius: var(--border-radius);
	transition: all 0.2s ease;
	display: flex;
	align-items: center;
	gap: 6px;
	color: var(--color-primary-element);
	font-weight: 500;
}

.breadcrumb-item:hover {
	background-color: var(--color-primary-element-light);
	transform: scale(1.05);
}

.breadcrumb-item:active {
	transform: scale(0.98);
}

.breadcrumb-item .icon-home {
	font-size: 16px;
}

.breadcrumb-separator {
	color: var(--color-text-maxcontrast);
	user-select: none;
	font-weight: 300;
}

.folder-list-browser {
	min-height: 320px;
	max-height: 420px;
	overflow-y: auto;
	border: 2px solid var(--color-border);
	border-radius: var(--border-radius);
	padding: 12px;
	background-color: var(--color-background-hover);
}

.folder-list-browser::-webkit-scrollbar {
	width: 12px;
}

.folder-list-browser::-webkit-scrollbar-track {
	background: var(--color-main-background);
	border-radius: var(--border-radius);
}

.folder-list-browser::-webkit-scrollbar-thumb {
	background: var(--color-primary-element);
	border-radius: var(--border-radius);
}

.folder-list-browser::-webkit-scrollbar-thumb:hover {
	background: var(--color-primary-element-hover);
}

.loading-folders,
.empty-folders {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	padding: 60px 20px;
	color: var(--color-text-maxcontrast);
	gap: 16px;
}

.loading-folders .icon-loading {
	font-size: 40px;
	color: var(--color-primary-element);
}

.empty-folders .icon-folder {
	font-size: 56px;
	opacity: 0.25;
}

.browser-folder-item {
	display: flex;
	align-items: center;
	gap: 14px;
	padding: 14px 16px;
	border-radius: var(--border-radius);
	cursor: pointer;
	transition: all 0.2s ease;
	margin-bottom: 6px;
	background-color: var(--color-main-background);
	border: 2px solid transparent;
}

.browser-folder-item:hover {
	background-color: var(--color-background-hover);
	border-color: var(--color-primary-element-light);
	transform: translateX(4px);
	box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.browser-folder-item .icon-folder {
	font-size: 28px;
	color: var(--color-primary-element);
	opacity: 0.9;
	flex-shrink: 0;
}

.folder-name-browser {
	flex: 1;
	font-weight: 500;
	font-size: 15px;
	color: var(--color-main-text);
}

.select-folder-button {
	padding: 8px 18px;
	background-color: var(--color-primary-element-light);
	color: var(--color-primary-element);
	border: 2px solid var(--color-primary-element);
	border-radius: var(--border-radius);
	cursor: pointer;
	font-weight: 600;
	font-size: 13px;
	transition: all 0.25s ease;
	opacity: 0;
	transform: scale(0.9);
}

.browser-folder-item:hover .select-folder-button {
	opacity: 1;
	transform: scale(1);
}

.select-folder-button:hover {
	background-color: var(--color-primary-element);
	color: white;
	box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
	transform: scale(1.05);
}

.select-folder-button:active {
	transform: scale(0.95);
}

.modal-footer {
	padding: 20px 24px;
	border-top: 2px solid var(--color-border);
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 20px;
	background: linear-gradient(to top, var(--color-background-hover) 0%, transparent 100%);
}

.current-selection {
	flex: 1;
	font-size: 14px;
	color: var(--color-text-maxcontrast);
	padding: 10px 14px;
	background-color: var(--color-background-dark);
	border-radius: var(--border-radius);
	border-left: 3px solid var(--color-primary-element);
}

.current-selection strong {
	color: var(--color-main-text);
	margin-right: 8px;
	font-weight: 600;
}

.current-selection span {
	color: var(--color-primary-element);
	font-weight: 500;
}

.modal-actions {
	display: flex;
	gap: 10px;
}

.secondary-button,
.primary-button {
	padding: 12px 24px;
	border: none;
	border-radius: var(--border-radius);
	font-weight: 600;
	font-size: 14px;
	cursor: pointer;
	transition: all 0.2s ease;
	display: flex;
	align-items: center;
	gap: 8px;
	box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.secondary-button {
	background-color: var(--color-background-dark);
	color: var(--color-main-text);
	border: 2px solid var(--color-border);
}

.secondary-button:hover {
	background-color: var(--color-background-hover);
	border-color: var(--color-border-dark);
	transform: translateY(-2px);
	box-shadow: 0 4px 10px rgba(0, 0, 0, 0.12);
}

.primary-button {
	background-color: var(--color-primary-element);
	color: var(--color-primary-text);
}

.primary-button:hover:not(:disabled) {
	background-color: var(--color-primary-element-hover);
	transform: translateY(-2px);
	box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.primary-button:disabled {
	opacity: 0.6;
	cursor: not-allowed;
	transform: none;
}

.primary-button:active:not(:disabled),
.secondary-button:active {
	transform: translateY(0);
	box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.loading-spinner {
	width: 60px;
	height: 60px;
	display: flex;
	align-items: center;
	justify-content: center;
}

.loading-spinner .icon-loading {
	font-size: 40px;
}

.loading-content p {
	margin-top: 1rem;
	color: var(--color-text-maxcontrast);
}

</style>

<style>
/* Global styles (not scoped) for app icon - always white */
/* Apply filter to make the black icon white in all themes */
.app-menu-icon img[src*="mxlmscores/img/app.svg"] {
	filter: brightness(0) invert(1);
}
</style>
