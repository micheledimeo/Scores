<?php
declare(strict_types=1);

namespace OCA\Scores\Controller;

use OCP\AppFramework\Controller;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\DataResponse;
use OCP\IConfig;
use OCP\IRequest;
use OCP\IGroupManager;
use OCP\Files\IRootFolder;
use OCP\Files\NotFoundException;

class SettingsController extends Controller {
    private IConfig $config;
    private IGroupManager $groupManager;
    private IRootFolder $rootFolder;
    private ?string $userId;

    public function __construct(
        string $appName,
        IRequest $request,
        IConfig $config,
        IGroupManager $groupManager,
        IRootFolder $rootFolder,
        ?string $userId
    ) {
        parent::__construct($appName, $request);
        $this->config = $config;
        $this->groupManager = $groupManager;
        $this->rootFolder = $rootFolder;
        $this->userId = $userId;
    }

    /**
     * @NoAdminRequired
     */
    public function isAdmin(): DataResponse {
        if ($this->userId === null) {
            return new DataResponse(['isAdmin' => false], Http::STATUS_UNAUTHORIZED);
        }

        $isAdmin = $this->groupManager->isAdmin($this->userId);
        return new DataResponse(['isAdmin' => $isAdmin]);
    }

    /**
     * @NoAdminRequired
     */
    public function getScoresFolder(): DataResponse {
        if ($this->userId === null) {
            return new DataResponse(['error' => 'User not logged in'], Http::STATUS_UNAUTHORIZED);
        }

        // Check if user is admin
        if (!$this->groupManager->isAdmin($this->userId)) {
            return new DataResponse(['error' => 'Admin access required'], Http::STATUS_FORBIDDEN);
        }

        $folderPath = $this->config->getAppValue($this->appName, 'scores_folder', '');
        return new DataResponse(['folderPath' => $folderPath]);
    }

    /**
     * @NoAdminRequired
     */
    public function setScoresFolder(string $folderPath): DataResponse {
        if ($this->userId === null) {
            return new DataResponse(['error' => 'User not logged in'], Http::STATUS_UNAUTHORIZED);
        }

        // Check if user is admin
        if (!$this->groupManager->isAdmin($this->userId)) {
            return new DataResponse(['error' => 'Admin access required'], Http::STATUS_FORBIDDEN);
        }

        // Validate folder path (remove leading/trailing slashes)
        $folderPath = trim($folderPath, '/');

        // Security: Prevent path traversal attacks
        if (str_contains($folderPath, '..') || str_contains($folderPath, '\\')) {
            return new DataResponse(['error' => 'Invalid path: path traversal not allowed'], Http::STATUS_BAD_REQUEST);
        }

        // Verify folder exists in user's files
        try {
            $userFolder = $this->rootFolder->getUserFolder($this->userId);
            if (!empty($folderPath)) {
                $targetFolder = $userFolder->get($folderPath);
                if (!($targetFolder instanceof \OCP\Files\Folder)) {
                    return new DataResponse(['error' => 'Path is not a folder'], Http::STATUS_BAD_REQUEST);
                }
            }
        } catch (NotFoundException $e) {
            return new DataResponse(['error' => 'Folder not found'], Http::STATUS_NOT_FOUND);
        }

        // Save to app config
        $this->config->setAppValue($this->appName, 'scores_folder', $folderPath);

        return new DataResponse(['success' => true, 'folderPath' => $folderPath]);
    }

    /**
     * @NoAdminRequired
     */
    public function browseFolders(string $path = ''): DataResponse {
        if ($this->userId === null) {
            return new DataResponse(['error' => 'User not logged in'], Http::STATUS_UNAUTHORIZED);
        }

        // Check if user is admin
        if (!$this->groupManager->isAdmin($this->userId)) {
            return new DataResponse(['error' => 'Admin access required'], Http::STATUS_FORBIDDEN);
        }

        try {
            $userFolder = $this->rootFolder->getUserFolder($this->userId);

            // Security: Prevent path traversal attacks
            if (str_contains($path, '..') || str_contains($path, '\\')) {
                return new DataResponse(['error' => 'Invalid path: path traversal not allowed'], Http::STATUS_BAD_REQUEST);
            }

            // Get target folder
            $targetFolder = $userFolder;
            if (!empty($path)) {
                $targetFolder = $userFolder->get($path);
                if (!($targetFolder instanceof \OCP\Files\Folder)) {
                    return new DataResponse(['error' => 'Not a folder'], Http::STATUS_BAD_REQUEST);
                }
            }

            // Get only folders (not files)
            $folders = [];
            foreach ($targetFolder->getDirectoryListing() as $node) {
                if ($node instanceof \OCP\Files\Folder) {
                    $relativePath = empty($path) ? $node->getName() : $path . '/' . $node->getName();
                    $folders[] = [
                        'id' => $node->getId(),
                        'name' => $node->getName(),
                        'path' => $relativePath
                    ];
                }
            }

            // Sort folders alphabetically
            usort($folders, function($a, $b) {
                return strcasecmp($a['name'], $b['name']);
            });

            return new DataResponse([
                'folders' => $folders,
                'currentPath' => $path
            ]);

        } catch (NotFoundException $e) {
            return new DataResponse(['error' => 'Folder not found'], Http::STATUS_NOT_FOUND);
        } catch (\Exception $e) {
            \OC::$server->getLogger()->error('Error in browseFolders: ' . $e->getMessage(), ['app' => 'mxlmscores']);
            return new DataResponse(['error' => 'Failed to browse folders'], Http::STATUS_INTERNAL_SERVER_ERROR);
        }
    }
}
